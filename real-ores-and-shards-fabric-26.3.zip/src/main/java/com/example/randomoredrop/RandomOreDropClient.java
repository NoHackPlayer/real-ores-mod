package com.example.randomoredrop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

import java.text.NumberFormat;
import java.util.Locale;

public class RandomOreDropClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipFlag, lines) -> {
            if (stack.is(ModItems.WINDFEATHER_CHARM)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.windfeather_charm").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.SHADOW_GOGGLES)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.shadow_goggles").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.MINERS_CHARM)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.miners_charm").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.MAGMA_WARD)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.magma_ward").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.RESILIENCE_CORE)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.resilience_core").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.VOID_SIPHON_RING)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.void_siphon_ring").withStyle(ChatFormatting.LIGHT_PURPLE));
            }
            long unitValue = ModEconomy.getValue(stack.getItem());
            if (unitValue <= 0) {
                return;
            }
            String formattedUnit = NumberFormat.getNumberInstance(Locale.US).format(unitValue);
            lines.add(Component.translatable("tooltip.randomoredrop.value", formattedUnit)
                    .withStyle(ChatFormatting.GOLD));
            if (stack.getCount() > 1) {
                String formattedTotal = NumberFormat.getNumberInstance(Locale.US).format(unitValue * stack.getCount());
                lines.add(Component.translatable("tooltip.randomoredrop.stack_value", formattedTotal)
                        .withStyle(ChatFormatting.YELLOW));
            }
        });
    }
}
