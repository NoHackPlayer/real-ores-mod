package com.example.randomoredrop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public class RandomOreDropClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipFlag, lines) -> {
            if (stack.getItem() instanceof CoinItem) {
                lines.add(Component.translatable("tooltip.randomoredrop.coin_hint").withStyle(ChatFormatting.GRAY));
            } else if (stack.is(ModItems.GRAVITY_ANCHOR_BOOTS)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.gravity_anchor_boots").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.ALCHEMIST_COIN_BELT)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.alchemist_coin_belt").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.VEIN_COMPASS_CROWN)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.vein_compass_crown").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.SHARD_RESONATOR_NECKLACE)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.shard_resonator_necklace").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.SHARD_COMPRESSOR_GLOVE)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.shard_compressor_glove").withStyle(ChatFormatting.AQUA));
            } else if (stack.is(ModItems.MERCHANT_FORTUNE_RING)) {
                lines.add(Component.translatable("tooltip.randomoredrop.artifact.merchant_fortune_ring").withStyle(ChatFormatting.LIGHT_PURPLE));
            }

            long unitCents = ModEconomy.getCents(stack.getItem());
            if (unitCents <= 0L) {
                return;
            }
            lines.add(Component.translatable("tooltip.randomoredrop.value", ModEconomy.formatCents(unitCents))
                    .withStyle(ChatFormatting.GOLD));
            if (stack.getCount() > 1) {
                lines.add(Component.translatable("tooltip.randomoredrop.stack_value", ModEconomy.formatCents(unitCents * stack.getCount()))
                        .withStyle(ChatFormatting.YELLOW));
            }
        });
    }
}
