package com.example.randomoredrop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class RandomOreDropClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.OpenComputerPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> {
                    Minecraft client = ctx.client();
                    client.gui.setScreen(new ComputerScreen(payload.balanceCents()));
                })
        );
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.BalanceSyncPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> {
                    Minecraft client = ctx.client();
                    Screen current = client.gui.screen();
                    if (current instanceof ComputerScreen computerScreen) {
                        computerScreen.updateBalance(payload.balanceCents(), payload.message(), payload.isError());
                    }
                })
        );
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.SpinResultPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> {
                    Minecraft client = ctx.client();
                    Screen current = client.gui.screen();
                    if (current instanceof ComputerScreen computerScreen) {
                        computerScreen.startSpin(payload);
                    }
                })
        );

        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipFlag, lines) -> {
            if (stack.is(ModItems.COMPUTER)) {
                lines.add(Component.literal("放置於地面後右鍵開啟多功能電腦介面").withStyle(ChatFormatting.AQUA));
            } else if (stack.getItem() instanceof CoinItem) {
                lines.add(Component.translatable("tooltip.randomoredrop.coin_hint").withStyle(ChatFormatting.GRAY));
            }

            long unitCents = ModEconomy.getCents(stack.getItem());
            if (unitCents <= 0L) {
                return;
            }
            lines.add(Component.translatable("tooltip.randomoredrop.value", ModEconomy.formatCents(unitCents))
                    .withStyle(ChatFormatting.GOLD));
            if (stack.getCount() > 1) {
                lines.add(Component.translatable("tooltip.randomoredrop.stack_value", ModEconomy.formatCents(unitCents * stack.getCount()))
                        .withStyle(ChatFormatting.YELLOW));
            }
        });
    }
}
