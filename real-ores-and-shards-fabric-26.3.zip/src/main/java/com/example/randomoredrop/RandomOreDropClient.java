package com.example.randomoredrop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public class RandomOreDropClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.OpenComputerPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> ctx.client().gui.setScreen(new ComputerScreen(payload.balanceCents())))
        );
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.BalanceSyncPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> {
                    if (ctx.client().gui.screen() instanceof ComputerScreen screen) {
                        screen.updateBalance(payload.balanceCents(), payload.msgKey(), payload.arg1(), payload.arg2(), payload.isError());
                    }
                })
        );
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.SpinResultPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> {
                    if (ctx.client().gui.screen() instanceof ComputerScreen screen) {
                        screen.startSpin(payload);
                    }
                })
        );

        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipFlag, lines) -> {
            if (stack.is(ModItems.COMPUTER)) {
                lines.add(Component.translatable("tooltip.randomoredrop.computer_hint").withStyle(ChatFormatting.AQUA));
            } else if (stack.getItem() instanceof CoinItem) {
                lines.add(Component.translatable("tooltip.randomoredrop.coin_hint").withStyle(ChatFormatting.GRAY));
            }
            if (stack.isDamageableItem() && stack.getMaxDamage() > 0) {
                float wear = Math.min(1.0F, Math.max(0.0F, stack.getDamageValue() / (float) stack.getMaxDamage()));
                String wearKey;
                ChatFormatting wearCol;
                if (wear < 0.20F) { wearKey = "wear.randomoredrop.fn"; wearCol = ChatFormatting.GREEN; }
                else if (wear < 0.40F) { wearKey = "wear.randomoredrop.mw"; wearCol = ChatFormatting.AQUA; }
                else if (wear < 0.60F) { wearKey = "wear.randomoredrop.ft"; wearCol = ChatFormatting.YELLOW; }
                else if (wear < 0.80F) { wearKey = "wear.randomoredrop.ww"; wearCol = ChatFormatting.GOLD; }
                else { wearKey = "wear.randomoredrop.bs"; wearCol = ChatFormatting.RED; }
                String pct = String.format("%.0f%%", wear * 100.0F);
                lines.add(Component.translatable("tooltip.randomoredrop.wear", Component.translatable(wearKey), pct).withStyle(wearCol));
            }

            long unitCents = ModEconomy.getUnitCents(stack);
            if (unitCents <= 0L) {
                return;
            }
            lines.add(Component.translatable("tooltip.randomoredrop.value", ModEconomy.formatCents(unitCents))
                    .withStyle(ChatFormatting.GOLD));
            if (stack.getCount() > 1) {
                lines.add(Component.translatable("tooltip.randomoredrop.stack_value", ModEconomy.formatCents(unitCents * stack.getCount()))
                        .withStyle(ChatFormatting.YELLOW));
            }
        });
    }
}
