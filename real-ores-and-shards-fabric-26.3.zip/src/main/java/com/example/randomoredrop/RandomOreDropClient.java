package com.example.randomoredrop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

import java.text.NumberFormat;
import java.util.Locale;

public class RandomOreDropClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipFlag, lines) -> {
            long unitValue = ModEconomy.getValue(stack.getItem());
            if (unitValue <= 0) {
                return;
            }
            String formattedUnit = NumberFormat.getNumberInstance(Locale.US).format(unitValue);
            lines.add(Component.translatable("tooltip.randomoredrop.value", formattedUnit)
                    .withStyle(ChatFormatting.GOLD));
            if (stack.getCount() > 1) {
                String formattedTotal = NumberFormat.getNumberInstance(Locale.US).format(unitValue * stack.getCount());
                lines.add(Component.translatable("tooltip.randomoredrop.stack_value", formattedTotal)
                        .withStyle(ChatFormatting.YELLOW));
            }
        });
    }
}
