package com.example.randomoredrop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public class RandomOreDropClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.OpenComputerPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> ctx.client().setScreen(new ComputerScreen(payload.balanceCents())))
        );
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.BalanceSyncPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> {
                    if (ctx.client().screen instanceof ComputerScreen screen) {
                        screen.updateBalance(payload.balanceCents(), payload.message(), payload.isError());
                    }
                })
        );
        ClientPlayNetworking.registerGlobalReceiver(
                ComputerNetwork.SpinResultPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> {
                    if (ctx.client().screen instanceof ComputerScreen screen) {
                        screen.startSpin(payload);
                    }
                })
        );

        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipFlag, lines) -> {
            if (stack.is(ModItems.COMPUTER)) {
                lines.add(Component.literal("放置於地面後右鍵開啟多功能電腦介面").withStyle(ChatFormatting.AQUA));
            } else if (stack.getItem() instanceof CoinItem) {
                lines.add(Component.translatable("tooltip.randomoredrop.coin_hint").withStyle(ChatFormatting.GRAY));
            }

            long unitCents = ModEconomy.getCents(stack.getItem());
            if (unitCents <= 0L) {
                return;
            }
            lines.add(Component.translatable("tooltip.randomoredrop.value", ModEconomy.formatCents(unitCents))
                    .withStyle(ChatFormatting.GOLD));
            if (stack.getCount() > 1) {
                lines.add(Component.translatable("tooltip.randomoredrop.stack_value", ModEconomy.formatCents(unitCents * stack.getCount()))
                        .withStyle(ChatFormatting.YELLOW));
            }
        });
    }
}
