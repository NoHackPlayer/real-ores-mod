package com.example.randomoredrop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public class RandomOreDropClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipFlag, lines) -> {
            if (stack.getItem() instanceof CoinItem) {
                lines.add(Component.translatable("tooltip.randomoredrop.coin_hint").withStyle(ChatFormatting.GRAY));
            }

            long unitCents = ModEconomy.getCents(stack.getItem());
            if (unitCents <= 0L) {
                return;
            }
            lines.add(Component.translatable("tooltip.randomoredrop.value", ModEconomy.formatCents(unitCents))
                    .withStyle(ChatFormatting.GOLD));
            if (stack.getCount() > 1) {
                lines.add(Component.translatable("tooltip.randomoredrop.stack_value", ModEconomy.formatCents(unitCents * stack.getCount()))
                        .withStyle(ChatFormatting.YELLOW));
            }
        });
    }
}
