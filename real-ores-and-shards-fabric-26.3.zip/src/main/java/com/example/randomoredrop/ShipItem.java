package com.example.randomoredrop;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 原創船隻物品：對準水面右鍵生成對應原木船體（靈感來自常見船模玩法，非第三方程式碼）。
 */
public class ShipItem extends Item {
    private final String boatEntityId;
    private final String kindLangKey;
    private final int plankCost;

    public ShipItem(String boatEntityId, String kindLangKey, int plankCost, Properties properties) {
        super(properties);
        this.boatEntityId = boatEntityId;
        this.kindLangKey = kindLangKey;
        this.plankCost = plankCost;
    }

    public int getPlankCost() {
        return plankCost;
    }

    public String getKindLangKey() {
        return kindLangKey;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        HitResult hit = getPlayerPOVHitResult(level, player, ClipContext.Fluid.SOURCE_ONLY);
        if (hit.getType() != HitResult.Type.BLOCK) {
            return InteractionResult.PASS;
        }
        BlockHitResult blockHit = (BlockHitResult) hit;
        BlockPos pos = blockHit.getBlockPos();
        if (!level.getFluidState(pos).is(FluidTags.WATER)) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.PASS;
        }

        EntityType<?> type = BuiltInRegistries.ENTITY_TYPE.getOptional(Identifier.withDefaultNamespace(this.boatEntityId))
                .orElse(null);
        if (type == null) {
            // 後備：橡木船
            type = BuiltInRegistries.ENTITY_TYPE.getOptional(Identifier.withDefaultNamespace("oak_boat")).orElse(null);
        }
        if (type == null) {
            return InteractionResult.FAIL;
        }

        Entity boat = type.create(serverLevel, EntitySpawnReason.SPAWN_ITEM_USE);
        if (boat == null) {
            return InteractionResult.FAIL;
        }

        Vec3 loc = blockHit.getLocation();
        // 略浮於水面
        boat.moveTo(loc.x, loc.y + 0.1, loc.z, player.getYRot(), 0.0F);
        boat.setYRot(player.getYRot());
        boat.setCustomName(Component.translatable(this.kindLangKey));
        boat.setCustomNameVisible(true);

        if (!serverLevel.noCollision(boat, boat.getBoundingBox())) {
            return InteractionResult.FAIL;
        }

        serverLevel.addFreshEntity(boat);
        serverLevel.playSound(null, loc.x, loc.y, loc.z, SoundEvents.BOAT_PADDLE_WATER, SoundSource.PLAYERS, 1.0F, 1.0F);
        player.awardStat(Stats.ITEM_USED.get(this));
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return InteractionResult.SUCCESS;
    }
}
