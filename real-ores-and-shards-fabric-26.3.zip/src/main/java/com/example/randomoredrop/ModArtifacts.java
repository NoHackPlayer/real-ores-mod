package com.example.randomoredrop;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.HashSet;
import java.util.Set;

public class ModArtifacts {
    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int tick = server.getTickCount();
            if (tick % 20 != 0) {
                return;
            }
            boolean regenPulse = (tick % 80 == 0);
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (player.isSpectator() || !player.isAlive()) {
                    continue;
                }
                Set<Item> active = collectActiveArtifacts(player);
                if (active.isEmpty()) {
                    continue;
                }
                if (active.contains(ModItems.WINDFEATHER_CHARM)) {
                    grant(player, "speed", 60, 0);
                    grant(player, "jump_boost", 60, 0);
                }
                if (active.contains(ModItems.SHADOW_GOGGLES)) {
                    grant(player, "night_vision", 260, 0);
                }
                if (active.contains(ModItems.MINERS_CHARM)) {
                    grant(player, "haste", 60, 0);
                }
                if (active.contains(ModItems.MAGMA_WARD)) {
                    grant(player, "fire_resistance", 60, 0);
                }
                if (active.contains(ModItems.RESILIENCE_CORE)) {
                    grant(player, "resistance", 60, 0);
                }
                if (active.contains(ModItems.VOID_SIPHON_RING)) {
                    grant(player, "strength", 60, 0);
                    if (regenPulse) {
                        grant(player, "regeneration", 40, 0);
                    }
                }
            }
        });
    }

    private static Set<Item> collectActiveArtifacts(ServerPlayer player) {
        Set<Item> found = new HashSet<>();
        Inventory inv = player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && isArtifact(st.getItem())) {
                found.add(st.getItem());
            }
        }
        ItemStack off = player.getOffhandItem();
        if (!off.isEmpty() && isArtifact(off.getItem())) {
            found.add(off.getItem());
        }
        return found;
    }

    public static boolean isArtifact(Item item) {
        return item == ModItems.WINDFEATHER_CHARM
                || item == ModItems.SHADOW_GOGGLES
                || item == ModItems.MINERS_CHARM
                || item == ModItems.MAGMA_WARD
                || item == ModItems.RESILIENCE_CORE
                || item == ModItems.VOID_SIPHON_RING;
    }

    public static ItemStack rollRandomArtifact(RandomSource rng) {
        int r = rng.nextInt(100);
        if (r < 30) {
            return new ItemStack(ModItems.WINDFEATHER_CHARM);
        } else if (r < 55) {
            return new ItemStack(ModItems.SHADOW_GOGGLES);
        } else if (r < 70) {
            return new ItemStack(ModItems.MINERS_CHARM);
        } else if (r < 82) {
            return new ItemStack(ModItems.MAGMA_WARD);
        } else if (r < 92) {
            return new ItemStack(ModItems.RESILIENCE_CORE);
        } else {
            return new ItemStack(ModItems.VOID_SIPHON_RING);
        }
    }

    private static void grant(ServerPlayer player, String effectId, int duration, int amplifier) {
        BuiltInRegistries.MOB_EFFECT.get(Identifier.withDefaultNamespace(effectId)).ifPresent(holder ->
                player.addEffect(new MobEffectInstance(holder, duration, amplifier, true, false, true))
        );
    }
}
