package com.example.randomoredrop;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.Optional;

public class ModArtifacts {
    private static boolean trinketsChecked = false;
    private static Method trinketsGetComponent = null;

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int tick = server.getTickCount();
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (player.isSpectator() || !player.isAlive()) {
                    continue;
                }

                // 1. 沉重防摔鐵靴（鞋子飾品欄）：高空墜落超過 3 格或空中潛行時自動觸發短暫緩降
                if (tick % 4 == 0 && isEquipped(player, ModItems.GRAVITY_ANCHOR_BOOTS)) {
                    if (!player.onGround() && (player.fallDistance > 3.0F || (player.isShiftKeyDown() && player.getDeltaMovement().y < -0.2))) {
                        grant(player, "slow_falling", 25, 0);
                    }
                }

                // 2. 貪婪商賈戒（戒指欄）：幸運 I（挖礦額外給金幣在 RandomOreDropMod 處理）
                if (tick % 40 == 0 && isEquipped(player, ModItems.MERCHANT_FORTUNE_RING)) {
                    grant(player, "luck", 80, 0);
                }

                // 3. 礦脈探測冠（帽子飾品欄）：每 4 秒掃描周圍 10 格內是否有稀有/史詩礦脈
                if (tick % 80 == 0 && isEquipped(player, ModItems.VEIN_COMPASS_CROWN)) {
                    scanNearbyRareOre(player);
                }

                // 4. 碎礦壓縮手套（手套飾品欄）：每 5 秒自動將背包內 4 個相同碎片壓縮成 1 個完整礦物
                if (tick % 100 == 0 && isEquipped(player, ModItems.SHARD_COMPRESSOR_GLOVE)) {
                    compressOneShardStack(player);
                }
            }
        });
    }

    /**
     * 穿戴在 Trinkets 飾品欄才生效（放快捷欄不生效）；未裝 Trinkets 時自動退回檢查副手
     */
    public static boolean isEquipped(ServerPlayer player, Item target) {
        if (isTrinketsLoaded()) {
            return isEquippedInTrinkets(player, target);
        }
        return player.getOffhandItem().is(target);
    }

    private static boolean isTrinketsLoaded() {
        return FabricLoader.getInstance().isModLoaded("trinkets")
                || FabricLoader.getInstance().isModLoaded("trinkets_updated");
    }

    private static boolean isEquippedInTrinkets(ServerPlayer player, Item target) {
        try {
            if (!trinketsChecked) {
                trinketsChecked = true;
                Class<?> apiCls = Class.forName("dev.emi.trinkets.api.TrinketsApi");
                trinketsGetComponent = apiCls.getMethod("getTrinketComponent", LivingEntity.class);
            }
            if (trinketsGetComponent == null) {
                return false;
            }
            Object optObj = trinketsGetComponent.invoke(null, player);
            if (optObj instanceof Optional<?> opt && opt.isPresent()) {
                Object comp = opt.get();
                Method isEq = comp.getClass().getMethod("isEquipped", Item.class);
                Object res = isEq.invoke(comp, target);
                return Boolean.TRUE.equals(res);
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static void scanNearbyRareOre(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }
        BlockPos origin = player.blockPosition();
        int radius = 10;
        double closestSq = Double.MAX_VALUE;
        Block foundBlock = null;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos p = origin.offset(dx, dy, dz);
                    Block b = level.getBlockState(p).getBlock();
                    if (isRareTargetOre(b)) {
                        double dSq = dx * dx + dy * dy + dz * dz;
                        if (dSq < closestSq) {
                            closestSq = dSq;
                            foundBlock = b;
                        }
                    }
                }
            }
        }

        if (foundBlock != null) {
            int dist = (int) Math.round(Math.sqrt(closestSq));
            player.displayClientMessage(Component.literal("✦ 偵測到稀有礦脈：")
                    .withStyle(ChatFormatting.AQUA)
                    .append(foundBlock.getName().copy().withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD))
                    .append(Component.literal("（距離約 " + dist + " 格）").withStyle(ChatFormatting.GRAY)), true);
        }
    }

    private static boolean isRareTargetOre(Block b) {
        return b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE
                || b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE
                || b == Blocks.ANCIENT_DEBRIS
                || b == ModBlocks.TITANIUM_ORE || b == ModBlocks.DEEPSLATE_TITANIUM_ORE
                || b == ModBlocks.TUNGSTEN_ORE || b == ModBlocks.DEEPSLATE_TUNGSTEN_ORE;
    }

    private static void compressOneShardStack(ServerPlayer player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (st.isEmpty() || st.getCount() < 4) {
                continue;
            }
            for (Map.Entry<Item, Item> entry : ModItems.ORE_TO_SHARD.entrySet()) {
                if (st.is(entry.getValue())) {
                    st.shrink(4);
                    ItemStack result = new ItemStack(entry.getKey(), 1);
                    if (!inv.add(result)) {
                        player.level().addFreshEntity(new ItemEntity(
                                player.level(), player.getX(), player.getY(), player.getZ(), result));
                    }
                    player.level().playSound(null, player.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 0.15F, 1.8F);
                    return;
                }
            }
        }
    }

    public static ItemStack rollRandomArtifact(RandomSource rng) {
        int r = rng.nextInt(100);
        if (r < 25) {
            return new ItemStack(ModItems.GRAVITY_ANCHOR_BOOTS);
        } else if (r < 50) {
            return new ItemStack(ModItems.ALCHEMIST_COIN_BELT);
        } else if (r < 68) {
            return new ItemStack(ModItems.VEIN_COMPASS_CROWN);
        } else if (r < 82) {
            return new ItemStack(ModItems.SHARD_RESONATOR_NECKLACE);
        } else if (r < 93) {
            return new ItemStack(ModItems.SHARD_COMPRESSOR_GLOVE);
        } else {
            return new ItemStack(ModItems.MERCHANT_FORTUNE_RING);
        }
    }

    private static void grant(ServerPlayer player, String effectId, int duration, int amplifier) {
        BuiltInRegistries.MOB_EFFECT.get(Identifier.withDefaultNamespace(effectId)).ifPresent(holder ->
                player.addEffect(new MobEffectInstance(holder, duration, amplifier, true, false, true))
        );
    }
}
