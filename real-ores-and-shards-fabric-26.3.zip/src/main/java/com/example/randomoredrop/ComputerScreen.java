package com.example.randomoredrop;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ComputerScreen extends Screen {
    private static final String[] CASE_IDS = {
            "starter", "miner", "gem", "artifact", "armory", "netherite", "legendary"
    };

    private static final int[] CASE_TOP_COLORS = {
            0xFF8B561B, // starter (warm wood)
            0xFF217A4B, // miner (emerald)
            0xFF187399, // gem (aqua)
            0xFF6B3199, // treasure (royal purple)
            0xFF9C7418, // armory (gold)
            0xFF96202B, // netherite (crimson)
            0xFFC49216  // legendary (imperial gold)
    };

    private static final int[] CASE_BOT_COLORS = {
            0xFF281D13,
            0xFF13261C,
            0xFF11232C,
            0xFF20152D,
            0xFF2B2210,
            0xFF2A1216,
            0xFF33260E
    };

    private static final int[] TIER_ARGB = {
            0xFF4B69FF, // 0: Blue 軍規級
            0xFF8847FF, // 1: Purple 受限級
            0xFFD32CE6, // 2: Pink 保密級
            0xFFEB4B4B, // 3: Red 隱秘級
            0xFFFFD700  // 4: Gold 罕見極品
    };

    private static final int[] TIER_BG = {
            0xFF1A2238,
            0xFF241B38,
            0xFF301A36,
            0xFF361A1E,
            0xFF3B3014
    };

    private enum Tab { CASES, SELL, BANK }
    private enum CaseSubView { GRID, PREVIEW, SPIN }

    private Tab activeTab = Tab.CASES;
    private CaseSubView subView = CaseSubView.GRID;
    private String selectedCaseId = "starter";

    private long balanceCents;
    private String toastText = "";
    private boolean toastError = false;
    private long toastUntilMs = 0L;
    private int openedThisSession = 0;

    private static final int REEL_TOTAL = 56;
    private static final int WIN_IDX = 46;
    private static final long SPIN_DURATION_MS = 4600L;
    private final List<ComputerActions.CaseEntry> spinReel = new ArrayList<>();
    private long spinStartMs = 0L;
    private boolean spinFinished = false;
    private boolean spinClaimed = false;
    private int lastTickCard = -1;
    private long lastSpinCostCents = 0L;
    private long lastWinValCents = 0L;
    private int lastWinTier = 0;
    private ItemStack lastWinStack = ItemStack.EMPTY;

    private record HitBox(int x, int y, int w, int h, Runnable onClick) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }
    /** Hitboxes used for input (previous frame). */
    private List<HitBox> hitBoxes = new ArrayList<>();
    /** Hitboxes being built during the current extractRenderState call. */
    private final List<HitBox> pendingHitBoxes = new ArrayList<>();

    public ComputerScreen(long initialBalanceCents) {
        super(Component.literal("多功能電腦終端"));
        this.balanceCents = initialBalanceCents;
    }

    public void updateBalance(long newBalanceCents, String message, boolean isError) {
        this.balanceCents = newBalanceCents;
        if (message != null && !message.isEmpty()) {
            this.toastText = message.startsWith("ERR:") ? message.substring(4) : message;
            this.toastError = isError;
            this.toastUntilMs = System.currentTimeMillis() + 4500L;
        }
    }

    public void startSpin(ComputerNetwork.SpinResultPayload payload) {
        this.balanceCents = payload.newBalanceCents();
        this.selectedCaseId = payload.caseId();
        this.lastSpinCostCents = payload.costCents();
        this.lastWinValCents = payload.winValueCents();
        this.lastWinTier = payload.winTier();

        Item winItem = BuiltInRegistries.ITEM.getOptional(Identifier.parse(payload.winItemId())).orElse(Items.DIAMOND);
        this.lastWinStack = new ItemStack(winItem, payload.winCount());

        this.spinReel.clear();
        RandomSource rng = RandomSource.create();
        for (int i = 0; i < REEL_TOTAL; i++) {
            if (i == WIN_IDX) {
                this.spinReel.add(ComputerActions.makeEntryForClient(this.lastWinStack, payload.winTier()));
            } else {
                this.spinReel.add(ComputerActions.rollCaseEntry(payload.caseId(), rng));
            }
        }
        this.spinStartMs = System.currentTimeMillis();
        this.spinFinished = false;
        this.spinClaimed = false;
        this.lastTickCard = -1;
        this.activeTab = Tab.CASES;
        this.subView = CaseSubView.SPIN;
        this.openedThisSession++;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        if (this.subView == CaseSubView.SPIN && !this.spinClaimed) {
            this.spinClaimed = true;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("claim_spin", ""));
        }
        super.onClose();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        this.pendingHitBoxes.clear();

        int W = this.width;
        int H = this.height;

        // 1. Deep dark CS:GO dashboard backdrop
        g.fill(0, 0, W, H, 0xF00F131A);

        // 2. Top Navigation Bar (28px)
        int topH = 28;
        g.fill(0, 0, W, topH, 0xFF161C26);
        g.fill(0, topH - 1, W, topH, 0xFF283244);

        int tx = 10;
        tx = drawNavTab(g, tx, 4, 68, 20, "CASES 開箱", this.activeTab == Tab.CASES, mouseX, mouseY, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) {
                finishSpinNow();
            }
            this.activeTab = Tab.CASES;
            this.subView = CaseSubView.GRID;
        });
        tx = drawNavTab(g, tx + 4, 4, 82, 20, "UPGRADER 升級", false, mouseX, mouseY, () -> {
            playClick();
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) {
                finishSpinNow();
            }
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("open_upgrader", ""));
        });
        tx = drawNavTab(g, tx + 4, 4, 66, 20, "SELL 出售", this.activeTab == Tab.SELL, mouseX, mouseY, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) {
                finishSpinNow();
            }
            this.activeTab = Tab.SELL;
        });
        drawNavTab(g, tx + 4, 4, 68, 20, "BANK 銀行", this.activeTab == Tab.BANK, mouseX, mouseY, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) {
                finishSpinNow();
            }
            this.activeTab = Tab.BANK;
        });

        String balStr = "● " + ModEconomy.formatCents(this.balanceCents) + " 金幣";
        int balW = this.font.width(balStr);
        int closeX = W - 26;
        g.fill(closeX - balW - 18, 5, closeX - 6, 23, 0xFF1F2735);
        g.text(this.font, Component.literal(balStr).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                closeX - balW - 12, 10, 0xFFFFD54F, true);

        boolean closeHover = mouseX >= closeX && mouseX < closeX + 18 && mouseY >= 5 && mouseY < 23;
        g.fill(closeX, 5, closeX + 18, 23, closeHover ? 0xFFB83232 : 0xFF252D3D);
        g.centeredText(this.font, Component.literal("✕"), closeX + 9, 10, 0xFFFFFFFF);
        this.pendingHitBoxes.add(new HitBox(closeX, 5, 18, 18, this::onClose));

        // 3. Main Content Area
        int contentTop = topH + 8;
        int contentBot = H - 22;
        if (this.activeTab == Tab.CASES) {
            if (this.subView == CaseSubView.GRID) {
                renderCaseGrid(g, contentTop, contentBot, mouseX, mouseY);
            } else if (this.subView == CaseSubView.PREVIEW) {
                renderCasePreview(g, contentTop, contentBot, mouseX, mouseY);
            } else {
                renderCaseSpin(g, contentTop, contentBot, mouseX, mouseY);
            }
        } else if (this.activeTab == Tab.SELL) {
            renderSellTab(g, contentTop, contentBot, mouseX, mouseY);
        } else {
            renderBankTab(g, contentTop, contentBot, mouseX, mouseY);
        }

        // 4. Bottom Status Bar (20px)
        int botY = H - 20;
        g.fill(0, botY, W, H, 0xFF141923);
        g.fill(0, botY, W, botY + 1, 0xFF283244);
        g.text(this.font, Component.literal("ESC - 關閉"), 10, botY + 6, 0xFF8B97AD, false);

        if (System.currentTimeMillis() < this.toastUntilMs && !this.toastText.isEmpty()) {
            int col = this.toastError ? 0xFFFF6B6B : 0xFF5CE08C;
            g.centeredText(this.font, Component.literal(this.toastText), W / 2, botY + 6, col);
        } else {
            g.centeredText(this.font, Component.literal("點擊寶箱卡片立即開箱｜點右下角 i 預覽獎池與機率"), W / 2, botY + 6, 0xFF6E7B91);
        }

        String sess = "本次已開箱：" + this.openedThisSession;
        g.text(this.font, Component.literal(sess), W - this.font.width(sess) - 10, botY + 6, 0xFF8B97AD, false);

        // Publish hitboxes for the next input events (render builds, input consumes previous frame)
        this.hitBoxes = new ArrayList<>(this.pendingHitBoxes);
    }

    private void renderCaseGrid(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        int cols = 4;
        int gap = 10;
        int padX = Math.max(16, (W - 460) / 2);
        int availW = W - padX * 2;
        int cardW = Math.min(118, (availW - gap * (cols - 1)) / cols);
        int totalGridW = cardW * cols + gap * (cols - 1);
        int startX = (W - totalGridW) / 2;

        int availH = bot - top - 8;
        int cardH = Math.min(96, (availH - gap) / 2);
        int startY = top + Math.max(4, (availH - (cardH * 2 + gap)) / 2);

        for (int i = 0; i < CASE_IDS.length; i++) {
            String cid = CASE_IDS[i];
            ComputerActions.CaseDef def = ComputerActions.getCaseDef(cid);
            int row = i / cols;
            int col = i % cols;
            int x = startX + col * (cardW + gap);
            int y = startY + row * (cardH + gap);

            int bannerH = (int) (cardH * 0.56);
            boolean cardHover = mouseX >= x && mouseX < x + cardW && mouseY >= y && mouseY < y + cardH;

            drawBorder(g, x - 1, y - 1, cardW + 2, cardH + 2, cardHover ? 0xFF58A6FF : 0xFF263042);
            fillVerticalGradient(g, x, y, x + cardW, y + bannerH, CASE_TOP_COLORS[i], CASE_BOT_COLORS[i]);
            g.fill(x, y + bannerH, x + cardW, y + cardH, cardHover ? 0xFF212A3A : 0xFF19202D);

            drawScaledItem(g, new ItemStack(def.icon()), x + cardW / 2 - 16, y + bannerH / 2 - 16, 2.0F);

            String cleanName = def.displayName().replaceAll("^[^\u4e00-\u9fffA-Za-z0-9]+\s*", "");
            g.text(this.font, Component.literal(cleanName).withStyle(ChatFormatting.WHITE),
                    x + 6, y + bannerH + 5, 0xFFFFFFFF, true);
            String priceTxt = "● " + ModEconomy.formatCents(def.costCents());
            g.text(this.font, Component.literal(priceTxt).withStyle(ChatFormatting.GOLD),
                    x + 6, y + bannerH + 17, 0xFFFFD54F, false);

            int infoX = x + cardW - 18;
            int infoY = y + cardH - 15;
            boolean infoHover = mouseX >= infoX && mouseX < infoX + 14 && mouseY >= infoY && mouseY < infoY + 13;
            g.fill(infoX, infoY, infoX + 14, infoY + 13, infoHover ? 0xFF3B82F6 : 0xFF293448);
            g.centeredText(this.font, Component.literal("i"), infoX + 7, infoY + 2, 0xFFFFFFFF);

            g.text(this.font, Component.literal(cardHover && !infoHover ? "點擊開箱" : "OPEN"),
                    x + 6, y + cardH - 12, cardHover && !infoHover ? 0xFF5CE08C : 0xFF7D8AA3, false);

            this.pendingHitBoxes.add(new HitBox(infoX, infoY, 14, 13, () -> {
                playClick();
                this.selectedCaseId = cid;
                this.subView = CaseSubView.PREVIEW;
            }));
            this.pendingHitBoxes.add(new HitBox(x, y, cardW, cardH, () -> {
                playClick();
                ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", cid));
            }));
        }
    }

    private void renderCasePreview(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        ComputerActions.CaseDef def = ComputerActions.getCaseDef(this.selectedCaseId);

        int hx = Math.max(16, (W - 440) / 2);
        int hw = W - hx * 2;
        g.fill(hx, top, hx + hw, top + 28, 0xFF18202E);
        drawBorder(g, hx, top, hw, 28, 0xFF2B374D);

        drawButton(g, hx + 6, top + 5, 58, 18, "← 返回", 0xFF263145, 0xFF354460, mouseX, mouseY, () -> {
            playClick();
            this.subView = CaseSubView.GRID;
        });

        g.text(this.font, Component.literal(def.displayName() + "｜" + ModEconomy.formatCents(def.costCents()) + " 金幣")
                .withStyle(def.titleColor(), ChatFormatting.BOLD), hx + 72, top + 5, 0xFFFFFFFF, true);
        g.text(this.font, Component.literal("藍 52%  紫 26.5%  粉 14.5%  紅 5.5%  金 ★1.5%"),
                hx + 72, top + 16, 0xFF94A3B8, false);

        drawButton(g, hx + hw - 96, top + 5, 90, 18, "🎰 立即開箱", 0xFF1F7A46, 0xFF29A05C, mouseX, mouseY, () -> {
            playClick();
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", this.selectedCaseId));
        });

        List<ComputerActions.PreviewEntry> entries = ComputerActions.getPreviewEntries(this.selectedCaseId);
        int cols = 5;
        int gap = 6;
        int cardW = (hw - gap * (cols - 1)) / cols;
        int gridTop = top + 34;
        int rows = (entries.size() + cols - 1) / cols;
        int cardH = Math.min(40, Math.max(28, (bot - gridTop - gap * (rows - 1)) / Math.max(1, rows)));

        List<Component> hoveredTooltip = null;
        for (int i = 0; i < entries.size(); i++) {
            ComputerActions.PreviewEntry e = entries.get(i);
            int r = i / cols;
            int c = i % cols;
            int x = hx + c * (cardW + gap);
            int y = gridTop + r * (cardH + gap);
            if (y + cardH > bot) break;

            int tierCol = TIER_ARGB[Math.min(4, e.tierIndex())];
            int bgCol = TIER_BG[Math.min(4, e.tierIndex())];
            boolean hover = mouseX >= x && mouseX < x + cardW && mouseY >= y && mouseY < y + cardH;

            g.fill(x, y, x + cardW, y + cardH, hover ? 0xFF253045 : bgCol);
            g.fill(x, y + cardH - 3, x + cardW, y + cardH, tierCol);
            drawBorder(g, x, y, cardW, cardH, hover ? tierCol : 0xFF2A3448);

            ItemStack st = new ItemStack(e.item(), e.minCount());
            g.item(st, x + 5, y + (cardH - 18) / 2);

            String nm = st.getHoverName().getString();
            if (nm.length() > 7) nm = nm.substring(0, 6) + "…";
            g.text(this.font, Component.literal(nm), x + 25, y + 6, 0xFFFFFFFF, false);
            long minV = ModEconomy.getCents(e.item()) * e.minCount();
            g.text(this.font, Component.literal("● " + ModEconomy.formatCents(minV)), x + 25, y + 17, 0xFFFFD54F, false);

            if (hover) {
                long maxV = ModEconomy.getCents(e.item()) * e.maxCount();
                String cntTxt = e.minCount() == e.maxCount() ? ("數量：" + e.minCount()) : ("數量：" + e.minCount() + "–" + e.maxCount());
                String valTxt = minV == maxV ? ("價值：" + ModEconomy.formatCents(minV) + " 金幣")
                        : ("價值：" + ModEconomy.formatCents(minV) + "–" + ModEconomy.formatCents(maxV) + " 金幣");
                hoveredTooltip = List.of(
                        st.getHoverName().copy().withStyle(e.color(), ChatFormatting.BOLD),
                        Component.literal("等級：" + e.rarityLabel() + "（" + e.chanceText() + "）").withStyle(e.color()),
                        Component.literal(cntTxt).withStyle(ChatFormatting.WHITE),
                        Component.literal(valTxt).withStyle(ChatFormatting.GOLD)
                );
            }
        }
        if (hoveredTooltip != null) {
            g.setTooltipForNextFrame(this.font, hoveredTooltip, Optional.empty(), mouseX, mouseY);
        }
    }

    private void renderCaseSpin(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        ComputerActions.CaseDef def = ComputerActions.getCaseDef(this.selectedCaseId);

        long elapsed = System.currentTimeMillis() - this.spinStartMs;
        double t = Math.min(1.0, elapsed / (double) SPIN_DURATION_MS);
        if (this.spinFinished) t = 1.0;

        double eased = 1.0 - Math.pow(1.0 - t, 4.0);

        int trackW = Math.min(440, W - 32);
        int trackX = (W - trackW) / 2;
        int trackH = 88;
        int trackY = top + Math.max(18, (bot - top - trackH - 60) / 2);
        int centerX = trackX + trackW / 2;

        g.centeredText(this.font, Component.literal(def.displayName() + (this.spinFinished ? " — 開獎結果" : " — CS:GO 滾動中..."))
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), W / 2, trackY - 16, 0xFFFFD54F);

        g.fill(trackX - 2, trackY - 2, trackX + trackW + 2, trackY + trackH + 2, 0xFF283347);
        g.fill(trackX, trackY, trackX + trackW, trackY + trackH, 0xFF0C1017);

        int cardW = 64;
        int cardGap = 6;
        int stepPx = cardW + cardGap;
        double startOffset = 2.0 * stepPx;
        double targetOffset = WIN_IDX * (double) stepPx;
        double currentPos = startOffset + (targetOffset - startOffset) * eased;

        int curCard = (int) Math.round(currentPos / stepPx);
        if (!this.spinFinished && curCard != this.lastTickCard) {
            this.lastTickCard = curCard;
            float pitch = (float) (1.55 - 0.65 * t);
            Minecraft.getInstance().getSoundManager().play(
                    SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_HAT.value(), pitch, 0.55F));
        }

        for (int i = 0; i < this.spinReel.size(); i++) {
            int cx = (int) Math.round(centerX + (i * stepPx - currentPos) - cardW / 2.0);
            if (cx + cardW < trackX + 2 || cx > trackX + trackW - 2) {
                continue;
            }
            int drawL = Math.max(cx, trackX + 2);
            int drawR = Math.min(cx + cardW, trackX + trackW - 2);
            if (drawR <= drawL) continue;

            ComputerActions.CaseEntry entry = this.spinReel.get(i);
            int tierCol = TIER_ARGB[Math.min(4, entry.tierIndex())];
            int bgCol = TIER_BG[Math.min(4, entry.tierIndex())];
            int cy = trackY + 6;
            int ch = trackH - 12;

            g.fill(drawL, cy, drawR, cy + ch, bgCol);
            g.fill(drawL, cy + ch - 4, drawR, cy + ch, tierCol);
            if (cx >= trackX + 2 && cx + cardW <= trackX + trackW - 2) {
                boolean isWinnerNow = this.spinFinished && i == WIN_IDX;
                drawBorder(g, cx, cy, cardW, ch, isWinnerNow ? 0xFFFFD700 : 0xFF2A364B);
                drawScaledItem(g, entry.stack(), cx + cardW / 2 - 16, cy + 10, 2.0F);
                String lbl = entry.stack().getHoverName().getString();
                if (lbl.length() > 6) lbl = lbl.substring(0, 5) + "…";
                g.centeredText(this.font, Component.literal(lbl), cx + cardW / 2, cy + ch - 16, 0xFFE2E8F0);
            }
        }

        g.fill(centerX - 1, trackY, centerX + 1, trackY + trackH, 0xFFFFD700);
        g.fill(centerX - 5, trackY, centerX + 6, trackY + 4, 0xFFFFD700);
        g.fill(centerX - 5, trackY + trackH - 4, centerX + 6, trackY + trackH, 0xFFFFD700);

        if (t >= 1.0 && !this.spinFinished) {
            finishSpinNow();
        }

        int btnY = trackY + trackH + 14;
        if (!this.spinFinished) {
            drawButton(g, W / 2 - 58, btnY, 116, 22, "⏩ 跳過動畫（立即開獎）", 0xFF28507A, 0xFF356CA3, mouseX, mouseY, this::finishSpinNow);
        } else {
            int tierCol = TIER_ARGB[Math.min(4, this.lastWinTier)];
            long diff = this.lastWinValCents - this.lastSpinCostCents;
            String diffTxt = (diff >= 0 ? "+" : "") + ModEconomy.formatCents(diff) + " 金幣";
            String winLine = "★ " + this.lastWinStack.getHoverName().getString() + " x" + this.lastWinStack.getCount()
                    + "  ｜  價值 " + ModEconomy.formatCents(this.lastWinValCents) + " 金幣（" + diffTxt + "）";
            g.centeredText(this.font, Component.literal(winLine), W / 2, btnY, tierCol);

            int rowY = btnY + 16;
            drawButton(g, W / 2 - 135, rowY, 85, 22, "← 返回寶箱列表", 0xFF263145, 0xFF364663, mouseX, mouseY, () -> {
                playClick();
                this.subView = CaseSubView.GRID;
            });
            drawButton(g, W / 2 - 42, rowY, 96, 22, "🔁 再抽一次", 0xFF1F7A46, 0xFF29A05C, mouseX, mouseY, () -> {
                playClick();
                ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", this.selectedCaseId));
            });
            drawButton(g, W / 2 + 62, rowY, 76, 22, "ⓘ 預覽獎池", 0xFF4B3278, 0xFF63439C, mouseX, mouseY, () -> {
                playClick();
                this.subView = CaseSubView.PREVIEW;
            });
        }
    }

    private void finishSpinNow() {
        this.spinFinished = true;
        if (!this.spinClaimed) {
            this.spinClaimed = true;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("claim_spin", ""));
        }
    }

    private void renderSellTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        int cardW = Math.min(195, (W - 48) / 2);
        int cardH = Math.min(140, bot - top - 24);
        int gap = 16;
        int startX = (W - (cardW * 2 + gap)) / 2;
        int y = top + (bot - top - cardH) / 2;

        ItemStack offhand = this.minecraft != null && this.minecraft.player != null
                ? this.minecraft.player.getOffhandItem() : ItemStack.EMPTY;
        long offVal = offhand.isEmpty() ? 0L : ModEconomy.getCents(offhand.getItem()) * offhand.getCount();

        drawPanelCard(g, startX, y, cardW, cardH, 0xFF1D6B48, 0xFF16222E);
        drawScaledItem(g, offhand.isEmpty() ? new ItemStack(Items.EMERALD) : offhand, startX + cardW / 2 - 16, y + 14, 2.0F);
        g.centeredText(this.font, Component.literal("販售副手物品").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
                startX + cardW / 2, y + 54, 0xFF5CE08C);
        String offInfo = offhand.isEmpty()
                ? "請先把物品放進副手"
                : (offhand.getHoverName().getString() + " x" + offhand.getCount() + " (" + ModEconomy.formatCents(offVal) + " 金幣)");
        g.centeredText(this.font, Component.literal(offInfo), startX + cardW / 2, y + 70, 0xFFD0D8E8);
        drawButton(g, startX + cardW / 2 - 50, y + cardH - 30, 100, 20, "🏷 立即販售副手", 0xFF1F7A46, 0xFF29A05C, mouseX, mouseY, () -> {
            playClick();
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("sell_offhand", ""));
        });

        int rx = startX + cardW + gap;
        int mineralCnt = 0;
        long mineralVal = 0L;
        if (this.minecraft != null && this.minecraft.player != null) {
            Inventory inv = this.minecraft.player.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack st = inv.getItem(i);
                if (!st.isEmpty() && !(st.getItem() instanceof CoinItem) && ModEconomy.isBulkSellable(st.getItem())) {
                    long u = ModEconomy.getCents(st.getItem());
                    if (u > 0L) {
                        mineralCnt += st.getCount();
                        mineralVal += u * st.getCount();
                    }
                }
            }
        }
        drawPanelCard(g, rx, y, cardW, cardH, 0xFF8C6919, 0xFF16222E);
        drawScaledItem(g, new ItemStack(Items.HOPPER), rx + cardW / 2 - 16, y + 14, 2.0F);
        g.centeredText(this.font, Component.literal("一鍵販售礦物與碎片").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                rx + cardW / 2, y + 54, 0xFFFFD54F);
        String minInfo = mineralCnt > 0
                ? ("背包可賣：" + mineralCnt + " 個（共 " + ModEconomy.formatCents(mineralVal) + " 金幣）")
                : "背包目前無可批次販售礦物";
        g.centeredText(this.font, Component.literal(minInfo), rx + cardW / 2, y + 70, 0xFFD0D8E8);
        drawButton(g, rx + cardW / 2 - 54, y + cardH - 30, 108, 20, "💰 一鍵全部賣出", 0xFF9C7218, 0xFFC49222, mouseX, mouseY, () -> {
            playClick();
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("sell_minerals", ""));
        });
    }

    private void renderBankTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        Item[] coins = {ModItems.COIN_1, ModItems.COIN_10, ModItems.COIN_100, ModItems.COIN_1000, ModItems.COIN_10000};
        String[] labels = {"1", "10", "100", "1,000", "10,000"};
        String[] args = {"1", "10", "100", "1000", "10000"};
        int[] colors = {0xFF7D5324, 0xFF6B778C, 0xFFA37E18, 0xFF1C7E9E, 0xFF7A32A8};

        int gap = 8;
        int cardW = Math.min(78, (W - 40 - gap * 4) / 5);
        int cardH = 92;
        int totalW = cardW * 5 + gap * 4;
        int startX = (W - totalW) / 2;
        int y = top + Math.max(12, (bot - top - cardH - 42) / 2);

        for (int i = 0; i < 5; i++) {
            int x = startX + i * (cardW + gap);
            String arg = args[i];
            drawPanelCard(g, x, y, cardW, cardH, colors[i], 0xFF18202E);
            drawScaledItem(g, new ItemStack(coins[i]), x + cardW / 2 - 16, y + 10, 2.0F);
            g.centeredText(this.font, Component.literal(labels[i] + " 金幣"), x + cardW / 2, y + 48, 0xFFFFD54F);
            drawButton(g, x + 8, y + cardH - 24, cardW - 16, 18, "提款", 0xFF28507A, 0xFF3A72AD, mouseX, mouseY, () -> {
                playClick();
                ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("withdraw", arg));
            });
        }

        int depY = y + cardH + 14;
        drawButton(g, startX, depY, totalW, 24, "🏦 一鍵存入背包全部實體金幣（可直接丟給其他玩家再存入）",
                0xFF1F7A46, 0xFF29A05C, mouseX, mouseY, () -> {
                    playClick();
                    ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("deposit_all", ""));
                });
    }

    private int drawNavTab(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, boolean active,
                           int mouseX, int mouseY, Runnable onClick) {
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        int bg = active ? 0xFF2B6CB0 : (hover ? 0xFF232C3D : 0xFF161C26);
        g.fill(x, y, x + w, y + h, bg);
        if (active) {
            g.fill(x, y + h - 2, x + w, y + h, 0xFF63B3ED);
        }
        g.centeredText(this.font, Component.literal(label), x + w / 2, y + 6, active ? 0xFFFFFFFF : 0xFFB0BCD0);
        this.pendingHitBoxes.add(new HitBox(x, y, w, h, () -> {
            playClick();
            onClick.run();
        }));
        return x + w;
    }

    private void drawButton(GuiGraphicsExtractor g, int x, int y, int w, int h, String text,
                            int normalBg, int hoverBg, int mouseX, int mouseY, Runnable onClick) {
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        g.fill(x, y, x + w, y + h, hover ? hoverBg : normalBg);
        drawBorder(g, x, y, w, h, hover ? 0xFFFFFFFF : 0x55FFFFFF);
        g.centeredText(this.font, Component.literal(text), x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
        this.pendingHitBoxes.add(new HitBox(x, y, w, h, onClick));
    }

    private void drawPanelCard(GuiGraphicsExtractor g, int x, int y, int w, int h, int headerCol, int bodyCol) {
        drawBorder(g, x - 1, y - 1, w + 2, h + 2, 0xFF2B374D);
        fillVerticalGradient(g, x, y, x + w, y + 44, headerCol, bodyCol);
        g.fill(x, y + 44, x + w, y + h, bodyCol);
    }

    private void drawScaledItem(GuiGraphicsExtractor g, ItemStack stack, int x, int y, float scale) {
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.item(stack, 0, 0);
        g.pose().popMatrix();
    }

    private static void drawBorder(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private static void fillVerticalGradient(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int topArgb, int botArgb) {
        int height = Math.max(1, y2 - y1);
        int bands = Math.min(height, 16);
        int ta = (topArgb >>> 24) & 0xFF, tr = (topArgb >>> 16) & 0xFF, tg = (topArgb >>> 8) & 0xFF, tb = topArgb & 0xFF;
        int ba = (botArgb >>> 24) & 0xFF, br = (botArgb >>> 16) & 0xFF, bg = (botArgb >>> 8) & 0xFF, bb = botArgb & 0xFF;
        for (int i = 0; i < bands; i++) {
            int sy1 = y1 + (i * height) / bands;
            int sy2 = y1 + ((i + 1) * height) / bands;
            float f = bands <= 1 ? 0.0F : i / (float) (bands - 1);
            int a = (int) (ta + (ba - ta) * f);
            int r = (int) (tr + (br - tr) * f);
            int gr = (int) (tg + (bg - tg) * f);
            int b = (int) (tb + (bb - tb) * f);
            int c = (a << 24) | (r << 16) | (gr << 8) | b;
            g.fill(x1, sy1, x2, sy2, c);
        }
    }

    private static void playClick() {
        Minecraft.getInstance().getSoundManager().play(
                SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0F, 0.5F));
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        // Accept primary / secondary (SDL/GLFW left is usually 0; be permissive)
        int btn = event.button();
        if (btn != 0 && btn != 1) {
            return super.mouseClicked(event, doubleClick);
        }

        double mx = event.x();
        double my = event.y();
        int W = this.width;
        int H = this.height;

        // --- Close button (top-right) ---
        int closeX = W - 26;
        if (mx >= closeX && mx < closeX + 18 && my >= 5 && my < 23) {
            playClick();
            this.onClose();
            return true;
        }

        // --- Top nav tabs (same geometry as extractRenderState) ---
        int tx = 10;
        int tabY = 4, tabH = 20;
        // CASES
        if (mx >= tx && mx < tx + 68 && my >= tabY && my < tabY + tabH) {
            playClick();
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.CASES;
            this.subView = CaseSubView.GRID;
            return true;
        }
        tx += 68 + 4;
        // UPGRADER
        if (mx >= tx && mx < tx + 82 && my >= tabY && my < tabY + tabH) {
            playClick();
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("open_upgrader", ""));
            return true;
        }
        tx += 82 + 4;
        // SELL
        if (mx >= tx && mx < tx + 66 && my >= tabY && my < tabY + tabH) {
            playClick();
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.SELL;
            return true;
        }
        tx += 66 + 4;
        // BANK
        if (mx >= tx && mx < tx + 68 && my >= tabY && my < tabY + tabH) {
            playClick();
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.BANK;
            return true;
        }

        int topH = 28;
        int contentTop = topH + 8;
        int contentBot = H - 22;


        if (this.activeTab == Tab.CASES && this.subView == CaseSubView.GRID) {
            // Same layout as renderCaseGrid
            int cols = 4;
            int gap = 10;
            int padX = Math.max(16, (W - 460) / 2);
            int availW = W - padX * 2;
            int cardW = Math.min(118, (availW - gap * (cols - 1)) / cols);
            int totalGridW = cardW * cols + gap * (cols - 1);
            int startX = (W - totalGridW) / 2;
            int availH = contentBot - contentTop - 8;
            int cardH = Math.min(96, (availH - gap) / 2);
            int startY = contentTop + 4;

            for (int i = 0; i < CASE_IDS.length; i++) {
                int col = i % cols;
                int row = i / cols;
                int x = startX + col * (cardW + gap);
                int y = startY + row * (cardH + gap);
                String cid = CASE_IDS[i];

                // info button
                int infoX = x + cardW - 18;
                int infoY = y + cardH - 18;
                if (mx >= infoX && mx < infoX + 14 && my >= infoY && my < infoY + 13) {
                    playClick();
                    this.selectedCaseId = cid;
                    this.subView = CaseSubView.PREVIEW;
                    return true;
                }
                // whole card -> spin
                if (mx >= x && mx < x + cardW && my >= y && my < y + cardH) {
                    playClick();
                    ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", cid));
                    return true;
                }
            }
        }

        // Fallback: last frame hitboxes (preview / spin / sell / bank buttons)
        List<HitBox> boxes = this.hitBoxes;
        if (boxes.isEmpty() && !this.pendingHitBoxes.isEmpty()) {
            boxes = this.pendingHitBoxes;
        }
        for (HitBox hb : boxes) {
            if (hb.contains(mx, my)) {
                hb.onClick().run();
                return true;
            }
        }

        // Debug feedback so we know the click reached the screen
        this.toastText = "點擊已收到 (" + (int) mx + "," + (int) my + ")";
        this.toastError = false;
        this.toastUntilMs = System.currentTimeMillis() + 2000L;
        playClick();
        return true;
    }
}
