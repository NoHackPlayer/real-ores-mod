package com.example.randomoredrop;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ComputerScreen extends Screen {
    private static final String[] CASE_IDS = {
            "starter", "miner", "gem", "explorer", "titanium", "tungsten", "netherite", "legendary"
    };

    private static final int[] CASE_TOP_COLORS = {
            0xFF8B561B, 0xFF217A4B, 0xFF187399, 0xFF6B3199,
            0xFF2E5C9E, 0xFF9C7418, 0xFF96202B, 0xFFC49216
    };

    private static final int[] CASE_BOT_COLORS = {
            0xFF281D13, 0xFF13261C, 0xFF11232C, 0xFF20152D,
            0xFF121E33, 0xFF2B2210, 0xFF2A1216, 0xFF33260E
    };

    private static final int[] TIER_ARGB = {
            0xFF4B69FF, 0xFF8847FF, 0xFFD32CE6, 0xFFEB4B4B, 0xFFFFD700
    };

    private static final int[] TIER_BG = {
            0xFF1A2238, 0xFF241B38, 0xFF301A36, 0xFF361A1E, 0xFF3B3014
    };

    private enum Tab { CASES, UPGRADER, STOCKS, SELL, BANK }
    private enum CaseSubView { GRID, PREVIEW, SPIN }

    private Tab activeTab = Tab.CASES;
    private CaseSubView subView = CaseSubView.GRID;
    private String selectedCaseId = "starter";

    private long balanceCents;
    private Component toastComp = Component.empty();
    private boolean toastError = false;
    private long toastUntilMs = 0L;
    private int openedThisSession = 0;
    private final java.util.Set<Integer> selectedSellSlots = new java.util.LinkedHashSet<>();
    private boolean confirmSellArmed = false;
    private List<StockMarket.StockSnapshot> stockList = new ArrayList<>();
    private int selectedStockIdx = 0;
    private int stockAutoSyncTicks = 0;
    private long lastStockSyncMs = 0L;
    private boolean stockShortMode = false;

    private int upgInputSlot = -1;
    private final List<Item> upgCatalog = new ArrayList<>();
    private int upgTargetIdx = 0;
    private int upgTargetQty = 1;
    private double upgZoneStart = 0.0;
    private boolean upgDraggingBar = false;
    private boolean upgPickingTarget = false;
    private int upgCatalogPage = 0;
    private String upgSearchQuery = "";
    private EditBox upgSearchBox = null;
    private boolean upgRolling = false;
    private boolean upgFinished = false;
    private boolean upgClaimed = true;
    private boolean upgWon = false;
    private double upgChancePct = 0.0;
    private double upgRollPos = 0.5;
    private long upgStartMs = 0L;
    private static final long UPG_DURATION_MS = 2200L;

    private static final int REEL_TOTAL = 56;
    private static final int WIN_IDX = 46;
    private static final long SPIN_DURATION_MS = 4600L;
    private final List<ComputerActions.CaseEntry> spinReel = new ArrayList<>();
    private long spinStartMs = 0L;
    private boolean spinFinished = false;
    private boolean spinClaimed = false;
    private int lastTickCard = -1;
    private long lastSpinCostCents = 0L;
    private long lastWinValCents = 0L;
    private int lastWinTier = 0;
    private ItemStack lastWinStack = ItemStack.EMPTY;

    public ComputerScreen(long initialBalanceCents) {
        super(Component.translatable("ui.randomoredrop.title"));
        this.balanceCents = initialBalanceCents;
    }

    private void addClickZone(int x, int y, int w, int h, Runnable action) {
        this.addWidget(Button.builder(Component.empty(), btn -> action.run()).bounds(x, y, w, h).build());
    }

    @Override
    protected void init() {
        super.init();
        int W = this.width;
        int H = this.height;
        int topH = 28;
        int contentTop = topH + 8;
        int contentBot = H - 22;

        int tx = 8;
        addClickZone(tx, 4, 54, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.CASES;
            this.subView = CaseSubView.GRID;
            this.rebuildWidgets();
        });
        tx += 57;
        addClickZone(tx, 4, 66, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            if (this.upgRolling && !this.upgClaimed) finishUpgradeNow();
            this.activeTab = Tab.UPGRADER;
            rebuildUpgradeCatalog();
            this.rebuildWidgets();
        });
        tx += 69;
        addClickZone(tx, 4, 58, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.STOCKS;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("sync_stocks", ""));
            this.rebuildWidgets();
        });
        tx += 61;
        addClickZone(tx, 4, 48, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.SELL;
            this.rebuildWidgets();
        });
        tx += 51;
        addClickZone(tx, 4, 50, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.BANK;
            this.rebuildWidgets();
        });

        addClickZone(W - 26, 5, 18, 18, this::onClose);

        if (this.activeTab == Tab.CASES) {
            if (this.subView == CaseSubView.GRID) {
                int cols = 4, gap = 10;
                int padX = Math.max(16, (W - 460) / 2);
                int cardW = Math.min(118, (W - padX * 2 - gap * (cols - 1)) / cols);
                int startX = (W - (cardW * cols + gap * (cols - 1))) / 2;
                int availH = contentBot - contentTop - 8;
                int cardH = Math.min(96, (availH - gap) / 2);
                int startY = contentTop + Math.max(4, (availH - (cardH * 2 + gap)) / 2);

                for (int i = 0; i < CASE_IDS.length; i++) {
                    String cid = CASE_IDS[i];
                    int x = startX + (i % cols) * (cardW + gap);
                    int y = startY + (i / cols) * (cardH + gap);
                    int infoX = x + cardW - 18;
                    int infoY = y + cardH - 15;
                    addClickZone(infoX, infoY, 14, 13, () -> {
                        this.selectedCaseId = cid;
                        this.subView = CaseSubView.PREVIEW;
                        this.rebuildWidgets();
                    });
                    addClickZone(x, y, cardW, cardH, () ->
                            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", cid)));
                }
            } else if (this.subView == CaseSubView.PREVIEW) {
                int hx = Math.max(16, (W - 440) / 2);
                int hw = W - hx * 2;
                addClickZone(hx + 6, contentTop + 5, 58, 18, () -> {
                    this.subView = CaseSubView.GRID;
                    this.rebuildWidgets();
                });
                addClickZone(hx + hw - 96, contentTop + 5, 90, 18, () ->
                        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", this.selectedCaseId)));
            } else {
                int trackH = 88;
                int trackY = contentTop + Math.max(18, (contentBot - contentTop - trackH - 60) / 2);
                int btnY = trackY + trackH + 14;
                if (!this.spinFinished) {
                    addClickZone(W / 2 - 58, btnY, 116, 22, this::finishSpinNow);
                } else {
                    int rowY = btnY + 16;
                    addClickZone(W / 2 - 135, rowY, 85, 22, () -> {
                        this.subView = CaseSubView.GRID;
                        this.rebuildWidgets();
                    });
                    addClickZone(W / 2 - 42, rowY, 96, 22, () ->
                            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", this.selectedCaseId)));
                    addClickZone(W / 2 + 62, rowY, 76, 22, () -> {
                        this.subView = CaseSubView.PREVIEW;
                        this.rebuildWidgets();
                    });
                }
            }
        } else if (this.activeTab == Tab.UPGRADER) {
            rebuildUpgradeCatalog();
            int padX = Math.max(12, (W - 440) / 2);
            int totalW = W - padX * 2;
            int topPanelH = 86;
            int boxW = Math.min(126, (totalW - 24) / 3);
            int midW = totalW - boxW * 2 - 16;
            int midX = padX + boxW + 8;
            int rightX = midX + midW + 8;

            // Native invisible AbstractSliderButton directly over the green/red bar -> 100% smooth 26.3 drag & click!
            int barX = midX + 8;
            int barY = contentTop + 18;
            int barW = midW - 16;
            int barH = 18;
            double initFrac = getCurrentUpgradeChanceFrac();
            double initSlider = (initFrac > 0.0 && initFrac < 1.0) ? Math.max(0.0, Math.min(1.0, this.upgZoneStart / (1.0 - initFrac))) : 0.0;
            this.addWidget(new AbstractSliderButton(barX, barY, barW, barH, Component.empty(), initSlider) {
                @Override protected void updateMessage() {}
                @Override protected void applyValue() {
                    if (!ComputerScreen.this.upgRolling && !ComputerScreen.this.upgFinished) {
                        double f = ComputerScreen.this.getCurrentUpgradeChanceFrac();
                        if (f > 0.0 && f < 1.0) {
                            ComputerScreen.this.upgZoneStart = Math.max(0.0, Math.min(1.0 - f, this.value * (1.0 - f)));
                        }
                    }
                }
            });

            addClickZone(midX + 6, contentTop + topPanelH - 22, midW - 12, 19, this::handleUpgradeClick);

            // Target <, >, Target Icon, Row 1 (- / Pick / +), Row 2 (10 / 50 / 100)
            addClickZone(rightX + 4, contentTop + 17, 16, 20, () -> cycleUpgradeTarget(-1));
            addClickZone(rightX + boxW - 20, contentTop + 17, 16, 20, () -> cycleUpgradeTarget(1));
            addClickZone(rightX + boxW / 2 - 11, contentTop + 15, 22, 22, () -> {
                this.upgPickingTarget = !this.upgPickingTarget;
                this.upgCatalogPage = 0;
                this.rebuildWidgets();
            });
            int row1Y = contentTop + topPanelH - 32;
            int row2Y = contentTop + topPanelH - 16;
            addClickZone(rightX + 4, row1Y, 18, 13, () -> adjustUpgradeQty(-1));
            addClickZone(rightX + boxW - 22, row1Y, 18, 13, () -> adjustUpgradeQty(1));
            addClickZone(rightX + 25, row1Y, boxW - 50, 13, () -> {
                this.upgPickingTarget = !this.upgPickingTarget;
                this.upgCatalogPage = 0;
                this.rebuildWidgets();
            });
            int[] quickQtys = {10, 50, 100};
            int qbw = (boxW - 12) / 3;
            for (int q = 0; q < 3; q++) {
                int targetQ = quickQtys[q];
                addClickZone(rightX + 4 + q * (qbw + 2), row2Y, qbw, 13, () -> setUpgradeQty(targetQ));
            }

            int slotSz = 19, slotGap = 2;
            int gridW = 9 * slotSz + 8 * slotGap;
            int gx = (W - gridW) / 2;
            int gy = contentTop + topPanelH + 14;
            this.upgSearchBox = null;
            if (!this.upgPickingTarget) {
                for (int r = 0; r < 4; r++) {
                    int y = gy + r * (slotSz + slotGap) + (r == 3 ? 3 : 0);
                    for (int c = 0; c < 9; c++) {
                        int invIdx = (r < 3) ? (9 + r * 9 + c) : c;
                        int x = gx + c * (slotSz + slotGap);
                        addClickZone(x, y, slotSz, slotSz, () -> selectUpgradeInputSlot(invIdx));
                    }
                }
            } else {
                this.upgSearchBox = new EditBox(this.font, gx + 70, gy - 14, gridW - 126, 12,
                        Component.translatable("ui.randomoredrop.upg_search_hint"));
                this.upgSearchBox.setHint(Component.translatable("ui.randomoredrop.upg_search_hint"));
                this.upgSearchBox.setMaxLength(32);
                this.upgSearchBox.setValue(this.upgSearchQuery);
                this.upgSearchBox.setResponder(q -> {
                    this.upgSearchQuery = q == null ? "" : q;
                    this.upgCatalogPage = 0;
                    rebuildUpgradeCatalog();
                });
                this.addWidget(this.upgSearchBox);

                addClickZone(gx + gridW - 52, gy - 13, 24, 12, () -> {
                    if (this.upgCatalogPage > 0) this.upgCatalogPage--;
                });
                addClickZone(gx + gridW - 26, gy - 13, 26, 12, () -> {
                    int maxPage = Math.max(0, (this.upgCatalog.size() - 1) / 36);
                    if (this.upgCatalogPage < maxPage) this.upgCatalogPage++;
                });
                for (int r = 0; r < 4; r++) {
                    int y = gy + r * (slotSz + slotGap);
                    for (int c = 0; c < 9; c++) {
                        int offset = r * 9 + c;
                        int x = gx + c * (slotSz + slotGap);
                        addClickZone(x, y, slotSz, slotSz, () -> {
                            int idx = this.upgCatalogPage * 36 + offset;
                            if (idx >= 0 && idx < this.upgCatalog.size()) {
                                this.upgTargetIdx = idx;
                                Item chosen = this.upgCatalog.get(idx);
                                this.upgTargetQty = getMinValidQty(chosen, getSelectedUpgradeInputCents());
                                this.upgPickingTarget = false;
                                this.upgSearchQuery = "";
                                this.rebuildWidgets();
                            }
                        });
                    }
                }
            }
        } else if (this.activeTab == Tab.STOCKS) {
            int padX = Math.max(10, (W - 460) / 2);
            int totalW = W - padX * 2;
            int listW = Math.min(122, totalW / 3);
            int rightX = padX + listW + 8;
            int rightW = totalW - listW - 8;
            int availH = contentBot - contentTop;
            int rowH = Math.max(14, Math.min(19, (availH - 4) / 10));

            for (int i = 0; i < 10; i++) {
                int idx = i;
                addClickZone(padX, contentTop + i * rowH, listW, rowH - 1, () -> {
                    this.selectedStockIdx = idx;
                });
            }
            // Long/Short mode toggle button + Refresh button in top-right of stock header
            addClickZone(rightX + rightW - 134, contentTop + 3, 74, 16, () -> {
                this.stockShortMode = !this.stockShortMode;
            });
            addClickZone(rightX + rightW - 56, contentTop + 3, 52, 16, () ->
                    ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("refresh_stocks", "")));

            // 6 Order buttons along bottom of right panel: Open 1 / 10 / 100 | Close 1 / 10 / All
            int btnY = contentBot - 22;
            int gap = 4;
            int bw = (rightW - gap * 5) / 6;
            String[] qtys = {"1", "10", "100", "1", "10", "0"};
            for (int b = 0; b < 6; b++) {
                boolean isOpen = b < 3;
                String q = qtys[b];
                addClickZone(rightX + b * (bw + gap), btnY, bw, 20, () -> {
                    if (!this.stockList.isEmpty()) {
                        String sym = this.stockList.get(Math.min(this.selectedStockIdx, this.stockList.size() - 1)).symbol();
                        String act = this.stockShortMode
                                ? (isOpen ? "short_stock" : "cover_stock")
                                : (isOpen ? "buy_stock" : "sell_stock");
                        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload(act, sym + ":" + q));
                    }
                });
            }
        } else if (this.activeTab == Tab.SELL) {
            int slotSz = 22, slotGap = 3;
            int gridW = 9 * slotSz + 8 * slotGap;
            int panelW = Math.min(145, Math.max(115, W - gridW - 40));
            int totalW = gridW + 14 + panelW;
            int startX = (W - totalW) / 2;
            int gridH = 4 * slotSz + 3 * slotGap + 8;
            int startY = contentTop + Math.max(18, (contentBot - contentTop - gridH) / 2);

            // 27 main inventory slots (indices 9..35) in rows 0..2, plus 9 hotbar slots (0..8) in row 3
            for (int r = 0; r < 4; r++) {
                int y = startY + r * (slotSz + slotGap) + (r == 3 ? 6 : 0);
                for (int c = 0; c < 9; c++) {
                    int invIdx = (r < 3) ? (9 + r * 9 + c) : c;
                    int x = startX + c * (slotSz + slotGap);
                    addClickZone(x, y, slotSz, slotSz, () -> toggleSellSlot(invIdx));
                }
            }

            // Right-side action panel buttons (Select Minerals removed)
            int px = startX + gridW + 14;
            addClickZone(px + 8, startY + 42, panelW - 16, 18, () -> {
                this.selectedSellSlots.clear();
                this.confirmSellArmed = false;
            });
            addClickZone(px + 8, startY + 68, panelW - 16, 22, this::handleSellConfirmClick);
        } else {
            String[] args = {"1", "10", "100", "1000", "10000"};
            int gap = 8;
            int cardW = Math.min(78, (W - 40 - gap * 4) / 5);
            int cardH = 92;
            int totalW = cardW * 5 + gap * 4;
            int startX = (W - totalW) / 2;
            int y = contentTop + Math.max(12, (contentBot - contentTop - cardH - 42) / 2);

            for (int i = 0; i < 5; i++) {
                int x = startX + i * (cardW + gap);
                String arg = args[i];
                addClickZone(x + 8, y + cardH - 24, cardW - 16, 18, () ->
                        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("withdraw", arg)));
            }
            addClickZone(startX, y + cardH + 14, totalW, 24, () ->
                    ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("deposit_all", "")));
        }
    }

    public void updateStocks(long newBalanceCents, List<StockMarket.StockSnapshot> stocks) {
        this.balanceCents = newBalanceCents;
        this.stockList = stocks != null ? stocks : new ArrayList<>();
        this.lastStockSyncMs = System.currentTimeMillis();
        if (this.selectedStockIdx >= this.stockList.size()) {
            this.selectedStockIdx = 0;
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.activeTab == Tab.STOCKS) {
            if (++this.stockAutoSyncTicks >= 200) { // Auto-sync every 10 seconds while watching K-line
                this.stockAutoSyncTicks = 0;
                ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("sync_stocks", ""));
            }
        }
    }

    public void updateBalance(long newBalanceCents, String msgKey, String arg1, String arg2, boolean isError) {
        this.balanceCents = newBalanceCents;
        if (msgKey != null && !msgKey.isEmpty()) {
            this.toastComp = Component.translatable(msgKey, arg1, arg2);
            this.toastError = isError;
            this.toastUntilMs = System.currentTimeMillis() + 4500L;
        }
    }

    public void startSpin(ComputerNetwork.SpinResultPayload payload) {
        this.balanceCents = payload.newBalanceCents();
        this.selectedCaseId = payload.caseId();
        this.lastSpinCostCents = payload.costCents();
        this.lastWinValCents = payload.winValueCents();
        this.lastWinTier = payload.winTier();

        Item winItem = BuiltInRegistries.ITEM.getOptional(Identifier.parse(payload.winItemId())).orElse(Items.DIAMOND);
        this.lastWinStack = new ItemStack(winItem, payload.winCount());
        if (payload.winDamage() > 0 && this.lastWinStack.isDamageableItem()) {
            this.lastWinStack.setDamageValue(Math.min(this.lastWinStack.getMaxDamage() - 1, payload.winDamage()));
        }

        this.spinReel.clear();
        RandomSource rng = RandomSource.create();
        for (int i = 0; i < REEL_TOTAL; i++) {
            if (i == WIN_IDX) {
                this.spinReel.add(ComputerActions.makeEntryForClient(this.lastWinStack, payload.winTier()));
            } else {
                this.spinReel.add(ComputerActions.rollCaseEntry(payload.caseId(), rng));
            }
        }
        this.spinStartMs = System.currentTimeMillis();
        this.spinFinished = false;
        this.spinClaimed = false;
        this.lastTickCard = -1;
        this.activeTab = Tab.CASES;
        this.subView = CaseSubView.SPIN;
        this.openedThisSession++;
        this.rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        if (this.upgRolling && !this.upgClaimed) finishUpgradeNow();
        if (this.subView == CaseSubView.SPIN && !this.spinClaimed) {
            this.spinClaimed = true;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("claim_spin", ""));
        }
        super.onClose();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        int W = this.width;
        int H = this.height;

        g.fill(0, 0, W, H, 0xF00F131A);

        int topH = 28;
        g.fill(0, 0, W, topH, 0xFF161C26);
        g.fill(0, topH - 1, W, topH, 0xFF283244);

        int tx = 8;
        drawNavTabVisual(g, tx, 4, 54, 20, Component.translatable("ui.randomoredrop.tab.cases"), this.activeTab == Tab.CASES, mouseX, mouseY);
        tx += 57;
        drawNavTabVisual(g, tx, 4, 66, 20, Component.translatable("ui.randomoredrop.tab.upgrader"), this.activeTab == Tab.UPGRADER, mouseX, mouseY);
        tx += 69;
        drawNavTabVisual(g, tx, 4, 58, 20, Component.translatable("ui.randomoredrop.tab.stocks"), this.activeTab == Tab.STOCKS, mouseX, mouseY);
        tx += 61;
        drawNavTabVisual(g, tx, 4, 48, 20, Component.translatable("ui.randomoredrop.tab.sell"), this.activeTab == Tab.SELL, mouseX, mouseY);
        tx += 51;
        drawNavTabVisual(g, tx, 4, 50, 20, Component.translatable("ui.randomoredrop.tab.bank"), this.activeTab == Tab.BANK, mouseX, mouseY);

        Component balComp = Component.translatable("ui.randomoredrop.balance", ModEconomy.formatCents(this.balanceCents))
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
        int balW = this.font.width(balComp);
        int closeX = W - 26;
        g.fill(closeX - balW - 18, 5, closeX - 6, 23, 0xFF1F2735);
        g.text(this.font, balComp, closeX - balW - 12, 10, 0xFFFFD54F, true);

        boolean closeHover = mouseX >= closeX && mouseX < closeX + 18 && mouseY >= 5 && mouseY < 23;
        g.fill(closeX, 5, closeX + 18, 23, closeHover ? 0xFFB83232 : 0xFF252D3D);
        g.centeredText(this.font, Component.literal("X"), closeX + 9, 10, 0xFFFFFFFF);

        int contentTop = topH + 8;
        int contentBot = H - 22;
        if (this.activeTab == Tab.CASES) {
            if (this.subView == CaseSubView.GRID) {
                renderCaseGrid(g, contentTop, contentBot, mouseX, mouseY);
            } else if (this.subView == CaseSubView.PREVIEW) {
                renderCasePreview(g, contentTop, contentBot, mouseX, mouseY);
            } else {
                renderCaseSpin(g, contentTop, contentBot, mouseX, mouseY);
            }
        } else if (this.activeTab == Tab.UPGRADER) {
            renderUpgraderTab(g, contentTop, contentBot, mouseX, mouseY, partialTick);
        } else if (this.activeTab == Tab.STOCKS) {
            renderStocksTab(g, contentTop, contentBot, mouseX, mouseY);
        } else if (this.activeTab == Tab.SELL) {
            renderSellTab(g, contentTop, contentBot, mouseX, mouseY);
        } else {
            renderBankTab(g, contentTop, contentBot, mouseX, mouseY);
        }

        int botY = H - 20;
        g.fill(0, botY, W, H, 0xFF141923);
        g.fill(0, botY, W, botY + 1, 0xFF283244);
        g.text(this.font, Component.translatable("ui.randomoredrop.esc_close"), 10, botY + 6, 0xFF8B97AD, false);

        if (System.currentTimeMillis() < this.toastUntilMs && !this.toastComp.getString().isEmpty()) {
            int col = this.toastError ? 0xFFFF6B6B : 0xFF5CE08C;
            g.centeredText(this.font, this.toastComp, W / 2, botY + 6, col);
        } else if (this.activeTab == Tab.CASES) {
            g.centeredText(this.font, Component.translatable("ui.randomoredrop.footer_hint"), W / 2, botY + 6, 0xFF6E7B91);
        }

        Component sess = Component.translatable("ui.randomoredrop.opened_session", this.openedThisSession);
        g.text(this.font, sess, W - this.font.width(sess) - 10, botY + 6, 0xFF8B97AD, false);
    }

    private void renderCaseGrid(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        int cols = 4, gap = 10;
        int padX = Math.max(16, (W - 460) / 2);
        int cardW = Math.min(118, (W - padX * 2 - gap * (cols - 1)) / cols);
        int startX = (W - (cardW * cols + gap * (cols - 1))) / 2;
        int availH = bot - top - 8;
        int cardH = Math.min(96, (availH - gap) / 2);
        int startY = top + Math.max(4, (availH - (cardH * 2 + gap)) / 2);

        for (int i = 0; i < CASE_IDS.length; i++) {
            String cid = CASE_IDS[i];
            ComputerActions.CaseDef def = ComputerActions.getCaseDef(cid);
            int x = startX + (i % cols) * (cardW + gap);
            int y = startY + (i / cols) * (cardH + gap);

            int bannerH = (int) (cardH * 0.56);
            boolean cardHover = mouseX >= x && mouseX < x + cardW && mouseY >= y && mouseY < y + cardH;

            drawBorder(g, x - 1, y - 1, cardW + 2, cardH + 2, cardHover ? 0xFF58A6FF : 0xFF263042);
            fillVerticalGradient(g, x, y, x + cardW, y + bannerH, CASE_TOP_COLORS[i], CASE_BOT_COLORS[i]);
            g.fill(x, y + bannerH, x + cardW, y + cardH, cardHover ? 0xFF212A3A : 0xFF19202D);

            drawScaledItem(g, new ItemStack(def.icon()), x + cardW / 2 - 16, y + bannerH / 2 - 16, 2.0F);

            g.text(this.font, Component.translatable("case.randomoredrop." + cid).withStyle(ChatFormatting.WHITE),
                    x + 6, y + bannerH + 5, 0xFFFFFFFF, true);
            g.text(this.font, Component.literal("* " + ModEconomy.formatCents(def.costCents())).withStyle(ChatFormatting.GOLD),
                    x + 6, y + bannerH + 17, 0xFFFFD54F, false);

            int infoX = x + cardW - 18;
            int infoY = y + cardH - 15;
            boolean infoHover = mouseX >= infoX && mouseX < infoX + 14 && mouseY >= infoY && mouseY < infoY + 13;
            g.fill(infoX, infoY, infoX + 14, infoY + 13, infoHover ? 0xFF3B82F6 : 0xFF293448);
            g.centeredText(this.font, Component.literal("i"), infoX + 7, infoY + 2, 0xFFFFFFFF);

            Component openLbl = (cardHover && !infoHover)
                    ? Component.translatable("ui.randomoredrop.click_open")
                    : Component.translatable("ui.randomoredrop.open_short");
            g.text(this.font, openLbl, x + 6, y + cardH - 12, cardHover && !infoHover ? 0xFF5CE08C : 0xFF7D8AA3, false);
        }
    }

    private void renderCasePreview(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        ComputerActions.CaseDef def = ComputerActions.getCaseDef(this.selectedCaseId);

        int hx = Math.max(16, (W - 440) / 2);
        int hw = W - hx * 2;
        g.fill(hx, top, hx + hw, top + 28, 0xFF18202E);
        drawBorder(g, hx, top, hw, 28, 0xFF2B374D);

        drawButtonVisual(g, hx + 6, top + 5, 58, 18, Component.translatable("ui.randomoredrop.back"), 0xFF263145, 0xFF354460, mouseX, mouseY);

        g.text(this.font, Component.translatable("ui.randomoredrop.preview_header",
                        Component.translatable("case.randomoredrop." + this.selectedCaseId),
                        ModEconomy.formatCents(def.costCents()))
                .withStyle(def.titleColor(), ChatFormatting.BOLD), hx + 72, top + 5, 0xFFFFFFFF, true);
        g.text(this.font, Component.translatable("ui.randomoredrop.odds_legend"),
                hx + 72, top + 16, 0xFF94A3B8, false);

        drawButtonVisual(g, hx + hw - 96, top + 5, 90, 18, Component.translatable("ui.randomoredrop.open_now"), 0xFF1F7A46, 0xFF29A05C, mouseX, mouseY);

        List<ComputerActions.PreviewEntry> entries = ComputerActions.getPreviewEntries(this.selectedCaseId);
        int cols = 5, gap = 6;
        int cardW = (hw - gap * (cols - 1)) / cols;
        int gridTop = top + 34;
        int rows = (entries.size() + cols - 1) / cols;
        int cardH = Math.min(40, Math.max(28, (bot - gridTop - gap * (rows - 1)) / Math.max(1, rows)));

        List<Component> hoveredTooltip = null;
        for (int i = 0; i < entries.size(); i++) {
            ComputerActions.PreviewEntry e = entries.get(i);
            int x = hx + (i % cols) * (cardW + gap);
            int y = gridTop + (i / cols) * (cardH + gap);
            if (y + cardH > bot) break;

            int tierCol = TIER_ARGB[Math.min(4, e.tierIndex())];
            int bgCol = TIER_BG[Math.min(4, e.tierIndex())];
            boolean hover = mouseX >= x && mouseX < x + cardW && mouseY >= y && mouseY < y + cardH;

            g.fill(x, y, x + cardW, y + cardH, hover ? 0xFF253045 : bgCol);
            g.fill(x, y + cardH - 3, x + cardW, y + cardH, tierCol);
            drawBorder(g, x, y, cardW, cardH, hover ? tierCol : 0xFF2A3448);

            ItemStack st = new ItemStack(e.item(), e.minCount());
            g.item(st, x + 5, y + (cardH - 18) / 2);

            String nm = st.getHoverName().getString();
            if (nm.length() > 8) nm = nm.substring(0, 7) + "..";
            g.text(this.font, Component.literal(nm), x + 25, y + 6, 0xFFFFFFFF, false);
            long minV = ModEconomy.getCents(e.item()) * e.minCount();
            g.text(this.font, Component.literal("* " + ModEconomy.formatCents(minV)), x + 25, y + 17, 0xFFFFD54F, false);

            if (hover) {
                long maxV = ModEconomy.getCents(e.item()) * e.maxCount();
                Component cntComp = e.minCount() == e.maxCount()
                        ? Component.translatable("ui.randomoredrop.qty_single", e.minCount())
                        : Component.translatable("ui.randomoredrop.qty_range", e.minCount(), e.maxCount());
                Component valComp = minV == maxV
                        ? Component.translatable("ui.randomoredrop.val_single", ModEconomy.formatCents(minV))
                        : Component.translatable("ui.randomoredrop.val_range", ModEconomy.formatCents(minV), ModEconomy.formatCents(maxV));
                hoveredTooltip = List.of(
                        st.getHoverName().copy().withStyle(e.color(), ChatFormatting.BOLD),
                        Component.translatable("ui.randomoredrop.tier_line",
                                Component.translatable(ComputerActions.rarityKey(e.tierIndex())), e.chanceText()).withStyle(e.color()),
                        cntComp.copy().withStyle(ChatFormatting.WHITE),
                        valComp.copy().withStyle(ChatFormatting.GOLD)
                );
            }
        }
        if (hoveredTooltip != null) {
            g.setTooltipForNextFrame(this.font, hoveredTooltip, Optional.empty(), mouseX, mouseY);
        }
    }

    private void renderCaseSpin(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        long elapsed = System.currentTimeMillis() - this.spinStartMs;
        double t = Math.min(1.0, elapsed / (double) SPIN_DURATION_MS);
        if (this.spinFinished) t = 1.0;

        double eased = 1.0 - Math.pow(1.0 - t, 4.0);

        int trackW = Math.min(440, W - 32);
        int trackX = (W - trackW) / 2;
        int trackH = 88;
        int trackY = top + Math.max(18, (bot - top - trackH - 60) / 2);
        int centerX = trackX + trackW / 2;

        Component spinHeader = Component.translatable(
                this.spinFinished ? "ui.randomoredrop.spin_done" : "ui.randomoredrop.spinning",
                Component.translatable("case.randomoredrop." + this.selectedCaseId)
        ).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
        g.centeredText(this.font, spinHeader, W / 2, trackY - 16, 0xFFFFD54F);

        g.fill(trackX - 2, trackY - 2, trackX + trackW + 2, trackY + trackH + 2, 0xFF283347);
        g.fill(trackX, trackY, trackX + trackW, trackY + trackH, 0xFF0C1017);

        int cardW = 64, cardGap = 6, stepPx = cardW + cardGap;
        double startOffset = 2.0 * stepPx;
        double targetOffset = WIN_IDX * (double) stepPx;
        double currentPos = startOffset + (targetOffset - startOffset) * eased;

        int curCard = (int) Math.round(currentPos / stepPx);
        if (!this.spinFinished && curCard != this.lastTickCard) {
            this.lastTickCard = curCard;
            try {
                float pitch = (float) (1.55 - 0.65 * t);
                Minecraft.getInstance().getSoundManager().play(
                        SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_HAT.value(), pitch, 0.55F));
            } catch (Throwable ignored) {}
        }

        for (int i = 0; i < this.spinReel.size(); i++) {
            int cx = (int) Math.round(centerX + (i * stepPx - currentPos) - cardW / 2.0);
            if (cx + cardW < trackX + 2 || cx > trackX + trackW - 2) continue;
            int drawL = Math.max(cx, trackX + 2);
            int drawR = Math.min(cx + cardW, trackX + trackW - 2);
            if (drawR <= drawL) continue;

            ComputerActions.CaseEntry entry = this.spinReel.get(i);
            int tierCol = TIER_ARGB[Math.min(4, entry.tierIndex())];
            int bgCol = TIER_BG[Math.min(4, entry.tierIndex())];
            int cy = trackY + 6;
            int ch = trackH - 12;

            g.fill(drawL, cy, drawR, cy + ch, bgCol);
            g.fill(drawL, cy + ch - 4, drawR, cy + ch, tierCol);
            if (cx >= trackX + 2 && cx + cardW <= trackX + trackW - 2) {
                boolean isWinnerNow = this.spinFinished && i == WIN_IDX;
                drawBorder(g, cx, cy, cardW, ch, isWinnerNow ? 0xFFFFD700 : 0xFF2A364B);
                drawScaledItem(g, entry.stack(), cx + cardW / 2 - 16, cy + 10, 2.0F);
                String lbl = entry.stack().getHoverName().getString();
                if (lbl.length() > 8) lbl = lbl.substring(0, 7) + "..";
                g.centeredText(this.font, Component.literal(lbl), cx + cardW / 2, cy + ch - 16, 0xFFE2E8F0);
            }
        }

        g.fill(centerX - 1, trackY, centerX + 1, trackY + trackH, 0xFFFFD700);
        g.fill(centerX - 5, trackY, centerX + 6, trackY + 4, 0xFFFFD700);
        g.fill(centerX - 5, trackY + trackH - 4, centerX + 6, trackY + trackH, 0xFFFFD700);

        if (t >= 1.0 && !this.spinFinished) {
            finishSpinNow();
        }

        int btnY = trackY + trackH + 14;
        if (!this.spinFinished) {
            drawButtonVisual(g, W / 2 - 58, btnY, 116, 22, Component.translatable("ui.randomoredrop.skip"), 0xFF28507A, 0xFF356CA3, mouseX, mouseY);
        } else {
            int tierCol = TIER_ARGB[Math.min(4, this.lastWinTier)];
            long diff = this.lastWinValCents - this.lastSpinCostCents;
            String diffTxt = (diff >= 0 ? "+" : "") + ModEconomy.formatCents(diff);
            Component wearComp = ComputerActions.formatWearComponent(this.lastWinStack);
            Component winComp = Component.translatable(
                    "ui.randomoredrop.win_banner",
                    this.lastWinStack.getHoverName(),
                    this.lastWinStack.getCount(),
                    wearComp,
                    ModEconomy.formatCents(this.lastWinValCents),
                    diffTxt
            );
            g.centeredText(this.font, winComp, W / 2, btnY, tierCol);

            int rowY = btnY + 16;
            drawButtonVisual(g, W / 2 - 135, rowY, 85, 22, Component.translatable("ui.randomoredrop.back_cases"), 0xFF263145, 0xFF364663, mouseX, mouseY);
            drawButtonVisual(g, W / 2 - 42, rowY, 96, 22, Component.translatable("ui.randomoredrop.spin_again"), 0xFF1F7A46, 0xFF29A05C, mouseX, mouseY);
            drawButtonVisual(g, W / 2 + 62, rowY, 76, 22, Component.translatable("ui.randomoredrop.preview_btn"), 0xFF4B3278, 0xFF63439C, mouseX, mouseY);
        }
    }

    private void finishSpinNow() {
        boolean wasFinished = this.spinFinished;
        this.spinFinished = true;
        if (!this.spinClaimed) {
            this.spinClaimed = true;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("claim_spin", ""));
        }
        if (!wasFinished) {
            this.rebuildWidgets();
        }
    }

    public void startUpgradeRoll(ComputerNetwork.UpgradeResultPayload payload) {
        this.upgRolling = true;
        this.upgFinished = false;
        this.upgClaimed = false;
        this.upgDraggingBar = false;
        this.upgWon = payload.success();
        this.upgChancePct = payload.chancePct();
        this.upgZoneStart = payload.zoneStart();
        this.upgRollPos = payload.rollPos();
        this.upgStartMs = System.currentTimeMillis();
        this.upgInputSlot = -1;
    }

    private void finishUpgradeNow() {
        if (!this.upgClaimed) {
            this.upgClaimed = true;
            this.upgFinished = true;
            this.upgRolling = false;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("claim_upgrade", ""));
            if (this.minecraft != null && this.minecraft.player != null) {
                this.minecraft.player.playSound(this.upgWon ? SoundEvents.PLAYER_LEVELUP : SoundEvents.VILLAGER_NO, 0.8F, this.upgWon ? 1.25F : 0.9F);
            }
        }
    }

    private long getTargetUnitCents(Item item) {
        if (item == null) return 0L;
        return ModEconomy.getStackCents(new ItemStack(item, 1));
    }

    private int getMaxAllowedQty(Item item, long inCents) {
        if (item == null) return 1;
        int hardMax = item.getDefaultMaxStackSize() > 1 ? 128 : 1;
        if (inCents <= 0L) return hardMax;
        long unit = getTargetUnitCents(item);
        if (unit <= 0L) return 1;
        long cap128x = (inCents * 128L) / unit;
        return (int) Math.max(1L, Math.min(hardMax, cap128x));
    }

    private int getMinValidQty(Item item, long inCents) {
        if (item == null || inCents <= 0L) return 1;
        long unit = getTargetUnitCents(item);
        if (unit <= 0L) return 1;
        return (int) (inCents / unit) + 1;
    }

    private double getCurrentUpgradeChanceFrac() {
        long inCents = getSelectedUpgradeInputCents();
        if (inCents <= 0L || this.upgCatalog.isEmpty()) return 0.0;
        Item tgt = this.upgCatalog.get(Math.min(this.upgTargetIdx, this.upgCatalog.size() - 1));
        long tgtCents = getTargetUnitCents(tgt) * this.upgTargetQty;
        if (tgtCents <= inCents) return 0.0;
        return Math.max(0.007, Math.min(0.80, (inCents / (double) tgtCents) * 0.90));
    }

    private void adjustUpgradeQty(int delta) {
        if (this.upgCatalog.isEmpty()) return;
        Item tgt = this.upgCatalog.get(Math.min(this.upgTargetIdx, this.upgCatalog.size() - 1));
        long inCents = getSelectedUpgradeInputCents();
        int minQ = getMinValidQty(tgt, inCents);
        int maxQ = Math.max(minQ, getMaxAllowedQty(tgt, inCents));
        this.upgTargetQty = Math.max(minQ, Math.min(maxQ, this.upgTargetQty + delta));
    }

    private void setUpgradeQty(int qty) {
        if (this.upgCatalog.isEmpty()) return;
        Item tgt = this.upgCatalog.get(Math.min(this.upgTargetIdx, this.upgCatalog.size() - 1));
        long inCents = getSelectedUpgradeInputCents();
        int minQ = getMinValidQty(tgt, inCents);
        int maxQ = Math.max(minQ, getMaxAllowedQty(tgt, inCents));
        this.upgTargetQty = Math.max(minQ, Math.min(maxQ, qty));
    }

    private void rebuildUpgradeCatalog() {
        long inCents = getSelectedUpgradeInputCents();
        Item prevSelected = (!this.upgCatalog.isEmpty() && this.upgTargetIdx < this.upgCatalog.size())
                ? this.upgCatalog.get(this.upgTargetIdx) : null;
        this.upgCatalog.clear();
        String q = (this.upgPickingTarget && this.upgSearchQuery != null) ? this.upgSearchQuery.trim().toLowerCase(java.util.Locale.ROOT) : "";
        for (Item item : BuiltInRegistries.ITEM) {
            if (item instanceof CoinItem || item == ModItems.COMPUTER) continue;
            if (ModEconomy.isForbiddenOrUnobtainable(item) || ModEconomy.isArtifactItem(item)) continue;
            long unit = getTargetUnitCents(item);
            if (unit < 100L) continue;
            if (!q.isEmpty()) {
                String disp = new ItemStack(item, 1).getHoverName().getString().toLowerCase(java.util.Locale.ROOT);
                String regId = BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase(java.util.Locale.ROOT);
                if (!disp.contains(q) && !regId.contains(q)) continue;
            }
            if (inCents > 0L) {
                int hardMax = item.getDefaultMaxStackSize() > 1 ? 128 : 1;
                int minQ = (int) (inCents / unit) + 1;
                // Only include if item can beat input value within 1..128 stack AND its min valid stack is <= 128x input!
                if (minQ > hardMax) continue;
                if (unit * (long) minQ > inCents * 128L) continue;
            }
            this.upgCatalog.add(item);
        }
        this.upgCatalog.sort(java.util.Comparator.comparingLong(it -> {
            long u = getTargetUnitCents(it);
            int mq = getMinValidQty(it, inCents);
            return u * (long) mq;
        }));
        if (prevSelected != null) {
            int newIdx = this.upgCatalog.indexOf(prevSelected);
            if (newIdx >= 0) {
                this.upgTargetIdx = newIdx;
                int minQ = getMinValidQty(prevSelected, inCents);
                int maxQ = Math.max(minQ, getMaxAllowedQty(prevSelected, inCents));
                this.upgTargetQty = Math.max(minQ, Math.min(maxQ, this.upgTargetQty));
                return;
            }
        }
        this.upgTargetIdx = 0;
        this.upgCatalogPage = 0;
        if (!this.upgCatalog.isEmpty()) {
            this.upgTargetQty = getMinValidQty(this.upgCatalog.get(0), inCents);
        }
    }

    private long getSelectedUpgradeInputCents() {
        if (this.upgInputSlot < 0 || this.minecraft == null || this.minecraft.player == null) return 0L;
        ItemStack st = this.minecraft.player.getInventory().getItem(this.upgInputSlot);
        return st.isEmpty() ? 0L : ModEconomy.getStackCents(st);
    }

    private void selectUpgradeInputSlot(int invIdx) {
        if (this.upgRolling && !this.upgFinished) return;
        if (this.minecraft == null || this.minecraft.player == null) return;
        ItemStack st = this.minecraft.player.getInventory().getItem(invIdx);
        if (st.isEmpty() || ModEconomy.getStackCents(st) <= 0L) return;
        this.upgInputSlot = invIdx;
        this.upgFinished = false;
        rebuildUpgradeCatalog();
        snapTargetMultiplier(2.0);
        this.rebuildWidgets();
    }

    private void snapTargetMultiplier(double mult) {
        if (this.upgCatalog.isEmpty()) return;
        long inCents = getSelectedUpgradeInputCents();
        if (inCents <= 0L) return;
        long desired = Math.round(inCents * mult);
        int bestIdx = 0;
        long bestDiff = Long.MAX_VALUE;
        for (int i = 0; i < this.upgCatalog.size(); i++) {
            Item it = this.upgCatalog.get(i);
            int mq = getMinValidQty(it, inCents);
            long val = getTargetUnitCents(it) * (long) mq;
            long diff = Math.abs(val - desired);
            if (diff < bestDiff) {
                bestDiff = diff;
                bestIdx = i;
            }
        }
        this.upgTargetIdx = bestIdx;
        this.upgTargetQty = getMinValidQty(this.upgCatalog.get(bestIdx), inCents);
    }

    private void cycleUpgradeTarget(int dir) {
        if (this.upgCatalog.isEmpty()) rebuildUpgradeCatalog();
        if (this.upgCatalog.isEmpty()) return;
        int n = this.upgCatalog.size();
        this.upgTargetIdx = (this.upgTargetIdx + dir + n) % n;
        this.upgTargetQty = getMinValidQty(this.upgCatalog.get(this.upgTargetIdx), getSelectedUpgradeInputCents());
    }

    private void handleUpgradeClick() {
        if (this.upgRolling && !this.upgFinished) {
            finishUpgradeNow();
            return;
        }
        long inCents = getSelectedUpgradeInputCents();
        if (inCents <= 0L || this.upgCatalog.isEmpty()) return;
        Item tgt = this.upgCatalog.get(Math.min(this.upgTargetIdx, this.upgCatalog.size() - 1));
        int minQ = getMinValidQty(tgt, inCents);
        int maxQ = Math.max(minQ, getMaxAllowedQty(tgt, inCents));
        int qty = Math.max(minQ, Math.min(maxQ, this.upgTargetQty));
        long tgtCents = getTargetUnitCents(tgt) * (long) qty;
        if (tgtCents <= inCents) return;
        String tid = BuiltInRegistries.ITEM.getKey(tgt).toString();
        String zStr = String.format(java.util.Locale.ROOT, "%.4f", this.upgZoneStart);
        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("upgrade_roll",
                this.upgInputSlot + "|" + tid + "|" + qty + "|" + zStr));
    }

    private void renderUpgraderTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY, float partialTick) {
        int W = this.width;
        int padX = Math.max(12, (W - 440) / 2);
        int totalW = W - padX * 2;
        int topPanelH = 86;
        int boxW = Math.min(126, (totalW - 24) / 3);
        int midW = totalW - boxW * 2 - 16;
        int midX = padX + boxW + 8;
        int rightX = midX + midW + 8;

        Inventory inv = (this.minecraft != null && this.minecraft.player != null) ? this.minecraft.player.getInventory() : null;
        ItemStack inStack = (inv != null && this.upgInputSlot >= 0) ? inv.getItem(this.upgInputSlot) : ItemStack.EMPTY;
        long inCents = inStack.isEmpty() ? 0L : ModEconomy.getStackCents(inStack);
        Item tgtItem = this.upgCatalog.isEmpty() ? null : this.upgCatalog.get(Math.min(this.upgTargetIdx, this.upgCatalog.size() - 1));
        int minQ = getMinValidQty(tgtItem, inCents);
        int maxQ = Math.max(minQ, getMaxAllowedQty(tgtItem, inCents));
        int clampedQty = tgtItem != null ? Math.max(minQ, Math.min(maxQ, this.upgTargetQty)) : 1;
        this.upgTargetQty = clampedQty;
        long tgtCents = tgtItem != null ? getTargetUnitCents(tgtItem) * (long) clampedQty : 0L;
        double liveChancePct = (inCents > 0L && tgtCents > inCents)
                ? Math.max(0.7, Math.min(80.0, (inCents / (double) tgtCents) * 90.0)) : 0.0;

        // 1. Left Box: YOUR ITEM
        g.fill(padX, top, padX + boxW, top + topPanelH, 0xFF151C29);
        drawBorder(g, padX, top, boxW, topPanelH, inCents > 0L ? 0xFF38BDF8 : 0xFF28344A);
        g.centeredText(this.font, Component.translatable("ui.randomoredrop.upg_input"), padX + boxW / 2, top + 5, 0xFF94A3B8);
        int sx = padX + boxW / 2 - 12;
        int sy = top + 20;
        g.fill(sx, sy, sx + 24, sy + 24, 0xFF0B0F17);
        drawBorder(g, sx, sy, 24, 24, 0xFF334155);
        if (!inStack.isEmpty()) {
            g.item(inStack, sx + 4, sy + 4);
            if (inStack.getCount() > 1) {
                String cs = String.valueOf(inStack.getCount());
                g.text(this.font, Component.literal(cs), sx + 23 - this.font.width(cs), sy + 15, 0xFFFFFFFF, true);
            }
            g.centeredText(this.font, Component.literal(ModEconomy.formatCents(inCents) + " Coins"), padX + boxW / 2, top + 50, 0xFFFACC15);
            if (inStack.isDamageableItem() && inStack.getMaxDamage() > 0) {
                int wPct = Math.round(inStack.getDamageValue() * 100.0F / inStack.getMaxDamage());
                g.centeredText(this.font, Component.literal("Wear " + wPct + "%"), padX + boxW / 2, top + 64, 0xFF94A3B8);
            }
        } else {
            g.centeredText(this.font, Component.translatable("ui.randomoredrop.upg_pick_hint"), padX + boxW / 2, top + 52, 0xFF64748B);
        }

        // 2. Center Box: Draggable Green Win-Zone Bar + Animated Needle
        g.fill(midX, top, midX + midW, top + topPanelH, 0xFF151C29);
        drawBorder(g, midX, top, midW, topPanelH, 0xFF28344A);

        double dispChance = this.upgRolling || this.upgFinished ? this.upgChancePct : liveChancePct;
        String pctStr = dispChance > 0.0 ? String.format("%.1f%%", dispChance) : "--%";
        int pctCol = this.upgFinished ? (this.upgWon ? 0xFF4ADE80 : 0xFFF87171) : 0xFFFACC15;
        g.centeredText(this.font, Component.literal(pctStr), midX + midW / 2, top + 5, pctCol);

        int barX = midX + 8;
        int barY = top + 18;
        int barW = midW - 16;
        int barH = 18;
        double frac = Math.max(0.0, Math.min(1.0, dispChance / 100.0));
        if (!this.upgRolling && !this.upgFinished) {
            this.upgZoneStart = Math.max(0.0, Math.min(Math.max(0.0, 1.0 - frac), this.upgZoneStart));
        }

        g.fill(barX, barY, barX + barW, barY + barH, 0xFF7F1D1D);
        int winX0 = barX + (int) Math.round(barW * this.upgZoneStart);
        int winW = Math.max(frac > 0.0 ? 2 : 0, (int) Math.round(barW * frac));
        if (winW > 0) {
            int clampedW = Math.min(barX + barW - winX0, winW);
            boolean barHov = mouseX >= barX && mouseX <= barX + barW && mouseY >= barY && mouseY <= barY + barH;
            g.fill(winX0, barY, winX0 + clampedW, barY + barH, barHov ? 0xFF22C55E : 0xFF15803D);
            drawBorder(g, winX0, barY, clampedW, barH, 0xFF86EFAC);
        }
        drawBorder(g, barX, barY, barW, barH, 0xFF475569);

        if (this.upgRolling || this.upgFinished) {
            double needlePos;
            if (this.upgRolling && !this.upgFinished) {
                long elapsed = System.currentTimeMillis() - this.upgStartMs;
                double t = Math.min(1.0, elapsed / (double) UPG_DURATION_MS);
                double eased = 1.0 - Math.pow(1.0 - t, 3.0);
                double totalTravel = 2.0 + this.upgRollPos;
                needlePos = (totalTravel * eased) % 1.0;
                if (t >= 1.0) {
                    finishUpgradeNow();
                    needlePos = this.upgRollPos;
                }
            } else {
                needlePos = this.upgRollPos;
            }
            int nx = barX + Math.max(1, Math.min(barW - 2, (int) Math.round(needlePos * barW)));
            g.fill(nx - 1, barY - 3, nx + 2, barY + barH + 3, 0xFFFACC15);
        }

        if (this.upgFinished) {
            g.centeredText(this.font,
                    Component.translatable(this.upgWon ? "ui.randomoredrop.upg_win" : "ui.randomoredrop.upg_lose"),
                    midX + midW / 2, top + 44, this.upgWon ? 0xFF4ADE80 : 0xFFF87171);
        } else if (frac > 0.0) {
            g.centeredText(this.font, Component.translatable("ui.randomoredrop.upg_drag_hint"), midX + midW / 2, top + 44, 0xFF64748B);
        }

        boolean canRoll = (inCents > 0L && tgtCents > inCents) || (this.upgRolling && !this.upgFinished);
        drawButtonVisual(g, midX + 6, top + topPanelH - 22, midW - 12, 19,
                Component.translatable(this.upgRolling && !this.upgFinished ? "ui.randomoredrop.skip_anim" : "ui.randomoredrop.upg_btn"),
                canRoll ? 0xFFB45309 : 0xFF2B3548, canRoll ? 0xFFD97706 : 0xFF334155, mouseX, mouseY);

        // 3. Right Box: TARGET ITEM + Row 1 (- / Pick / +) + Row 2 (10 / 50 / 100)
        g.fill(rightX, top, rightX + boxW, top + topPanelH, 0xFF151C29);
        drawBorder(g, rightX, top, boxW, topPanelH, this.upgPickingTarget ? 0xFF38BDF8 : 0xFF28344A);
        g.centeredText(this.font, Component.translatable("ui.randomoredrop.upg_target"), rightX + boxW / 2, top + 4, 0xFF94A3B8);

        drawButtonVisual(g, rightX + 4, top + 17, 16, 20, Component.literal("<"), 0xFF25354D, 0xFF38BDF8, mouseX, mouseY);
        drawButtonVisual(g, rightX + boxW - 20, top + 17, 16, 20, Component.literal(">"), 0xFF25354D, 0xFF38BDF8, mouseX, mouseY);

        int tsx = rightX + boxW / 2 - 11;
        int tsy = top + 15;
        g.fill(tsx, tsy, tsx + 22, tsy + 22, 0xFF0B0F17);
        drawBorder(g, tsx, tsy, 22, 22, 0xFF38BDF8);
        List<Component> hoveredTip = null;
        if (tgtItem != null) {
            ItemStack tStack = new ItemStack(tgtItem, Math.min(64, clampedQty));
            g.item(tStack, tsx + 3, tsy + 3);
            if (clampedQty > 1) {
                String cs = String.valueOf(clampedQty);
                g.text(this.font, Component.literal(cs), tsx + 21 - this.font.width(cs), tsy + 13, 0xFFFFFFFF, true);
            }
            g.centeredText(this.font, Component.literal(ModEconomy.formatCents(tgtCents) + " Coins"), rightX + boxW / 2, top + 41, 0xFF4ADE80);
            if (mouseX >= tsx && mouseX < tsx + 22 && mouseY >= tsy && mouseY < tsy + 22) {
                List<Component> tTip = new ArrayList<>();
                tTip.add(tStack.getHoverName().copy().withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
                if (tStack.isDamageableItem()) tTip.add(Component.translatable("wear.randomoredrop.fn").withStyle(ChatFormatting.GREEN));
                tTip.add(Component.translatable("ui.randomoredrop.val_single", ModEconomy.formatCents(tgtCents)).withStyle(ChatFormatting.YELLOW));
                tTip.add(Component.translatable("ui.randomoredrop.upg_click_browse").withStyle(ChatFormatting.AQUA));
                hoveredTip = tTip;
            }
        }
        int row1Y = top + topPanelH - 32;
        int row2Y = top + topPanelH - 16;
        drawButtonVisual(g, rightX + 4, row1Y, 18, 13, Component.literal("-"), 0xFF1E293B, 0xFF334155, mouseX, mouseY);
        drawButtonVisual(g, rightX + boxW - 22, row1Y, 18, 13, Component.literal("+"), 0xFF1E293B, 0xFF334155, mouseX, mouseY);
        drawButtonVisual(g, rightX + 25, row1Y, boxW - 50, 13,
                Component.translatable(this.upgPickingTarget ? "ui.randomoredrop.upg_back_inv" : "ui.randomoredrop.upg_choose", clampedQty),
                this.upgPickingTarget ? 0xFF1D4ED8 : 0xFF1E293B, 0xFF2563EB, mouseX, mouseY);

        String[] qLabels = {"10", "50", "100"};
        int qbw = (boxW - 12) / 3;
        for (int q = 0; q < 3; q++) {
            drawButtonVisual(g, rightX + 4 + q * (qbw + 2), row2Y, qbw, 13,
                    Component.literal(qLabels[q]), 0xFF1E293B, 0xFF334155, mouseX, mouseY);
        }

        // 4. Bottom Grid: Player Inventory OR Filtered Target Catalog (strictly > input & <= 128x!)
        int slotSz = 19, slotGap = 2;
        int gridW = 9 * slotSz + 8 * slotGap;
        int gx = (W - gridW) / 2;
        int gy = top + topPanelH + 14;
        if (!this.upgPickingTarget) {
            g.text(this.font, Component.translatable("ui.randomoredrop.upg_inv_title"), gx, gy - 11, 0xFFCBD5E1, false);
            for (int r = 0; r < 4; r++) {
                int y = gy + r * (slotSz + slotGap) + (r == 3 ? 3 : 0);
                for (int c = 0; c < 9; c++) {
                    int invIdx = (r < 3) ? (9 + r * 9 + c) : c;
                    int x = gx + c * (slotSz + slotGap);
                    ItemStack st = inv != null ? inv.getItem(invIdx) : ItemStack.EMPTY;
                    long val = st.isEmpty() ? 0L : ModEconomy.getStackCents(st);
                    boolean usable = !st.isEmpty() && val > 0L;
                    boolean sel = usable && (invIdx == this.upgInputSlot);
                    boolean hov = mouseX >= x && mouseX < x + slotSz && mouseY >= y && mouseY < y + slotSz;

                    g.fill(x, y, x + slotSz, y + slotSz, sel ? 0xFF1E3A5F : (hov && usable ? 0xFF283448 : 0xFF141B26));
                    drawBorder(g, x, y, slotSz, slotSz, sel ? 0xFF38BDF8 : (hov && usable ? 0xFF60A5FA : 0xFF263042));
                    if (!st.isEmpty()) {
                        g.item(st, x + 2, y + 2);
                        if (st.getCount() > 1) {
                            String cnt = String.valueOf(st.getCount());
                            g.text(this.font, Component.literal(cnt), x + slotSz - this.font.width(cnt) - 1, y + slotSz - 8, 0xFFFFFFFF, true);
                        }
                        if (hov) {
                            List<Component> tip = new ArrayList<>();
                            tip.add(st.getHoverName().copy().withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD));
                            Component wComp = ComputerActions.formatWearComponent(st);
                            if (!wComp.getString().isEmpty()) tip.add(wComp);
                            if (usable) {
                                tip.add(Component.translatable("ui.randomoredrop.val_single", ModEconomy.formatCents(val)).withStyle(ChatFormatting.GOLD));
                            } else {
                                tip.add(Component.translatable("msg.randomoredrop.offhand_unsellable").withStyle(ChatFormatting.RED));
                            }
                            hoveredTip = tip;
                        }
                    }
                }
            }
        } else {
            int maxPage = Math.max(0, (this.upgCatalog.size() - 1) / 36);
            if (this.upgCatalogPage > maxPage) this.upgCatalogPage = maxPage;
            g.text(this.font, Component.translatable("ui.randomoredrop.upg_catalog_title", this.upgCatalogPage + 1, maxPage + 1),
                    gx, gy - 11, 0xFF38BDF8, false);
            if (this.upgSearchBox != null) {
                this.upgSearchBox.extractRenderState(g, mouseX, mouseY, partialTick);
            }
            drawButtonVisual(g, gx + gridW - 52, gy - 13, 24, 12, Component.literal("<"), 0xFF1E293B, 0xFF38BDF8, mouseX, mouseY);
            drawButtonVisual(g, gx + gridW - 26, gy - 13, 26, 12, Component.literal(">"), 0xFF1E293B, 0xFF38BDF8, mouseX, mouseY);

            for (int r = 0; r < 4; r++) {
                int y = gy + r * (slotSz + slotGap);
                for (int c = 0; c < 9; c++) {
                    int idx = this.upgCatalogPage * 36 + r * 9 + c;
                    int x = gx + c * (slotSz + slotGap);
                    boolean exists = idx < this.upgCatalog.size();
                    boolean sel = exists && (idx == this.upgTargetIdx);
                    boolean hov = mouseX >= x && mouseX < x + slotSz && mouseY >= y && mouseY < y + slotSz;
                    g.fill(x, y, x + slotSz, y + slotSz, sel ? 0xFF1A4D33 : (hov && exists ? 0xFF283448 : 0xFF141B26));
                    drawBorder(g, x, y, slotSz, slotSz, sel ? 0xFF4ADE80 : (hov && exists ? 0xFF38BDF8 : 0xFF263042));
                    if (exists) {
                        Item it = this.upgCatalog.get(idx);
                        int mq = getMinValidQty(it, inCents);
                        ItemStack st = new ItemStack(it, 1);
                        long totalVal = getTargetUnitCents(it) * (long) mq;
                        g.item(st, x + 2, y + 2);
                        if (mq > 1) {
                            String cnt = String.valueOf(mq);
                            g.text(this.font, Component.literal(cnt), x + slotSz - this.font.width(cnt) - 1, y + slotSz - 8, 0xFFFACC15, true);
                        }
                        if (hov) {
                            List<Component> tip = new ArrayList<>();
                            tip.add(st.getHoverName().copy().withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
                            if (st.isDamageableItem()) tip.add(Component.translatable("wear.randomoredrop.fn").withStyle(ChatFormatting.GREEN));
                            if (mq > 1) {
                                tip.add(Component.translatable("ui.randomoredrop.qty_single", mq).withStyle(ChatFormatting.AQUA));
                            }
                            tip.add(Component.translatable("ui.randomoredrop.val_single", ModEconomy.formatCents(totalVal)).withStyle(ChatFormatting.YELLOW));
                            hoveredTip = tip;
                        }
                    }
                }
            }
        }
        if (hoveredTip != null) {
            g.setTooltipForNextFrame(this.font, hoveredTip, Optional.empty(), mouseX, mouseY);
        }
    }

    private void renderStocksTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        int padX = Math.max(10, (W - 460) / 2);
        int totalW = W - padX * 2;
        int listW = Math.min(122, totalW / 3);
        int rightX = padX + listW + 8;
        int rightW = totalW - listW - 8;
        int availH = bot - top;
        int rowH = Math.max(14, Math.min(19, (availH - 4) / 10));

        if (this.stockList.isEmpty()) {
            g.centeredText(this.font, Component.translatable("ui.randomoredrop.stocks_loading"), W / 2, top + availH / 2, 0xFF94A3B8);
            return;
        }

        // 1. Left Sidebar: Top 10 Most Active US Stocks
        for (int i = 0; i < Math.min(10, this.stockList.size()); i++) {
            StockMarket.StockSnapshot st = this.stockList.get(i);
            int y = top + i * rowH;
            boolean sel = (i == this.selectedStockIdx);
            boolean hov = mouseX >= padX && mouseX < padX + listW && mouseY >= y && mouseY < y + rowH - 1;
            int bg = sel ? 0xFF1E3252 : (hov ? 0xFF1D2638 : 0xFF141A26);
            g.fill(padX, y, padX + listW, y + rowH - 1, bg);
            if (sel) {
                g.fill(padX, y, padX + 2, y + rowH - 1, 0xFF38BDF8);
            }
            drawBorder(g, padX, y, listW, rowH - 1, sel ? 0xFF38BDF8 : 0xFF232C3F);

            double pct = st.prevCloseCents() > 0
                    ? ((st.priceCents() - st.prevCloseCents()) * 100.0 / st.prevCloseCents()) : 0.0;
            boolean up = pct >= 0.0;
            int pctCol = up ? 0xFF4ADE80 : 0xFFF87171;

            int ty = y + Math.max(2, (rowH - 9) / 2);
            boolean hasPos = st.ownedShares() > 0 || st.shortShares() > 0;
            String symLbl = hasPos ? (st.symbol() + "*") : st.symbol();
            g.text(this.font, Component.literal(symLbl), padX + 5, ty, hasPos ? 0xFFFFD54F : 0xFFFFFFFF, false);

            String pStr = ModEconomy.formatCents(st.priceCents());
            String pctStr = String.format("%+.1f%%", pct);
            int pctW = this.font.width(pctStr);
            g.text(this.font, Component.literal(pctStr), padX + listW - pctW - 3, ty, pctCol, false);
            g.text(this.font, Component.literal(pStr), padX + listW - pctW - this.font.width(pStr) - 7, ty, 0xFFCBD5E1, false);
        }

        // 2. Right Panel: Header + Candlestick K-Line Chart + Buy/Sell Order Bar
        StockMarket.StockSnapshot cur = this.stockList.get(Math.min(this.selectedStockIdx, this.stockList.size() - 1));
        int hdrH = 34;
        g.fill(rightX, top, rightX + rightW, top + hdrH, 0xFF151C29);
        drawBorder(g, rightX, top, rightW, hdrH, 0xFF28344A);

        double curPct = cur.prevCloseCents() > 0
                ? ((cur.priceCents() - cur.prevCloseCents()) * 100.0 / cur.prevCloseCents()) : 0.0;
        long diffCents = cur.priceCents() - cur.prevCloseCents();
        int trendCol = diffCents >= 0 ? 0xFF4ADE80 : 0xFFF87171;
        String liveBadge = cur.live() ? " [LIVE+EXT]" : " [SIM]";
        g.text(this.font, Component.literal(cur.symbol() + " - " + cur.name() + liveBadge),
                rightX + 6, top + 5, cur.live() ? 0xFF38BDF8 : 0xFFFBBF24, true);

        String quoteStr = ModEconomy.formatCents(cur.priceCents()) + " (" + (diffCents >= 0 ? "+" : "")
                + ModEconomy.formatCents(diffCents) + " / " + String.format("%+.2f%%", curPct) + ")";
        g.text(this.font, Component.literal(quoteStr), rightX + 6, top + 16, trendCol, false);

        // Player position summary (Long or Short depending on selected mode)
        if (!this.stockShortMode) {
            if (cur.ownedShares() > 0) {
                long pnl = (cur.priceCents() - cur.avgCostCents()) * cur.ownedShares();
                String pnlStr = (pnl >= 0 ? "+" : "") + ModEconomy.formatCents(pnl);
                g.text(this.font, Component.translatable("ui.randomoredrop.stock_pos",
                                cur.ownedShares(), ModEconomy.formatCents(cur.avgCostCents()), pnlStr),
                        rightX + 6, top + 25, pnl >= 0 ? 0xFF4ADE80 : 0xFFF87171, false);
            } else {
                g.text(this.font, Component.translatable("ui.randomoredrop.stock_no_pos"),
                        rightX + 6, top + 25, 0xFF64748B, false);
            }
        } else {
            if (cur.shortShares() > 0) {
                long pnl = (cur.shortAvgEntryCents() - cur.priceCents()) * cur.shortShares();
                String pnlStr = (pnl >= 0 ? "+" : "") + ModEconomy.formatCents(pnl);
                g.text(this.font, Component.translatable("ui.randomoredrop.stock_short_pos",
                                cur.shortShares(), ModEconomy.formatCents(cur.shortAvgEntryCents()), pnlStr),
                        rightX + 6, top + 25, pnl >= 0 ? 0xFF4ADE80 : 0xFFF87171, false);
            } else {
                g.text(this.font, Component.translatable("ui.randomoredrop.stock_no_short_pos"),
                        rightX + 6, top + 25, 0xFF64748B, false);
            }
        }

        drawButtonVisual(g, rightX + rightW - 134, top + 3, 74, 16,
                Component.translatable(this.stockShortMode ? "ui.randomoredrop.mode_short" : "ui.randomoredrop.mode_long"),
                this.stockShortMode ? 0xFFB45309 : 0xFF166534,
                this.stockShortMode ? 0xFFD97706 : 0xFF15803D,
                mouseX, mouseY);
        drawButtonVisual(g, rightX + rightW - 56, top + 3, 52, 16,
                Component.translatable("ui.randomoredrop.stock_refresh"), 0xFF25354D, 0xFF344B6E, mouseX, mouseY);

        // 3. Candlestick K-Line Chart Box
        int chartY = top + hdrH + 4;
        int chartH = Math.max(48, (bot - 26) - chartY);
        int axisW = 36;
        int plotW = rightW - axisW - 4;
        g.fill(rightX, chartY, rightX + rightW, chartY + chartH, 0xFF0B0F17);
        drawBorder(g, rightX, chartY, rightW, chartH, 0xFF263247);

        List<StockMarket.Candle> candles = cur.candles();
        if (!candles.isEmpty()) {
            long minP = Long.MAX_VALUE, maxP = Long.MIN_VALUE;
            for (StockMarket.Candle c : candles) {
                if (c.lowCents() < minP) minP = c.lowCents();
                if (c.highCents() > maxP) maxP = c.highCents();
            }
            if (maxP <= minP) maxP = minP + 100L;
            long padRange = Math.max(10L, (maxP - minP) / 10L);
            minP = Math.max(0L, minP - padRange);
            maxP = maxP + padRange;
            long span = Math.max(1L, maxP - minP);

            // Horizontal price gridlines + right Y-axis labels
            for (int gIdx = 0; gIdx <= 3; gIdx++) {
                int gy = chartY + 6 + (gIdx * (chartH - 12)) / 3;
                g.fill(rightX + 2, gy, rightX + plotW, gy + 1, 0xFF182233);
                long gridPrice = maxP - (gIdx * span) / 3;
                g.text(this.font, Component.literal(ModEconomy.formatCents(gridPrice)),
                        rightX + plotW + 3, gy - 3, 0xFF64748B, false);
            }

            int n = candles.size();
            float slotW = (plotW - 8) / (float) Math.max(1, n);
            int bodyW = Math.max(2, Math.min(8, (int) (slotW * 0.65F)));
            List<Component> candleTip = null;

            for (int i = 0; i < n; i++) {
                StockMarket.Candle c = candles.get(i);
                int cx = rightX + 4 + (int) ((i + 0.5F) * slotW);
                int yHigh = chartY + 6 + (int) ((maxP - c.highCents()) * (chartH - 12) / (double) span);
                int yLow  = chartY + 6 + (int) ((maxP - c.lowCents())  * (chartH - 12) / (double) span);
                int yOpen = chartY + 6 + (int) ((maxP - c.openCents()) * (chartH - 12) / (double) span);
                int yClose = chartY + 6 + (int) ((maxP - c.closeCents()) * (chartH - 12) / (double) span);

                boolean bull = c.closeCents() >= c.openCents();
                int col = bull ? 0xFF22C55E : 0xFFEF4444;
                boolean hov = mouseX >= cx - Math.max(2, (int) (slotW / 2)) && mouseX <= cx + Math.max(2, (int) (slotW / 2))
                        && mouseY >= chartY && mouseY < chartY + chartH;
                if (hov) {
                    g.fill(cx, chartY + 1, cx + 1, chartY + chartH - 1, 0x55FFFFFF);
                    candleTip = List.of(
                            Component.literal(cur.symbol() + " #" + (i + 1)).withStyle(bull ? ChatFormatting.GREEN : ChatFormatting.RED, ChatFormatting.BOLD),
                            Component.translatable("ui.randomoredrop.kline_o", ModEconomy.formatCents(c.openCents())).withStyle(ChatFormatting.GRAY),
                            Component.translatable("ui.randomoredrop.kline_h", ModEconomy.formatCents(c.highCents())).withStyle(ChatFormatting.GREEN),
                            Component.translatable("ui.randomoredrop.kline_l", ModEconomy.formatCents(c.lowCents())).withStyle(ChatFormatting.RED),
                            Component.translatable("ui.randomoredrop.kline_c", ModEconomy.formatCents(c.closeCents())).withStyle(ChatFormatting.GOLD)
                    );
                }

                // Vertical High-Low Wick
                g.fill(cx, Math.min(yHigh, yLow), cx + 1, Math.max(yHigh, yLow) + 1, col);
                // Open-Close Candlestick Body
                int topB = Math.min(yOpen, yClose);
                int botB = Math.max(yOpen, yClose);
                if (botB <= topB) botB = topB + 1;
                g.fill(cx - bodyW / 2, topB, cx - bodyW / 2 + bodyW, botB + 1, col);

                // 5-Candle Moving Average (MA5) gold marker
                if (i >= 4) {
                    long sum = 0L;
                    for (int k = i - 4; k <= i; k++) sum += candles.get(k).closeCents();
                    long ma = sum / 5L;
                    int yMa = chartY + 6 + (int) ((maxP - ma) * (chartH - 12) / (double) span);
                    g.fill(cx - 1, yMa, cx + 1, yMa + 2, 0xFFFACC15);
                }
            }

            if (candleTip != null) {
                g.setTooltipForNextFrame(this.font, candleTip, Optional.empty(), mouseX, mouseY);
            }
        }

        // 4. Bottom Order Buttons: Long (Buy/Sell) or Short (Short/Close)
        int btnY = bot - 22;
        int gap = 4;
        int bw = (rightW - gap * 5) / 6;
        String[] keys = this.stockShortMode
                ? new String[]{
                        "ui.randomoredrop.short_1", "ui.randomoredrop.short_10", "ui.randomoredrop.short_100",
                        "ui.randomoredrop.cover_1", "ui.randomoredrop.cover_10", "ui.randomoredrop.cover_all"
                }
                : new String[]{
                        "ui.randomoredrop.buy_1", "ui.randomoredrop.buy_10", "ui.randomoredrop.buy_100",
                        "ui.randomoredrop.sell_1", "ui.randomoredrop.sell_10", "ui.randomoredrop.sell_all"
                };
        for (int b = 0; b < 6; b++) {
            boolean isOpen = b < 3;
            int bgNorm = this.stockShortMode
                    ? (isOpen ? 0xFFB45309 : 0xFF1D4ED8)
                    : (isOpen ? 0xFF1F7A46 : 0xFF9E2A2B);
            int bgHov = this.stockShortMode
                    ? (isOpen ? 0xFFD97706 : 0xFF2563EB)
                    : (isOpen ? 0xFF29A05C : 0xFFC93838);
            drawButtonVisual(g, rightX + b * (bw + gap), btnY, bw, 20,
                    Component.translatable(keys[b]), bgNorm, bgHov, mouseX, mouseY);
        }
    }

    private void toggleSellSlot(int invIdx) {
        if (this.minecraft == null || this.minecraft.player == null) return;
        ItemStack st = this.minecraft.player.getInventory().getItem(invIdx);
        if (st.isEmpty() || ModEconomy.getStackCents(st) <= 0L) return;
        if (!this.selectedSellSlots.remove(invIdx)) {
            this.selectedSellSlots.add(invIdx);
        }
        this.confirmSellArmed = false;
    }

    private void selectAllMinerals() {
        if (this.minecraft == null || this.minecraft.player == null) return;
        Inventory inv = this.minecraft.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && !(st.getItem() instanceof CoinItem) && ModEconomy.isBulkSellable(st.getItem())
                    && ModEconomy.getStackCents(st) > 0L) {
                this.selectedSellSlots.add(i);
            }
        }
    }

    private void handleSellConfirmClick() {
        if (this.minecraft == null || this.minecraft.player == null) return;
        Inventory inv = this.minecraft.player.getInventory();
        this.selectedSellSlots.removeIf(idx -> {
            ItemStack st = inv.getItem(idx);
            return st.isEmpty() || ModEconomy.getStackCents(st) <= 0L;
        });
        if (this.selectedSellSlots.isEmpty()) {
            this.confirmSellArmed = false;
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (int idx : this.selectedSellSlots) {
            if (sb.length() > 0) sb.append(',');
            sb.append(idx);
        }
        this.selectedSellSlots.clear();
        this.confirmSellArmed = false;
        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("sell_slots", sb.toString()));
    }

    private void renderSellTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        int slotSz = 22, slotGap = 3;
        int gridW = 9 * slotSz + 8 * slotGap;
        int panelW = Math.min(145, Math.max(115, W - gridW - 40));
        int totalW = gridW + 14 + panelW;
        int startX = (W - totalW) / 2;
        int gridH = 4 * slotSz + 3 * slotGap + 8;
        int startY = top + Math.max(18, (bot - top - gridH) / 2);

        g.text(this.font, Component.translatable("ui.randomoredrop.sell_grid_title").withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD),
                startX, startY - 13, 0xFFFFFFFF, true);

        Inventory inv = (this.minecraft != null && this.minecraft.player != null) ? this.minecraft.player.getInventory() : null;
        List<Component> hoveredTip = null;
        long selectedTotalCents = 0L;
        int selectedSlotsCount = 0;

        for (int r = 0; r < 4; r++) {
            int y = startY + r * (slotSz + slotGap) + (r == 3 ? 6 : 0);
            for (int c = 0; c < 9; c++) {
                int invIdx = (r < 3) ? (9 + r * 9 + c) : c;
                int x = startX + c * (slotSz + slotGap);
                ItemStack st = inv != null ? inv.getItem(invIdx) : ItemStack.EMPTY;
                long val = st.isEmpty() ? 0L : ModEconomy.getStackCents(st);
                boolean sellable = !st.isEmpty() && val > 0L;
                boolean selected = sellable && this.selectedSellSlots.contains(invIdx);
                if (selected) {
                    selectedTotalCents += val;
                    selectedSlotsCount++;
                }
                boolean hover = mouseX >= x && mouseX < x + slotSz && mouseY >= y && mouseY < y + slotSz;

                int bg = selected ? 0xFF1A4D33 : (hover && sellable ? 0xFF283448 : 0xFF161D29);
                int border = selected ? 0xFF4ADE80 : (hover && sellable ? 0xFF60A5FA : 0xFF2B3548);
                g.fill(x, y, x + slotSz, y + slotSz, bg);
                drawBorder(g, x, y, slotSz, slotSz, border);

                if (!st.isEmpty()) {
                    g.item(st, x + 3, y + 3);
                    if (st.getCount() > 1) {
                        String cnt = String.valueOf(st.getCount());
                        g.text(this.font, Component.literal(cnt), x + slotSz - this.font.width(cnt) - 1, y + slotSz - 9, 0xFFFFFFFF, true);
                    }
                    if (hover) {
                        List<Component> tip = new ArrayList<>();
                        tip.add(st.getHoverName().copy().withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD));
                        Component wComp = ComputerActions.formatWearComponent(st);
                        if (!wComp.getString().isEmpty()) {
                            tip.add(wComp);
                        }
                        if (sellable) {
                            tip.add(Component.translatable("ui.randomoredrop.val_single", ModEconomy.formatCents(val)).withStyle(ChatFormatting.GOLD));
                            tip.add(Component.translatable(selected ? "ui.randomoredrop.click_deselect" : "ui.randomoredrop.click_select")
                                    .withStyle(selected ? ChatFormatting.RED : ChatFormatting.GREEN));
                        } else {
                            tip.add(Component.translatable("msg.randomoredrop.offhand_unsellable").withStyle(ChatFormatting.RED));
                        }
                        hoveredTip = tip;
                    }
                }
            }
        }

        // Right-side summary & confirmation panel
        int px = startX + gridW + 14;
        int ph = gridH;
        g.fill(px, startY, px + panelW, startY + ph, 0xFF171E2B);
        drawBorder(g, px, startY, panelW, ph, 0xFF2B374D);

        g.centeredText(this.font, Component.translatable("ui.randomoredrop.sell_selected_count", selectedSlotsCount),
                px + panelW / 2, startY + 7, 0xFFCBD5E1);
        g.centeredText(this.font, Component.translatable("ui.randomoredrop.sell_selected_total", ModEconomy.formatCents(selectedTotalCents))
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), px + panelW / 2, startY + 19, 0xFFFFD54F);

        drawButtonVisual(g, px + 8, startY + 42, panelW - 16, 18,
                Component.translatable("ui.randomoredrop.clear_sel_btn"), 0xFF334155, 0xFF475569, mouseX, mouseY);

        Component sellBtnLbl = Component.translatable("ui.randomoredrop.confirm_sell_btn");
        int btnNorm = selectedSlotsCount > 0 ? 0xFF1F7A46 : 0xFF283040;
        int btnHov  = selectedSlotsCount > 0 ? 0xFF29A05C : 0xFF323C4F;
        drawButtonVisual(g, px + 8, startY + 68, panelW - 16, 22, sellBtnLbl, btnNorm, btnHov, mouseX, mouseY);

        if (hoveredTip != null) {
            g.setTooltipForNextFrame(this.font, hoveredTip, Optional.empty(), mouseX, mouseY);
        }
    }

    private void renderBankTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        Item[] coins = {ModItems.COIN_1, ModItems.COIN_10, ModItems.COIN_100, ModItems.COIN_1000, ModItems.COIN_10000};
        String[] labels = {"1", "10", "100", "1,000", "10,000"};
        int[] colors = {0xFF7D5324, 0xFF6B778C, 0xFFA37E18, 0xFF1C7E9E, 0xFF7A32A8};

        int gap = 8;
        int cardW = Math.min(78, (W - 40 - gap * 4) / 5);
        int cardH = 92;
        int totalW = cardW * 5 + gap * 4;
        int startX = (W - totalW) / 2;
        int y = top + Math.max(12, (bot - top - cardH - 42) / 2);

        for (int i = 0; i < 5; i++) {
            int x = startX + i * (cardW + gap);
            drawPanelCard(g, x, y, cardW, cardH, colors[i], 0xFF18202E);
            drawScaledItem(g, new ItemStack(coins[i]), x + cardW / 2 - 16, y + 10, 2.0F);
            g.centeredText(this.font, Component.translatable("ui.randomoredrop.coin_amt", labels[i]), x + cardW / 2, y + 48, 0xFFFFD54F);
            drawButtonVisual(g, x + 8, y + cardH - 24, cardW - 16, 18,
                    Component.translatable("ui.randomoredrop.withdraw_btn"), 0xFF28507A, 0xFF3A72AD, mouseX, mouseY);
        }

        drawButtonVisual(g, startX, y + cardH + 14, totalW, 24,
                Component.translatable("ui.randomoredrop.deposit_all_btn"),
                0xFF1F7A46, 0xFF29A05C, mouseX, mouseY);
    }

    private void drawNavTabVisual(GuiGraphicsExtractor g, int x, int y, int w, int h, Component label, boolean active, int mouseX, int mouseY) {
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        int bg = active ? 0xFF2B6CB0 : (hover ? 0xFF232C3D : 0xFF161C26);
        g.fill(x, y, x + w, y + h, bg);
        if (active) {
            g.fill(x, y + h - 2, x + w, y + h, 0xFF63B3ED);
        }
        g.centeredText(this.font, label, x + w / 2, y + 6, active ? 0xFFFFFFFF : 0xFFB0BCD0);
    }

    private void drawButtonVisual(GuiGraphicsExtractor g, int x, int y, int w, int h, Component text,
                                  int normalBg, int hoverBg, int mouseX, int mouseY) {
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        g.fill(x, y, x + w, y + h, hover ? hoverBg : normalBg);
        drawBorder(g, x, y, w, h, hover ? 0xFFFFFFFF : 0x55FFFFFF);
        g.centeredText(this.font, text, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }

    private void drawPanelCard(GuiGraphicsExtractor g, int x, int y, int w, int h, int headerCol, int bodyCol) {
        drawBorder(g, x - 1, y - 1, w + 2, h + 2, 0xFF2B374D);
        fillVerticalGradient(g, x, y, x + w, y + 44, headerCol, bodyCol);
        g.fill(x, y + 44, x + w, y + h, bodyCol);
    }

    private void drawScaledItem(GuiGraphicsExtractor g, ItemStack stack, int x, int y, float scale) {
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.item(stack, 0, 0);
        g.pose().popMatrix();
    }

    private static void drawBorder(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private static void fillVerticalGradient(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int topArgb, int botArgb) {
        int height = Math.max(1, y2 - y1);
        int bands = Math.min(height, 16);
        int ta = (topArgb >>> 24) & 0xFF, tr = (topArgb >>> 16) & 0xFF, tg = (topArgb >>> 8) & 0xFF, tb = topArgb & 0xFF;
        int ba = (botArgb >>> 24) & 0xFF, br = (botArgb >>> 16) & 0xFF, bg = (botArgb >>> 8) & 0xFF, bb = botArgb & 0xFF;
        for (int i = 0; i < bands; i++) {
            int sy1 = y1 + (i * height) / bands;
            int sy2 = y1 + ((i + 1) * height) / bands;
            float f = bands <= 1 ? 0.0F : i / (float) (bands - 1);
            int a = (int) (ta + (ba - ta) * f);
            int r = (int) (tr + (br - tr) * f);
            int gr = (int) (tg + (bg - tg) * f);
            int b = (int) (tb + (bb - tb) * f);
            int c = (a << 24) | (r << 16) | (gr << 8) | b;
            g.fill(x1, sy1, x2, sy2, c);
        }
    }
}
