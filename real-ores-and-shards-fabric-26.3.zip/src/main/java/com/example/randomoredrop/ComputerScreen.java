package com.example.randomoredrop;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ComputerScreen extends Screen {
    private static final String[] CASE_IDS = {
            "starter", "miner", "gem", "explorer", "titanium", "tungsten", "netherite", "legendary"
    };

    private static final int[] CASE_TOP_COLORS = {
            0xFF8B561B, 0xFF217A4B, 0xFF187399, 0xFF6B3199,
            0xFF2E5C9E, 0xFF9C7418, 0xFF96202B, 0xFFC49216
    };

    private static final int[] CASE_BOT_COLORS = {
            0xFF281D13, 0xFF13261C, 0xFF11232C, 0xFF20152D,
            0xFF121E33, 0xFF2B2210, 0xFF2A1216, 0xFF33260E
    };

    private static final int[] TIER_ARGB = {
            0xFF4B69FF, 0xFF8847FF, 0xFFD32CE6, 0xFFEB4B4B, 0xFFFFD700
    };

    private static final int[] TIER_BG = {
            0xFF1A2238, 0xFF241B38, 0xFF301A36, 0xFF361A1E, 0xFF3B3014
    };

    private enum Tab { CASES, STOCKS, SELL, BANK }
    private enum CaseSubView { GRID, PREVIEW, SPIN }

    private Tab activeTab = Tab.CASES;
    private CaseSubView subView = CaseSubView.GRID;
    private String selectedCaseId = "starter";

    private long balanceCents;
    private Component toastComp = Component.empty();
    private boolean toastError = false;
    private long toastUntilMs = 0L;
    private int openedThisSession = 0;
    private final java.util.Set<Integer> selectedSellSlots = new java.util.LinkedHashSet<>();
    private boolean confirmSellArmed = false;
    private List<StockMarket.StockSnapshot> stockList = new ArrayList<>();
    private int selectedStockIdx = 0;
    private int stockAutoSyncTicks = 0;
    private long lastStockSyncMs = 0L;
    private boolean stockShortMode = false;

    private static final int REEL_TOTAL = 56;
    private static final int WIN_IDX = 46;
    private static final long SPIN_DURATION_MS = 4600L;
    private final List<ComputerActions.CaseEntry> spinReel = new ArrayList<>();
    private long spinStartMs = 0L;
    private boolean spinFinished = false;
    private boolean spinClaimed = false;
    private int lastTickCard = -1;
    private long lastSpinCostCents = 0L;
    private long lastWinValCents = 0L;
    private int lastWinTier = 0;
    private ItemStack lastWinStack = ItemStack.EMPTY;

    public ComputerScreen(long initialBalanceCents) {
        super(Component.translatable("ui.randomoredrop.title"));
        this.balanceCents = initialBalanceCents;
    }

    private void addClickZone(int x, int y, int w, int h, Runnable action) {
        this.addWidget(Button.builder(Component.empty(), btn -> action.run()).bounds(x, y, w, h).build());
    }

    @Override
    protected void init() {
        super.init();
        int W = this.width;
        int H = this.height;
        int topH = 28;
        int contentTop = topH + 8;
        int contentBot = H - 22;

        int tx = 8;
        addClickZone(tx, 4, 54, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.CASES;
            this.subView = CaseSubView.GRID;
            this.rebuildWidgets();
        });
        tx += 57;
        addClickZone(tx, 4, 66, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("open_upgrader", ""));
        });
        tx += 69;
        addClickZone(tx, 4, 58, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.STOCKS;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("sync_stocks", ""));
            this.rebuildWidgets();
        });
        tx += 61;
        addClickZone(tx, 4, 48, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.SELL;
            this.rebuildWidgets();
        });
        tx += 51;
        addClickZone(tx, 4, 50, 20, () -> {
            if (this.subView == CaseSubView.SPIN && !this.spinClaimed) finishSpinNow();
            this.activeTab = Tab.BANK;
            this.rebuildWidgets();
        });

        addClickZone(W - 26, 5, 18, 18, this::onClose);

        if (this.activeTab == Tab.CASES) {
            if (this.subView == CaseSubView.GRID) {
                int cols = 4, gap = 10;
                int padX = Math.max(16, (W - 460) / 2);
                int cardW = Math.min(118, (W - padX * 2 - gap * (cols - 1)) / cols);
                int startX = (W - (cardW * cols + gap * (cols - 1))) / 2;
                int availH = contentBot - contentTop - 8;
                int cardH = Math.min(96, (availH - gap) / 2);
                int startY = contentTop + Math.max(4, (availH - (cardH * 2 + gap)) / 2);

                for (int i = 0; i < CASE_IDS.length; i++) {
                    String cid = CASE_IDS[i];
                    int x = startX + (i % cols) * (cardW + gap);
                    int y = startY + (i / cols) * (cardH + gap);
                    int infoX = x + cardW - 18;
                    int infoY = y + cardH - 15;
                    addClickZone(infoX, infoY, 14, 13, () -> {
                        this.selectedCaseId = cid;
                        this.subView = CaseSubView.PREVIEW;
                        this.rebuildWidgets();
                    });
                    addClickZone(x, y, cardW, cardH, () ->
                            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", cid)));
                }
            } else if (this.subView == CaseSubView.PREVIEW) {
                int hx = Math.max(16, (W - 440) / 2);
                int hw = W - hx * 2;
                addClickZone(hx + 6, contentTop + 5, 58, 18, () -> {
                    this.subView = CaseSubView.GRID;
                    this.rebuildWidgets();
                });
                addClickZone(hx + hw - 96, contentTop + 5, 90, 18, () ->
                        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", this.selectedCaseId)));
            } else {
                int trackH = 88;
                int trackY = contentTop + Math.max(18, (contentBot - contentTop - trackH - 60) / 2);
                int btnY = trackY + trackH + 14;
                if (!this.spinFinished) {
                    addClickZone(W / 2 - 58, btnY, 116, 22, this::finishSpinNow);
                } else {
                    int rowY = btnY + 16;
                    addClickZone(W / 2 - 135, rowY, 85, 22, () -> {
                        this.subView = CaseSubView.GRID;
                        this.rebuildWidgets();
                    });
                    addClickZone(W / 2 - 42, rowY, 96, 22, () ->
                            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("spin_case", this.selectedCaseId)));
                    addClickZone(W / 2 + 62, rowY, 76, 22, () -> {
                        this.subView = CaseSubView.PREVIEW;
                        this.rebuildWidgets();
                    });
                }
            }
        } else if (this.activeTab == Tab.STOCKS) {
            int padX = Math.max(10, (W - 460) / 2);
            int totalW = W - padX * 2;
            int listW = Math.min(122, totalW / 3);
            int rightX = padX + listW + 8;
            int rightW = totalW - listW - 8;
            int availH = contentBot - contentTop;
            int rowH = Math.max(14, Math.min(19, (availH - 4) / 10));

            for (int i = 0; i < 10; i++) {
                int idx = i;
                addClickZone(padX, contentTop + i * rowH, listW, rowH - 1, () -> {
                    this.selectedStockIdx = idx;
                });
            }
            // Long/Short mode toggle button + Refresh button in top-right of stock header
            addClickZone(rightX + rightW - 134, contentTop + 3, 74, 16, () -> {
                this.stockShortMode = !this.stockShortMode;
            });
            addClickZone(rightX + rightW - 56, contentTop + 3, 52, 16, () ->
                    ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("refresh_stocks", "")));

            // 6 Order buttons along bottom of right panel: Open 1 / 10 / 100 | Close 1 / 10 / All
            int btnY = contentBot - 22;
            int gap = 4;
            int bw = (rightW - gap * 5) / 6;
            String[] qtys = {"1", "10", "100", "1", "10", "0"};
            for (int b = 0; b < 6; b++) {
                boolean isOpen = b < 3;
                String q = qtys[b];
                addClickZone(rightX + b * (bw + gap), btnY, bw, 20, () -> {
                    if (!this.stockList.isEmpty()) {
                        String sym = this.stockList.get(Math.min(this.selectedStockIdx, this.stockList.size() - 1)).symbol();
                        String act = this.stockShortMode
                                ? (isOpen ? "short_stock" : "cover_stock")
                                : (isOpen ? "buy_stock" : "sell_stock");
                        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload(act, sym + ":" + q));
                    }
                });
            }
        } else if (this.activeTab == Tab.SELL) {
            int slotSz = 22, slotGap = 3;
            int gridW = 9 * slotSz + 8 * slotGap;
            int panelW = Math.min(145, Math.max(115, W - gridW - 40));
            int totalW = gridW + 14 + panelW;
            int startX = (W - totalW) / 2;
            int gridH = 4 * slotSz + 3 * slotGap + 8;
            int startY = contentTop + Math.max(18, (contentBot - contentTop - gridH) / 2);

            // 27 main inventory slots (indices 9..35) in rows 0..2, plus 9 hotbar slots (0..8) in row 3
            for (int r = 0; r < 4; r++) {
                int y = startY + r * (slotSz + slotGap) + (r == 3 ? 6 : 0);
                for (int c = 0; c < 9; c++) {
                    int invIdx = (r < 3) ? (9 + r * 9 + c) : c;
                    int x = startX + c * (slotSz + slotGap);
                    addClickZone(x, y, slotSz, slotSz, () -> toggleSellSlot(invIdx));
                }
            }

            // Right-side action panel buttons
            int px = startX + gridW + 14;
            addClickZone(px + 8, startY + 34, panelW - 16, 18, () -> {
                selectAllMinerals();
                this.confirmSellArmed = false;
            });
            addClickZone(px + 8, startY + 56, panelW - 16, 18, () -> {
                this.selectedSellSlots.clear();
                this.confirmSellArmed = false;
            });
            addClickZone(px + 8, startY + 80, panelW - 16, 22, this::handleSellConfirmClick);
        } else {
            String[] args = {"1", "10", "100", "1000", "10000"};
            int gap = 8;
            int cardW = Math.min(78, (W - 40 - gap * 4) / 5);
            int cardH = 92;
            int totalW = cardW * 5 + gap * 4;
            int startX = (W - totalW) / 2;
            int y = contentTop + Math.max(12, (contentBot - contentTop - cardH - 42) / 2);

            for (int i = 0; i < 5; i++) {
                int x = startX + i * (cardW + gap);
                String arg = args[i];
                addClickZone(x + 8, y + cardH - 24, cardW - 16, 18, () ->
                        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("withdraw", arg)));
            }
            addClickZone(startX, y + cardH + 14, totalW, 24, () ->
                    ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("deposit_all", "")));
        }
    }

    public void updateStocks(long newBalanceCents, List<StockMarket.StockSnapshot> stocks) {
        this.balanceCents = newBalanceCents;
        this.stockList = stocks != null ? stocks : new ArrayList<>();
        this.lastStockSyncMs = System.currentTimeMillis();
        if (this.selectedStockIdx >= this.stockList.size()) {
            this.selectedStockIdx = 0;
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.activeTab == Tab.STOCKS) {
            if (++this.stockAutoSyncTicks >= 200) { // Auto-sync every 10 seconds while watching K-line
                this.stockAutoSyncTicks = 0;
                ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("sync_stocks", ""));
            }
        }
    }

    public void updateBalance(long newBalanceCents, String msgKey, String arg1, String arg2, boolean isError) {
        this.balanceCents = newBalanceCents;
        if (msgKey != null && !msgKey.isEmpty()) {
            this.toastComp = Component.translatable(msgKey, arg1, arg2);
            this.toastError = isError;
            this.toastUntilMs = System.currentTimeMillis() + 4500L;
        }
    }

    public void startSpin(ComputerNetwork.SpinResultPayload payload) {
        this.balanceCents = payload.newBalanceCents();
        this.selectedCaseId = payload.caseId();
        this.lastSpinCostCents = payload.costCents();
        this.lastWinValCents = payload.winValueCents();
        this.lastWinTier = payload.winTier();

        Item winItem = BuiltInRegistries.ITEM.getOptional(Identifier.parse(payload.winItemId())).orElse(Items.DIAMOND);
        this.lastWinStack = new ItemStack(winItem, payload.winCount());
        if (payload.winDamage() > 0 && this.lastWinStack.isDamageableItem()) {
            this.lastWinStack.setDamageValue(Math.min(this.lastWinStack.getMaxDamage() - 1, payload.winDamage()));
        }

        this.spinReel.clear();
        RandomSource rng = RandomSource.create();
        for (int i = 0; i < REEL_TOTAL; i++) {
            if (i == WIN_IDX) {
                this.spinReel.add(ComputerActions.makeEntryForClient(this.lastWinStack, payload.winTier()));
            } else {
                this.spinReel.add(ComputerActions.rollCaseEntry(payload.caseId(), rng));
            }
        }
        this.spinStartMs = System.currentTimeMillis();
        this.spinFinished = false;
        this.spinClaimed = false;
        this.lastTickCard = -1;
        this.activeTab = Tab.CASES;
        this.subView = CaseSubView.SPIN;
        this.openedThisSession++;
        this.rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        if (this.subView == CaseSubView.SPIN && !this.spinClaimed) {
            this.spinClaimed = true;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("claim_spin", ""));
        }
        super.onClose();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        int W = this.width;
        int H = this.height;

        g.fill(0, 0, W, H, 0xF00F131A);

        int topH = 28;
        g.fill(0, 0, W, topH, 0xFF161C26);
        g.fill(0, topH - 1, W, topH, 0xFF283244);

        int tx = 8;
        drawNavTabVisual(g, tx, 4, 54, 20, Component.translatable("ui.randomoredrop.tab.cases"), this.activeTab == Tab.CASES, mouseX, mouseY);
        tx += 57;
        drawNavTabVisual(g, tx, 4, 66, 20, Component.translatable("ui.randomoredrop.tab.upgrader"), false, mouseX, mouseY);
        tx += 69;
        drawNavTabVisual(g, tx, 4, 58, 20, Component.translatable("ui.randomoredrop.tab.stocks"), this.activeTab == Tab.STOCKS, mouseX, mouseY);
        tx += 61;
        drawNavTabVisual(g, tx, 4, 48, 20, Component.translatable("ui.randomoredrop.tab.sell"), this.activeTab == Tab.SELL, mouseX, mouseY);
        tx += 51;
        drawNavTabVisual(g, tx, 4, 50, 20, Component.translatable("ui.randomoredrop.tab.bank"), this.activeTab == Tab.BANK, mouseX, mouseY);

        Component balComp = Component.translatable("ui.randomoredrop.balance", ModEconomy.formatCents(this.balanceCents))
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
        int balW = this.font.width(balComp);
        int closeX = W - 26;
        g.fill(closeX - balW - 18, 5, closeX - 6, 23, 0xFF1F2735);
        g.text(this.font, balComp, closeX - balW - 12, 10, 0xFFFFD54F, true);

        boolean closeHover = mouseX >= closeX && mouseX < closeX + 18 && mouseY >= 5 && mouseY < 23;
        g.fill(closeX, 5, closeX + 18, 23, closeHover ? 0xFFB83232 : 0xFF252D3D);
        g.centeredText(this.font, Component.literal("X"), closeX + 9, 10, 0xFFFFFFFF);

        int contentTop = topH + 8;
        int contentBot = H - 22;
        if (this.activeTab == Tab.CASES) {
            if (this.subView == CaseSubView.GRID) {
                renderCaseGrid(g, contentTop, contentBot, mouseX, mouseY);
            } else if (this.subView == CaseSubView.PREVIEW) {
                renderCasePreview(g, contentTop, contentBot, mouseX, mouseY);
            } else {
                renderCaseSpin(g, contentTop, contentBot, mouseX, mouseY);
            }
        } else if (this.activeTab == Tab.STOCKS) {
            renderStocksTab(g, contentTop, contentBot, mouseX, mouseY);
        } else if (this.activeTab == Tab.SELL) {
            renderSellTab(g, contentTop, contentBot, mouseX, mouseY);
        } else {
            renderBankTab(g, contentTop, contentBot, mouseX, mouseY);
        }

        int botY = H - 20;
        g.fill(0, botY, W, H, 0xFF141923);
        g.fill(0, botY, W, botY + 1, 0xFF283244);
        g.text(this.font, Component.translatable("ui.randomoredrop.esc_close"), 10, botY + 6, 0xFF8B97AD, false);

        if (System.currentTimeMillis() < this.toastUntilMs && !this.toastComp.getString().isEmpty()) {
            int col = this.toastError ? 0xFFFF6B6B : 0xFF5CE08C;
            g.centeredText(this.font, this.toastComp, W / 2, botY + 6, col);
        } else {
            g.centeredText(this.font, Component.translatable("ui.randomoredrop.footer_hint"), W / 2, botY + 6, 0xFF6E7B91);
        }

        Component sess = Component.translatable("ui.randomoredrop.opened_session", this.openedThisSession);
        g.text(this.font, sess, W - this.font.width(sess) - 10, botY + 6, 0xFF8B97AD, false);
    }

    private void renderCaseGrid(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        int cols = 4, gap = 10;
        int padX = Math.max(16, (W - 460) / 2);
        int cardW = Math.min(118, (W - padX * 2 - gap * (cols - 1)) / cols);
        int startX = (W - (cardW * cols + gap * (cols - 1))) / 2;
        int availH = bot - top - 8;
        int cardH = Math.min(96, (availH - gap) / 2);
        int startY = top + Math.max(4, (availH - (cardH * 2 + gap)) / 2);

        for (int i = 0; i < CASE_IDS.length; i++) {
            String cid = CASE_IDS[i];
            ComputerActions.CaseDef def = ComputerActions.getCaseDef(cid);
            int x = startX + (i % cols) * (cardW + gap);
            int y = startY + (i / cols) * (cardH + gap);

            int bannerH = (int) (cardH * 0.56);
            boolean cardHover = mouseX >= x && mouseX < x + cardW && mouseY >= y && mouseY < y + cardH;

            drawBorder(g, x - 1, y - 1, cardW + 2, cardH + 2, cardHover ? 0xFF58A6FF : 0xFF263042);
            fillVerticalGradient(g, x, y, x + cardW, y + bannerH, CASE_TOP_COLORS[i], CASE_BOT_COLORS[i]);
            g.fill(x, y + bannerH, x + cardW, y + cardH, cardHover ? 0xFF212A3A : 0xFF19202D);

            drawScaledItem(g, new ItemStack(def.icon()), x + cardW / 2 - 16, y + bannerH / 2 - 16, 2.0F);

            g.text(this.font, Component.translatable("case.randomoredrop." + cid).withStyle(ChatFormatting.WHITE),
                    x + 6, y + bannerH + 5, 0xFFFFFFFF, true);
            g.text(this.font, Component.literal("* " + ModEconomy.formatCents(def.costCents())).withStyle(ChatFormatting.GOLD),
                    x + 6, y + bannerH + 17, 0xFFFFD54F, false);

            int infoX = x + cardW - 18;
            int infoY = y + cardH - 15;
            boolean infoHover = mouseX >= infoX && mouseX < infoX + 14 && mouseY >= infoY && mouseY < infoY + 13;
            g.fill(infoX, infoY, infoX + 14, infoY + 13, infoHover ? 0xFF3B82F6 : 0xFF293448);
            g.centeredText(this.font, Component.literal("i"), infoX + 7, infoY + 2, 0xFFFFFFFF);

            Component openLbl = (cardHover && !infoHover)
                    ? Component.translatable("ui.randomoredrop.click_open")
                    : Component.translatable("ui.randomoredrop.open_short");
            g.text(this.font, openLbl, x + 6, y + cardH - 12, cardHover && !infoHover ? 0xFF5CE08C : 0xFF7D8AA3, false);
        }
    }

    private void renderCasePreview(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        ComputerActions.CaseDef def = ComputerActions.getCaseDef(this.selectedCaseId);

        int hx = Math.max(16, (W - 440) / 2);
        int hw = W - hx * 2;
        g.fill(hx, top, hx + hw, top + 28, 0xFF18202E);
        drawBorder(g, hx, top, hw, 28, 0xFF2B374D);

        drawButtonVisual(g, hx + 6, top + 5, 58, 18, Component.translatable("ui.randomoredrop.back"), 0xFF263145, 0xFF354460, mouseX, mouseY);

        g.text(this.font, Component.translatable("ui.randomoredrop.preview_header",
                        Component.translatable("case.randomoredrop." + this.selectedCaseId),
                        ModEconomy.formatCents(def.costCents()))
                .withStyle(def.titleColor(), ChatFormatting.BOLD), hx + 72, top + 5, 0xFFFFFFFF, true);
        g.text(this.font, Component.translatable("ui.randomoredrop.odds_legend"),
                hx + 72, top + 16, 0xFF94A3B8, false);

        drawButtonVisual(g, hx + hw - 96, top + 5, 90, 18, Component.translatable("ui.randomoredrop.open_now"), 0xFF1F7A46, 0xFF29A05C, mouseX, mouseY);

        List<ComputerActions.PreviewEntry> entries = ComputerActions.getPreviewEntries(this.selectedCaseId);
        int cols = 5, gap = 6;
        int cardW = (hw - gap * (cols - 1)) / cols;
        int gridTop = top + 34;
        int rows = (entries.size() + cols - 1) / cols;
        int cardH = Math.min(40, Math.max(28, (bot - gridTop - gap * (rows - 1)) / Math.max(1, rows)));

        List<Component> hoveredTooltip = null;
        for (int i = 0; i < entries.size(); i++) {
            ComputerActions.PreviewEntry e = entries.get(i);
            int x = hx + (i % cols) * (cardW + gap);
            int y = gridTop + (i / cols) * (cardH + gap);
            if (y + cardH > bot) break;

            int tierCol = TIER_ARGB[Math.min(4, e.tierIndex())];
            int bgCol = TIER_BG[Math.min(4, e.tierIndex())];
            boolean hover = mouseX >= x && mouseX < x + cardW && mouseY >= y && mouseY < y + cardH;

            g.fill(x, y, x + cardW, y + cardH, hover ? 0xFF253045 : bgCol);
            g.fill(x, y + cardH - 3, x + cardW, y + cardH, tierCol);
            drawBorder(g, x, y, cardW, cardH, hover ? tierCol : 0xFF2A3448);

            ItemStack st = new ItemStack(e.item(), e.minCount());
            g.item(st, x + 5, y + (cardH - 18) / 2);

            String nm = st.getHoverName().getString();
            if (nm.length() > 8) nm = nm.substring(0, 7) + "..";
            g.text(this.font, Component.literal(nm), x + 25, y + 6, 0xFFFFFFFF, false);
            long minV = ModEconomy.getCents(e.item()) * e.minCount();
            g.text(this.font, Component.literal("* " + ModEconomy.formatCents(minV)), x + 25, y + 17, 0xFFFFD54F, false);

            if (hover) {
                long maxV = ModEconomy.getCents(e.item()) * e.maxCount();
                Component cntComp = e.minCount() == e.maxCount()
                        ? Component.translatable("ui.randomoredrop.qty_single", e.minCount())
                        : Component.translatable("ui.randomoredrop.qty_range", e.minCount(), e.maxCount());
                Component valComp = minV == maxV
                        ? Component.translatable("ui.randomoredrop.val_single", ModEconomy.formatCents(minV))
                        : Component.translatable("ui.randomoredrop.val_range", ModEconomy.formatCents(minV), ModEconomy.formatCents(maxV));
                hoveredTooltip = List.of(
                        st.getHoverName().copy().withStyle(e.color(), ChatFormatting.BOLD),
                        Component.translatable("ui.randomoredrop.tier_line",
                                Component.translatable(ComputerActions.rarityKey(e.tierIndex())), e.chanceText()).withStyle(e.color()),
                        cntComp.copy().withStyle(ChatFormatting.WHITE),
                        valComp.copy().withStyle(ChatFormatting.GOLD)
                );
            }
        }
        if (hoveredTooltip != null) {
            g.setTooltipForNextFrame(this.font, hoveredTooltip, Optional.empty(), mouseX, mouseY);
        }
    }

    private void renderCaseSpin(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        long elapsed = System.currentTimeMillis() - this.spinStartMs;
        double t = Math.min(1.0, elapsed / (double) SPIN_DURATION_MS);
        if (this.spinFinished) t = 1.0;

        double eased = 1.0 - Math.pow(1.0 - t, 4.0);

        int trackW = Math.min(440, W - 32);
        int trackX = (W - trackW) / 2;
        int trackH = 88;
        int trackY = top + Math.max(18, (bot - top - trackH - 60) / 2);
        int centerX = trackX + trackW / 2;

        Component spinHeader = Component.translatable(
                this.spinFinished ? "ui.randomoredrop.spin_done" : "ui.randomoredrop.spinning",
                Component.translatable("case.randomoredrop." + this.selectedCaseId)
        ).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
        g.centeredText(this.font, spinHeader, W / 2, trackY - 16, 0xFFFFD54F);

        g.fill(trackX - 2, trackY - 2, trackX + trackW + 2, trackY + trackH + 2, 0xFF283347);
        g.fill(trackX, trackY, trackX + trackW, trackY + trackH, 0xFF0C1017);

        int cardW = 64, cardGap = 6, stepPx = cardW + cardGap;
        double startOffset = 2.0 * stepPx;
        double targetOffset = WIN_IDX * (double) stepPx;
        double currentPos = startOffset + (targetOffset - startOffset) * eased;

        int curCard = (int) Math.round(currentPos / stepPx);
        if (!this.spinFinished && curCard != this.lastTickCard) {
            this.lastTickCard = curCard;
            try {
                float pitch = (float) (1.55 - 0.65 * t);
                Minecraft.getInstance().getSoundManager().play(
                        SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_HAT.value(), pitch, 0.55F));
            } catch (Throwable ignored) {}
        }

        for (int i = 0; i < this.spinReel.size(); i++) {
            int cx = (int) Math.round(centerX + (i * stepPx - currentPos) - cardW / 2.0);
            if (cx + cardW < trackX + 2 || cx > trackX + trackW - 2) continue;
            int drawL = Math.max(cx, trackX + 2);
            int drawR = Math.min(cx + cardW, trackX + trackW - 2);
            if (drawR <= drawL) continue;

            ComputerActions.CaseEntry entry = this.spinReel.get(i);
            int tierCol = TIER_ARGB[Math.min(4, entry.tierIndex())];
            int bgCol = TIER_BG[Math.min(4, entry.tierIndex())];
            int cy = trackY + 6;
            int ch = trackH - 12;

            g.fill(drawL, cy, drawR, cy + ch, bgCol);
            g.fill(drawL, cy + ch - 4, drawR, cy + ch, tierCol);
            if (cx >= trackX + 2 && cx + cardW <= trackX + trackW - 2) {
                boolean isWinnerNow = this.spinFinished && i == WIN_IDX;
                drawBorder(g, cx, cy, cardW, ch, isWinnerNow ? 0xFFFFD700 : 0xFF2A364B);
                drawScaledItem(g, entry.stack(), cx + cardW / 2 - 16, cy + 10, 2.0F);
                String lbl = entry.stack().getHoverName().getString();
                if (lbl.length() > 8) lbl = lbl.substring(0, 7) + "..";
                g.centeredText(this.font, Component.literal(lbl), cx + cardW / 2, cy + ch - 16, 0xFFE2E8F0);
            }
        }

        g.fill(centerX - 1, trackY, centerX + 1, trackY + trackH, 0xFFFFD700);
        g.fill(centerX - 5, trackY, centerX + 6, trackY + 4, 0xFFFFD700);
        g.fill(centerX - 5, trackY + trackH - 4, centerX + 6, trackY + trackH, 0xFFFFD700);

        if (t >= 1.0 && !this.spinFinished) {
            finishSpinNow();
        }

        int btnY = trackY + trackH + 14;
        if (!this.spinFinished) {
            drawButtonVisual(g, W / 2 - 58, btnY, 116, 22, Component.translatable("ui.randomoredrop.skip"), 0xFF28507A, 0xFF356CA3, mouseX, mouseY);
        } else {
            int tierCol = TIER_ARGB[Math.min(4, this.lastWinTier)];
            long diff = this.lastWinValCents - this.lastSpinCostCents;
            String diffTxt = (diff >= 0 ? "+" : "") + ModEconomy.formatCents(diff);
            Component wearComp = ComputerActions.formatWearComponent(this.lastWinStack);
            Component winComp = Component.translatable(
                    "ui.randomoredrop.win_banner",
                    this.lastWinStack.getHoverName(),
                    this.lastWinStack.getCount(),
                    wearComp,
                    ModEconomy.formatCents(this.lastWinValCents),
                    diffTxt
            );
            g.centeredText(this.font, winComp, W / 2, btnY, tierCol);

            int rowY = btnY + 16;
            drawButtonVisual(g, W / 2 - 135, rowY, 85, 22, Component.translatable("ui.randomoredrop.back_cases"), 0xFF263145, 0xFF364663, mouseX, mouseY);
            drawButtonVisual(g, W / 2 - 42, rowY, 96, 22, Component.translatable("ui.randomoredrop.spin_again"), 0xFF1F7A46, 0xFF29A05C, mouseX, mouseY);
            drawButtonVisual(g, W / 2 + 62, rowY, 76, 22, Component.translatable("ui.randomoredrop.preview_btn"), 0xFF4B3278, 0xFF63439C, mouseX, mouseY);
        }
    }

    private void finishSpinNow() {
        boolean wasFinished = this.spinFinished;
        this.spinFinished = true;
        if (!this.spinClaimed) {
            this.spinClaimed = true;
            ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("claim_spin", ""));
        }
        if (!wasFinished) {
            this.rebuildWidgets();
        }
    }

    private void renderStocksTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        int padX = Math.max(10, (W - 460) / 2);
        int totalW = W - padX * 2;
        int listW = Math.min(122, totalW / 3);
        int rightX = padX + listW + 8;
        int rightW = totalW - listW - 8;
        int availH = bot - top;
        int rowH = Math.max(14, Math.min(19, (availH - 4) / 10));

        if (this.stockList.isEmpty()) {
            g.centeredText(this.font, Component.translatable("ui.randomoredrop.stocks_loading"), W / 2, top + availH / 2, 0xFF94A3B8);
            return;
        }

        // 1. Left Sidebar: Top 10 Most Active US Stocks
        for (int i = 0; i < Math.min(10, this.stockList.size()); i++) {
            StockMarket.StockSnapshot st = this.stockList.get(i);
            int y = top + i * rowH;
            boolean sel = (i == this.selectedStockIdx);
            boolean hov = mouseX >= padX && mouseX < padX + listW && mouseY >= y && mouseY < y + rowH - 1;
            int bg = sel ? 0xFF1E3252 : (hov ? 0xFF1D2638 : 0xFF141A26);
            g.fill(padX, y, padX + listW, y + rowH - 1, bg);
            if (sel) {
                g.fill(padX, y, padX + 2, y + rowH - 1, 0xFF38BDF8);
            }
            drawBorder(g, padX, y, listW, rowH - 1, sel ? 0xFF38BDF8 : 0xFF232C3F);

            double pct = st.prevCloseCents() > 0
                    ? ((st.priceCents() - st.prevCloseCents()) * 100.0 / st.prevCloseCents()) : 0.0;
            boolean up = pct >= 0.0;
            int pctCol = up ? 0xFF4ADE80 : 0xFFF87171;

            int ty = y + Math.max(2, (rowH - 9) / 2);
            boolean hasPos = st.ownedShares() > 0 || st.shortShares() > 0;
            String symLbl = hasPos ? (st.symbol() + "*") : st.symbol();
            g.text(this.font, Component.literal(symLbl), padX + 5, ty, hasPos ? 0xFFFFD54F : 0xFFFFFFFF, false);

            String pStr = ModEconomy.formatCents(st.priceCents());
            String pctStr = String.format("%+.1f%%", pct);
            int pctW = this.font.width(pctStr);
            g.text(this.font, Component.literal(pctStr), padX + listW - pctW - 3, ty, pctCol, false);
            g.text(this.font, Component.literal(pStr), padX + listW - pctW - this.font.width(pStr) - 7, ty, 0xFFCBD5E1, false);
        }

        // 2. Right Panel: Header + Candlestick K-Line Chart + Buy/Sell Order Bar
        StockMarket.StockSnapshot cur = this.stockList.get(Math.min(this.selectedStockIdx, this.stockList.size() - 1));
        int hdrH = 34;
        g.fill(rightX, top, rightX + rightW, top + hdrH, 0xFF151C29);
        drawBorder(g, rightX, top, rightW, hdrH, 0xFF28344A);

        double curPct = cur.prevCloseCents() > 0
                ? ((cur.priceCents() - cur.prevCloseCents()) * 100.0 / cur.prevCloseCents()) : 0.0;
        long diffCents = cur.priceCents() - cur.prevCloseCents();
        int trendCol = diffCents >= 0 ? 0xFF4ADE80 : 0xFFF87171;
        String liveBadge = cur.live() ? " [LIVE+EXT]" : " [SIM]";
        g.text(this.font, Component.literal(cur.symbol() + " - " + cur.name() + liveBadge),
                rightX + 6, top + 5, cur.live() ? 0xFF38BDF8 : 0xFFFBBF24, true);

        String quoteStr = ModEconomy.formatCents(cur.priceCents()) + " (" + (diffCents >= 0 ? "+" : "")
                + ModEconomy.formatCents(diffCents) + " / " + String.format("%+.2f%%", curPct) + ")";
        g.text(this.font, Component.literal(quoteStr), rightX + 6, top + 16, trendCol, false);

        // Player position summary (Long or Short depending on selected mode)
        if (!this.stockShortMode) {
            if (cur.ownedShares() > 0) {
                long pnl = (cur.priceCents() - cur.avgCostCents()) * cur.ownedShares();
                String pnlStr = (pnl >= 0 ? "+" : "") + ModEconomy.formatCents(pnl);
                g.text(this.font, Component.translatable("ui.randomoredrop.stock_pos",
                                cur.ownedShares(), ModEconomy.formatCents(cur.avgCostCents()), pnlStr),
                        rightX + 6, top + 25, pnl >= 0 ? 0xFF4ADE80 : 0xFFF87171, false);
            } else {
                g.text(this.font, Component.translatable("ui.randomoredrop.stock_no_pos"),
                        rightX + 6, top + 25, 0xFF64748B, false);
            }
        } else {
            if (cur.shortShares() > 0) {
                long pnl = (cur.shortAvgEntryCents() - cur.priceCents()) * cur.shortShares();
                String pnlStr = (pnl >= 0 ? "+" : "") + ModEconomy.formatCents(pnl);
                g.text(this.font, Component.translatable("ui.randomoredrop.stock_short_pos",
                                cur.shortShares(), ModEconomy.formatCents(cur.shortAvgEntryCents()), pnlStr),
                        rightX + 6, top + 25, pnl >= 0 ? 0xFF4ADE80 : 0xFFF87171, false);
            } else {
                g.text(this.font, Component.translatable("ui.randomoredrop.stock_no_short_pos"),
                        rightX + 6, top + 25, 0xFF64748B, false);
            }
        }

        drawButtonVisual(g, rightX + rightW - 134, top + 3, 74, 16,
                Component.translatable(this.stockShortMode ? "ui.randomoredrop.mode_short" : "ui.randomoredrop.mode_long"),
                this.stockShortMode ? 0xFFB45309 : 0xFF166534,
                this.stockShortMode ? 0xFFD97706 : 0xFF15803D,
                mouseX, mouseY);
        drawButtonVisual(g, rightX + rightW - 56, top + 3, 52, 16,
                Component.translatable("ui.randomoredrop.stock_refresh"), 0xFF25354D, 0xFF344B6E, mouseX, mouseY);

        // 3. Candlestick K-Line Chart Box
        int chartY = top + hdrH + 4;
        int chartH = Math.max(48, (bot - 26) - chartY);
        int axisW = 36;
        int plotW = rightW - axisW - 4;
        g.fill(rightX, chartY, rightX + rightW, chartY + chartH, 0xFF0B0F17);
        drawBorder(g, rightX, chartY, rightW, chartH, 0xFF263247);

        List<StockMarket.Candle> candles = cur.candles();
        if (!candles.isEmpty()) {
            long minP = Long.MAX_VALUE, maxP = Long.MIN_VALUE;
            for (StockMarket.Candle c : candles) {
                if (c.lowCents() < minP) minP = c.lowCents();
                if (c.highCents() > maxP) maxP = c.highCents();
            }
            if (maxP <= minP) maxP = minP + 100L;
            long padRange = Math.max(10L, (maxP - minP) / 10L);
            minP = Math.max(0L, minP - padRange);
            maxP = maxP + padRange;
            long span = Math.max(1L, maxP - minP);

            // Horizontal price gridlines + right Y-axis labels
            for (int gIdx = 0; gIdx <= 3; gIdx++) {
                int gy = chartY + 6 + (gIdx * (chartH - 12)) / 3;
                g.fill(rightX + 2, gy, rightX + plotW, gy + 1, 0xFF182233);
                long gridPrice = maxP - (gIdx * span) / 3;
                g.text(this.font, Component.literal(ModEconomy.formatCents(gridPrice)),
                        rightX + plotW + 3, gy - 3, 0xFF64748B, false);
            }

            int n = candles.size();
            float slotW = (plotW - 8) / (float) Math.max(1, n);
            int bodyW = Math.max(2, Math.min(8, (int) (slotW * 0.65F)));
            List<Component> candleTip = null;

            for (int i = 0; i < n; i++) {
                StockMarket.Candle c = candles.get(i);
                int cx = rightX + 4 + (int) ((i + 0.5F) * slotW);
                int yHigh = chartY + 6 + (int) ((maxP - c.highCents()) * (chartH - 12) / (double) span);
                int yLow  = chartY + 6 + (int) ((maxP - c.lowCents())  * (chartH - 12) / (double) span);
                int yOpen = chartY + 6 + (int) ((maxP - c.openCents()) * (chartH - 12) / (double) span);
                int yClose = chartY + 6 + (int) ((maxP - c.closeCents()) * (chartH - 12) / (double) span);

                boolean bull = c.closeCents() >= c.openCents();
                int col = bull ? 0xFF22C55E : 0xFFEF4444;
                boolean hov = mouseX >= cx - Math.max(2, (int) (slotW / 2)) && mouseX <= cx + Math.max(2, (int) (slotW / 2))
                        && mouseY >= chartY && mouseY < chartY + chartH;
                if (hov) {
                    g.fill(cx, chartY + 1, cx + 1, chartY + chartH - 1, 0x55FFFFFF);
                    candleTip = List.of(
                            Component.literal(cur.symbol() + " #" + (i + 1)).withStyle(bull ? ChatFormatting.GREEN : ChatFormatting.RED, ChatFormatting.BOLD),
                            Component.translatable("ui.randomoredrop.kline_o", ModEconomy.formatCents(c.openCents())).withStyle(ChatFormatting.GRAY),
                            Component.translatable("ui.randomoredrop.kline_h", ModEconomy.formatCents(c.highCents())).withStyle(ChatFormatting.GREEN),
                            Component.translatable("ui.randomoredrop.kline_l", ModEconomy.formatCents(c.lowCents())).withStyle(ChatFormatting.RED),
                            Component.translatable("ui.randomoredrop.kline_c", ModEconomy.formatCents(c.closeCents())).withStyle(ChatFormatting.GOLD)
                    );
                }

                // Vertical High-Low Wick
                g.fill(cx, Math.min(yHigh, yLow), cx + 1, Math.max(yHigh, yLow) + 1, col);
                // Open-Close Candlestick Body
                int topB = Math.min(yOpen, yClose);
                int botB = Math.max(yOpen, yClose);
                if (botB <= topB) botB = topB + 1;
                g.fill(cx - bodyW / 2, topB, cx - bodyW / 2 + bodyW, botB + 1, col);

                // 5-Candle Moving Average (MA5) gold marker
                if (i >= 4) {
                    long sum = 0L;
                    for (int k = i - 4; k <= i; k++) sum += candles.get(k).closeCents();
                    long ma = sum / 5L;
                    int yMa = chartY + 6 + (int) ((maxP - ma) * (chartH - 12) / (double) span);
                    g.fill(cx - 1, yMa, cx + 1, yMa + 2, 0xFFFACC15);
                }
            }

            if (candleTip != null) {
                g.setTooltipForNextFrame(this.font, candleTip, Optional.empty(), mouseX, mouseY);
            }
        }

        // 4. Bottom Order Buttons: Long (Buy/Sell) or Short (Short/Close)
        int btnY = bot - 22;
        int gap = 4;
        int bw = (rightW - gap * 5) / 6;
        String[] keys = this.stockShortMode
                ? new String[]{
                        "ui.randomoredrop.short_1", "ui.randomoredrop.short_10", "ui.randomoredrop.short_100",
                        "ui.randomoredrop.cover_1", "ui.randomoredrop.cover_10", "ui.randomoredrop.cover_all"
                }
                : new String[]{
                        "ui.randomoredrop.buy_1", "ui.randomoredrop.buy_10", "ui.randomoredrop.buy_100",
                        "ui.randomoredrop.sell_1", "ui.randomoredrop.sell_10", "ui.randomoredrop.sell_all"
                };
        for (int b = 0; b < 6; b++) {
            boolean isOpen = b < 3;
            int bgNorm = this.stockShortMode
                    ? (isOpen ? 0xFFB45309 : 0xFF1D4ED8)
                    : (isOpen ? 0xFF1F7A46 : 0xFF9E2A2B);
            int bgHov = this.stockShortMode
                    ? (isOpen ? 0xFFD97706 : 0xFF2563EB)
                    : (isOpen ? 0xFF29A05C : 0xFFC93838);
            drawButtonVisual(g, rightX + b * (bw + gap), btnY, bw, 20,
                    Component.translatable(keys[b]), bgNorm, bgHov, mouseX, mouseY);
        }
    }

    private void toggleSellSlot(int invIdx) {
        if (this.minecraft == null || this.minecraft.player == null) return;
        ItemStack st = this.minecraft.player.getInventory().getItem(invIdx);
        if (st.isEmpty() || ModEconomy.getStackCents(st) <= 0L) return;
        if (!this.selectedSellSlots.remove(invIdx)) {
            this.selectedSellSlots.add(invIdx);
        }
        this.confirmSellArmed = false;
    }

    private void selectAllMinerals() {
        if (this.minecraft == null || this.minecraft.player == null) return;
        Inventory inv = this.minecraft.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && !(st.getItem() instanceof CoinItem) && ModEconomy.isBulkSellable(st.getItem())
                    && ModEconomy.getStackCents(st) > 0L) {
                this.selectedSellSlots.add(i);
            }
        }
    }

    private void handleSellConfirmClick() {
        if (this.minecraft == null || this.minecraft.player == null) return;
        Inventory inv = this.minecraft.player.getInventory();
        this.selectedSellSlots.removeIf(idx -> {
            ItemStack st = inv.getItem(idx);
            return st.isEmpty() || ModEconomy.getStackCents(st) <= 0L;
        });
        if (this.selectedSellSlots.isEmpty()) {
            this.confirmSellArmed = false;
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (int idx : this.selectedSellSlots) {
            if (sb.length() > 0) sb.append(',');
            sb.append(idx);
        }
        this.selectedSellSlots.clear();
        this.confirmSellArmed = false;
        ClientPlayNetworking.send(new ComputerNetwork.ComputerActionPayload("sell_slots", sb.toString()));
    }

    private void renderSellTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        int slotSz = 22, slotGap = 3;
        int gridW = 9 * slotSz + 8 * slotGap;
        int panelW = Math.min(145, Math.max(115, W - gridW - 40));
        int totalW = gridW + 14 + panelW;
        int startX = (W - totalW) / 2;
        int gridH = 4 * slotSz + 3 * slotGap + 8;
        int startY = top + Math.max(18, (bot - top - gridH) / 2);

        g.text(this.font, Component.translatable("ui.randomoredrop.sell_grid_title").withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD),
                startX, startY - 13, 0xFFFFFFFF, true);

        Inventory inv = (this.minecraft != null && this.minecraft.player != null) ? this.minecraft.player.getInventory() : null;
        List<Component> hoveredTip = null;
        long selectedTotalCents = 0L;
        int selectedSlotsCount = 0;

        for (int r = 0; r < 4; r++) {
            int y = startY + r * (slotSz + slotGap) + (r == 3 ? 6 : 0);
            for (int c = 0; c < 9; c++) {
                int invIdx = (r < 3) ? (9 + r * 9 + c) : c;
                int x = startX + c * (slotSz + slotGap);
                ItemStack st = inv != null ? inv.getItem(invIdx) : ItemStack.EMPTY;
                long val = st.isEmpty() ? 0L : ModEconomy.getStackCents(st);
                boolean sellable = !st.isEmpty() && val > 0L;
                boolean selected = sellable && this.selectedSellSlots.contains(invIdx);
                if (selected) {
                    selectedTotalCents += val;
                    selectedSlotsCount++;
                }
                boolean hover = mouseX >= x && mouseX < x + slotSz && mouseY >= y && mouseY < y + slotSz;

                int bg = selected ? 0xFF1A4D33 : (hover && sellable ? 0xFF283448 : 0xFF161D29);
                int border = selected ? 0xFF4ADE80 : (hover && sellable ? 0xFF60A5FA : 0xFF2B3548);
                g.fill(x, y, x + slotSz, y + slotSz, bg);
                drawBorder(g, x, y, slotSz, slotSz, border);

                if (!st.isEmpty()) {
                    g.item(st, x + 3, y + 3);
                    if (st.getCount() > 1) {
                        String cnt = String.valueOf(st.getCount());
                        g.text(this.font, Component.literal(cnt), x + slotSz - this.font.width(cnt) - 1, y + slotSz - 9, 0xFFFFFFFF, true);
                    }
                    if (hover) {
                        List<Component> tip = new ArrayList<>();
                        tip.add(st.getHoverName().copy().withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD));
                        Component wComp = ComputerActions.formatWearComponent(st);
                        if (!wComp.getString().isEmpty()) {
                            tip.add(wComp);
                        }
                        if (sellable) {
                            tip.add(Component.translatable("ui.randomoredrop.val_single", ModEconomy.formatCents(val)).withStyle(ChatFormatting.GOLD));
                            tip.add(Component.translatable(selected ? "ui.randomoredrop.click_deselect" : "ui.randomoredrop.click_select")
                                    .withStyle(selected ? ChatFormatting.RED : ChatFormatting.GREEN));
                        } else {
                            tip.add(Component.translatable("msg.randomoredrop.offhand_unsellable").withStyle(ChatFormatting.RED));
                        }
                        hoveredTip = tip;
                    }
                }
            }
        }

        // Right-side summary & confirmation panel
        int px = startX + gridW + 14;
        int ph = gridH;
        g.fill(px, startY, px + panelW, startY + ph, 0xFF171E2B);
        drawBorder(g, px, startY, panelW, ph, 0xFF2B374D);

        g.centeredText(this.font, Component.translatable("ui.randomoredrop.sell_selected_count", selectedSlotsCount),
                px + panelW / 2, startY + 7, 0xFFCBD5E1);
        g.centeredText(this.font, Component.translatable("ui.randomoredrop.sell_selected_total", ModEconomy.formatCents(selectedTotalCents))
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), px + panelW / 2, startY + 19, 0xFFFFD54F);

        drawButtonVisual(g, px + 8, startY + 34, panelW - 16, 18,
                Component.translatable("ui.randomoredrop.select_minerals_btn"), 0xFF8C6919, 0xFFB88A22, mouseX, mouseY);
        drawButtonVisual(g, px + 8, startY + 56, panelW - 16, 18,
                Component.translatable("ui.randomoredrop.clear_sel_btn"), 0xFF334155, 0xFF475569, mouseX, mouseY);

        Component sellBtnLbl = Component.translatable("ui.randomoredrop.confirm_sell_btn");
        int btnNorm = selectedSlotsCount > 0 ? 0xFF1F7A46 : 0xFF283040;
        int btnHov  = selectedSlotsCount > 0 ? 0xFF29A05C : 0xFF323C4F;
        drawButtonVisual(g, px + 8, startY + 80, panelW - 16, 22, sellBtnLbl, btnNorm, btnHov, mouseX, mouseY);

        if (hoveredTip != null) {
            g.setTooltipForNextFrame(this.font, hoveredTip, Optional.empty(), mouseX, mouseY);
        }
    }

    private void renderBankTab(GuiGraphicsExtractor g, int top, int bot, int mouseX, int mouseY) {
        int W = this.width;
        Item[] coins = {ModItems.COIN_1, ModItems.COIN_10, ModItems.COIN_100, ModItems.COIN_1000, ModItems.COIN_10000};
        String[] labels = {"1", "10", "100", "1,000", "10,000"};
        int[] colors = {0xFF7D5324, 0xFF6B778C, 0xFFA37E18, 0xFF1C7E9E, 0xFF7A32A8};

        int gap = 8;
        int cardW = Math.min(78, (W - 40 - gap * 4) / 5);
        int cardH = 92;
        int totalW = cardW * 5 + gap * 4;
        int startX = (W - totalW) / 2;
        int y = top + Math.max(12, (bot - top - cardH - 42) / 2);

        for (int i = 0; i < 5; i++) {
            int x = startX + i * (cardW + gap);
            drawPanelCard(g, x, y, cardW, cardH, colors[i], 0xFF18202E);
            drawScaledItem(g, new ItemStack(coins[i]), x + cardW / 2 - 16, y + 10, 2.0F);
            g.centeredText(this.font, Component.translatable("ui.randomoredrop.coin_amt", labels[i]), x + cardW / 2, y + 48, 0xFFFFD54F);
            drawButtonVisual(g, x + 8, y + cardH - 24, cardW - 16, 18,
                    Component.translatable("ui.randomoredrop.withdraw_btn"), 0xFF28507A, 0xFF3A72AD, mouseX, mouseY);
        }

        drawButtonVisual(g, startX, y + cardH + 14, totalW, 24,
                Component.translatable("ui.randomoredrop.deposit_all_btn"),
                0xFF1F7A46, 0xFF29A05C, mouseX, mouseY);
    }

    private void drawNavTabVisual(GuiGraphicsExtractor g, int x, int y, int w, int h, Component label, boolean active, int mouseX, int mouseY) {
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        int bg = active ? 0xFF2B6CB0 : (hover ? 0xFF232C3D : 0xFF161C26);
        g.fill(x, y, x + w, y + h, bg);
        if (active) {
            g.fill(x, y + h - 2, x + w, y + h, 0xFF63B3ED);
        }
        g.centeredText(this.font, label, x + w / 2, y + 6, active ? 0xFFFFFFFF : 0xFFB0BCD0);
    }

    private void drawButtonVisual(GuiGraphicsExtractor g, int x, int y, int w, int h, Component text,
                                  int normalBg, int hoverBg, int mouseX, int mouseY) {
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        g.fill(x, y, x + w, y + h, hover ? hoverBg : normalBg);
        drawBorder(g, x, y, w, h, hover ? 0xFFFFFFFF : 0x55FFFFFF);
        g.centeredText(this.font, text, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }

    private void drawPanelCard(GuiGraphicsExtractor g, int x, int y, int w, int h, int headerCol, int bodyCol) {
        drawBorder(g, x - 1, y - 1, w + 2, h + 2, 0xFF2B374D);
        fillVerticalGradient(g, x, y, x + w, y + 44, headerCol, bodyCol);
        g.fill(x, y + 44, x + w, y + h, bodyCol);
    }

    private void drawScaledItem(GuiGraphicsExtractor g, ItemStack stack, int x, int y, float scale) {
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.item(stack, 0, 0);
        g.pose().popMatrix();
    }

    private static void drawBorder(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private static void fillVerticalGradient(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int topArgb, int botArgb) {
        int height = Math.max(1, y2 - y1);
        int bands = Math.min(height, 16);
        int ta = (topArgb >>> 24) & 0xFF, tr = (topArgb >>> 16) & 0xFF, tg = (topArgb >>> 8) & 0xFF, tb = topArgb & 0xFF;
        int ba = (botArgb >>> 24) & 0xFF, br = (botArgb >>> 16) & 0xFF, bg = (botArgb >>> 8) & 0xFF, bb = botArgb & 0xFF;
        for (int i = 0; i < bands; i++) {
            int sy1 = y1 + (i * height) / bands;
            int sy2 = y1 + ((i + 1) * height) / bands;
            float f = bands <= 1 ? 0.0F : i / (float) (bands - 1);
            int a = (int) (ta + (ba - ta) * f);
            int r = (int) (tr + (br - tr) * f);
            int gr = (int) (tg + (bg - tg) * f);
            int b = (int) (tb + (bb - tb) * f);
            int c = (a << 24) | (r << 16) | (gr << 8) | b;
            g.fill(x1, sy1, x2, sy2, c);
        }
    }
}
