package com.example.randomoredrop;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 原創船隻物品表（木種 × 船型）。玩法靈感來自常見船模，內容與程式皆為本模組原創。
 */
public final class ModShips {
    private ModShips() {}

    public record ShipSpec(String wood, String kind, String boatEntityId, int plankCost, Rarity rarity) {}

    /** wood path segment -> vanilla boat entity id */
    private static final String[] WOODS = {
            "oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry", "bamboo", "pale_oak"
    };

    /**
     * kind -> plank cost (成品價值 = 木板成本)
     * rowboat 5, cog 8, brigg 10, drakkar 12, galley 14
     */
    private static final Object[][] KINDS = {
            {"rowboat", 5, Rarity.COMMON},
            {"cog", 8, Rarity.UNCOMMON},
            {"brigg", 10, Rarity.UNCOMMON},
            {"drakkar", 12, Rarity.RARE},
            {"galley", 14, Rarity.RARE},
    };

    public static final Map<String, Item> SHIPS = new LinkedHashMap<>();
    public static final List<ShipSpec> SPECS = new ArrayList<>();

    public static void initialize() {
        if (!SHIPS.isEmpty()) return;
        for (String wood : WOODS) {
            String boatId = wood + "_boat";
            for (Object[] k : KINDS) {
                String kind = (String) k[0];
                int cost = (Integer) k[1];
                Rarity rarity = (Rarity) k[2];
                String name = wood + "_" + kind;
                ShipSpec spec = new ShipSpec(wood, kind, boatId, cost, rarity);
                SPECS.add(spec);
                Item item = registerShip(name, boatId, "item.randomoredrop.ship_kind." + kind, cost, rarity);
                SHIPS.put(name, item);
                // 價值 = 木板數 × 50 cents
                ModEconomy.setExternalCents(item, cost * 50L);
            }
        }
    }

    private static Item registerShip(String name, String boatEntityId, String kindLangKey, int plankCost, Rarity rarity) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
                Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name));
        Item.Properties props = new Item.Properties().stacksTo(1).rarity(rarity).setId(key);
        return Registry.register(BuiltInRegistries.ITEM, key, new ShipItem(boatEntityId, kindLangKey, plankCost, props));
    }
}
