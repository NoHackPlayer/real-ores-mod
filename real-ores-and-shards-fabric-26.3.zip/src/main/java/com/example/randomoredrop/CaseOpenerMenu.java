package com.example.randomoredrop;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class CaseOpenerMenu extends ChestMenu {
    private static final List<CaseOpenerMenu> ACTIVE_SPINS = new CopyOnWriteArrayList<>();

    private static final int REEL_LENGTH = 55;
    private static final int WIN_INDEX = 45;
    private static final int FINAL_OFFSET = WIN_INDEX - 4; // 41 -> slot 22 (dead center of row 2)

    private enum Mode {
        PREVIEW,
        SPINNING,
        RESULT
    }

    private final ServerPlayer owner;
    private final SimpleContainer grid;
    private final String caseId;
    private final long costCents;

    private Mode mode;
    private final List<ComputerActions.CaseEntry> reel = new ArrayList<>();
    private int offset = 0;
    private int ticksUntilNextStep = 0;
    private boolean rewarded = false;
    private boolean closed = false;

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (ACTIVE_SPINS.isEmpty()) {
                return;
            }
            for (CaseOpenerMenu menu : ACTIVE_SPINS) {
                menu.tickSpin();
            }
        });
    }

    public static void openPreview(ServerPlayer player, String caseId, long costCents) {
        Component title = Component.literal("CS:GO 寶箱預覽｜" + ComputerActions.getCaseTitle(caseId))
                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD);
        player.openMenu(new SimpleMenuProvider(
                (syncId, inv, p) -> new CaseOpenerMenu(syncId, inv, player, caseId, costCents, false),
                title
        ));
    }

    public static void openAndSpin(ServerPlayer player, String caseId, long costCents) {
        if (!ModEconomy.spendCents(player.getUUID(), costCents)) {
            long bal = ModEconomy.getBalanceCents(player.getUUID());
            player.sendSystemMessage(Component.literal("金幣不足！需要 " + ModEconomy.formatCents(costCents)
                            + " 金幣（目前餘額：" + ModEconomy.formatCents(bal) + " 金幣）。")
                    .withStyle(ChatFormatting.RED));
            openPreview(player, caseId, costCents);
            return;
        }
        Component title = Component.literal("🎰 CS:GO 開箱中｜" + ComputerActions.getCaseTitle(caseId))
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
        player.openMenu(new SimpleMenuProvider(
                (syncId, inv, p) -> new CaseOpenerMenu(syncId, inv, player, caseId, costCents, true),
                title
        ));
    }

    private CaseOpenerMenu(int syncId, Inventory playerInv, ServerPlayer owner, String caseId, long costCents, boolean startSpinning) {
        this(syncId, playerInv, owner, new SimpleContainer(45), caseId, costCents, startSpinning);
    }

    private CaseOpenerMenu(int syncId, Inventory playerInv, ServerPlayer owner, SimpleContainer grid,
                           String caseId, long costCents, boolean startSpinning) {
        super(MenuType.GENERIC_9x5, syncId, playerInv, grid, 5);
        this.owner = owner;
        this.grid = grid;
        this.caseId = caseId;
        this.costCents = costCents;

        if (startSpinning) {
            beginSpinAlreadyPaid();
        } else {
            this.mode = Mode.PREVIEW;
            renderPreview();
        }
    }

    private void beginSpinAlreadyPaid() {
        this.reel.clear();
        RandomSource rng = this.owner.getRandom();
        for (int i = 0; i < REEL_LENGTH; i++) {
            this.reel.add(ComputerActions.rollCaseEntry(this.caseId, rng));
        }
        this.offset = 0;
        this.ticksUntilNextStep = 1;
        this.rewarded = false;
        this.mode = Mode.SPINNING;
        if (!ACTIVE_SPINS.contains(this)) {
            ACTIVE_SPINS.add(this);
        }
        renderSpinFrame();
        this.broadcastChanges();
    }

    private void tickSpin() {
        if (this.closed || this.mode != Mode.SPINNING) {
            ACTIVE_SPINS.remove(this);
            return;
        }
        if (this.owner.isRemoved() || this.owner.containerMenu != this) {
            finishSpin(true);
            return;
        }

        if (--this.ticksUntilNextStep > 0) {
            return;
        }

        if (this.offset < FINAL_OFFSET) {
            this.offset++;
            this.ticksUntilNextStep = computeDelayForStep(this.offset);
            renderSpinFrame();
            this.broadcastChanges();
            playTickSound(this.offset);
        } else {
            finishSpin(false);
        }
    }

    private static int computeDelayForStep(int step) {
        if (step <= 18) return 1;
        if (step <= 28) return 2;
        if (step <= 34) return 4;
        if (step <= 38) return 7;
        return 11;
    }

    private void playTickSound(int step) {
        float progress = Math.min(1.0F, step / (float) FINAL_OFFSET);
        float pitch = 1.65F - (progress * 0.70F);
        SoundEvent tickSound = BuiltInRegistries.SOUND_EVENT
                .getOptional(Identifier.withDefaultNamespace("block.note_block.hat"))
                .orElse(SoundEvents.EXPERIENCE_ORB_PICKUP);
        this.owner.level().playSound(null, this.owner.blockPosition(), tickSound, SoundSource.PLAYERS, 0.55F, pitch);
    }

    private void finishSpin(boolean silentGuiUpdate) {
        ACTIVE_SPINS.remove(this);
        this.offset = FINAL_OFFSET;
        this.mode = Mode.RESULT;

        if (!this.rewarded && this.reel.size() > WIN_INDEX) {
            this.rewarded = true;
            ComputerActions.CaseEntry winner = this.reel.get(WIN_INDEX);
            ItemStack prize = winner.stack().copy();
            long valCents = ModEconomy.getCents(prize.getItem()) * prize.getCount();

            Component rewardName = prize.getHoverName().copy();
            int rewardCount = prize.getCount();
            ComputerActions.giveOrDrop(this.owner, prize);

            if (winner.tierIndex() >= 4) {
                SoundEvent goldSound = BuiltInRegistries.SOUND_EVENT
                        .getOptional(Identifier.withDefaultNamespace("ui.toast.challenge_complete"))
                        .orElse(SoundEvents.PLAYER_LEVELUP);
                this.owner.level().playSound(null, this.owner.blockPosition(), goldSound, SoundSource.PLAYERS, 0.9F, 1.0F);
            } else if (winner.tierIndex() >= 2) {
                this.owner.level().playSound(null, this.owner.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.85F, 1.15F);
            } else {
                this.owner.level().playSound(null, this.owner.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 0.95F);
            }

            long remaining = ModEconomy.getBalanceCents(this.owner.getUUID());
            this.owner.sendSystemMessage(Component.literal("🎰 開箱獲得 ")
                    .withStyle(ChatFormatting.GOLD)
                    .append(Component.literal("[" + winner.rarityLabel() + "] ").withStyle(winner.color(), ChatFormatting.BOLD))
                    .append(rewardName)
                    .append(Component.literal(" x" + rewardCount).withStyle(ChatFormatting.WHITE))
                    .append(Component.literal("（價值 " + ModEconomy.formatCents(valCents)
                            + " 金幣｜餘額 " + ModEconomy.formatCents(remaining) + " 金幣）").withStyle(ChatFormatting.GRAY)));
        }

        if (!silentGuiUpdate && !this.closed) {
            renderSpinFrame();
            this.broadcastChanges();
        }
    }

    private void renderSpinFrame() {
        ItemStack darkPane = ComputerMenu.makeIcon(Items.BLACK_STAINED_GLASS_PANE, Component.literal(" "), List.of());

        for (int i = 0; i < 9; i++) {
            this.grid.setItem(i, darkPane.copy());
        }
        boolean landed = (this.mode == Mode.RESULT);
        ComputerActions.CaseEntry centerEntry = this.reel.get(Math.min(this.offset + 4, this.reel.size() - 1));
        this.grid.setItem(4, ComputerMenu.makeIcon(
                landed ? Items.NETHER_STAR : Items.REDSTONE_TORCH,
                Component.literal(landed ? "★ 中獎物品 ★" : "▼ 中獎指針 ▼")
                        .withStyle(landed ? centerEntry.color() : ChatFormatting.RED, ChatFormatting.BOLD),
                List.of(Component.literal(landed ? "已發放至背包！" : "指針停止處即為本次獎勵").withStyle(ChatFormatting.GRAY))
        ));

        for (int col = 0; col < 9; col++) {
            int idx = Math.min(this.offset + col, this.reel.size() - 1);
            ComputerActions.CaseEntry entry = this.reel.get(idx);

            boolean isCenter = (col == 4);
            Component topStripTitle = isCenter
                    ? Component.literal("▼ 中獎指針 ▼").withStyle(entry.color(), ChatFormatting.BOLD)
                    : Component.literal(entry.rarityLabel()).withStyle(entry.color());
            Component botStripTitle = isCenter
                    ? Component.literal("▲ 中獎指針 ▲").withStyle(entry.color(), ChatFormatting.BOLD)
                    : Component.literal(entry.rarityLabel()).withStyle(entry.color());

            this.grid.setItem(9 + col, ComputerMenu.makeIcon(entry.glassPane(), topStripTitle, List.of()));

            ItemStack display = entry.stack().copy();
            long valCents = ModEconomy.getCents(display.getItem()) * display.getCount();
            List<Component> lore = List.of(
                    Component.literal("稀有度：" + entry.rarityLabel()).withStyle(entry.color(), ChatFormatting.BOLD),
                    Component.literal("價值：" + ModEconomy.formatCents(valCents) + " 金幣").withStyle(ChatFormatting.GOLD)
            );
            display.set(DataComponents.LORE, new ItemLore(lore));
            this.grid.setItem(18 + col, display);

            this.grid.setItem(27 + col, ComputerMenu.makeIcon(entry.glassPane(), botStripTitle, List.of()));
        }

        for (int i = 36; i < 45; i++) {
            this.grid.setItem(i, darkPane.copy());
        }

        this.grid.setItem(36, ComputerMenu.makeIcon(Items.ARROW,
                Component.literal("← 返回電腦主頁").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD),
                List.of(Component.literal(landed ? "回到多功能電腦介面" : "提前返回（會直接發放本次獎勵）").withStyle(ChatFormatting.GRAY))));

        long bal = ModEconomy.getBalanceCents(this.owner.getUUID());
        this.grid.setItem(44, ComputerMenu.makeIcon(Items.NETHER_STAR,
                Component.literal("餘額：" + ModEconomy.formatCents(bal) + " 金幣").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                List.of()));

        if (this.mode == Mode.SPINNING) {
            this.grid.setItem(40, ComputerMenu.makeIcon(Items.CLOCK,
                    Component.literal("⏩ 跳過動畫（立即開獎）").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD),
                    List.of(Component.literal("點擊立即揭曉本次開箱結果").withStyle(ChatFormatting.GRAY))));
        } else {
            ComputerActions.CaseEntry winner = this.reel.get(WIN_INDEX);
            long winCents = ModEconomy.getCents(winner.stack().getItem()) * winner.stack().getCount();
            long diff = winCents - this.costCents;
            String diffStr = (diff >= 0 ? "+" : "") + ModEconomy.formatCents(diff) + " 金幣";

            this.grid.setItem(38, ComputerMenu.makeIcon(Items.EMERALD_BLOCK,
                    Component.literal("🔁 再抽一次（" + ModEconomy.formatCents(this.costCents) + " 金幣）")
                            .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
                    List.of(Component.literal("點擊立刻開始下一輪 CS:GO 滾動").withStyle(ChatFormatting.GRAY))));

            ItemStack resultIcon = winner.stack().copy();
            resultIcon.set(DataComponents.LORE, new ItemLore(List.of(
                    Component.literal("等級：" + winner.rarityLabel()).withStyle(winner.color(), ChatFormatting.BOLD),
                    Component.literal("價值：" + ModEconomy.formatCents(winCents) + " 金幣").withStyle(ChatFormatting.GOLD),
                    Component.literal("盈虧：" + diffStr).withStyle(diff >= 0 ? ChatFormatting.GREEN : ChatFormatting.RED)
            )));
            this.grid.setItem(40, resultIcon);

            this.grid.setItem(42, ComputerMenu.makeIcon(Items.SPYGLASS,
                    Component.literal("🔍 預覽掉落物與機率").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD),
                    List.of(Component.literal("檢視此寶箱全部可能開出的物品").withStyle(ChatFormatting.GRAY))));
        }
    }

    private void renderPreview() {
        ItemStack darkPane = ComputerMenu.makeIcon(Items.BLACK_STAINED_GLASS_PANE, Component.literal(" "), List.of());
        for (int i = 0; i < 45; i++) {
            this.grid.setItem(i, darkPane.copy());
        }

        ComputerActions.CaseDef def = ComputerActions.getCaseDef(this.caseId);
        this.grid.setItem(4, ComputerMenu.makeIcon(def.icon(),
                Component.literal(def.displayName() + "（" + ModEconomy.formatCents(this.costCents) + " 金幣）")
                        .withStyle(def.titleColor(), ChatFormatting.BOLD),
                List.of(
                        Component.literal("藍 52.0%｜紫 26.5%｜粉 14.5%").withStyle(ChatFormatting.AQUA),
                        Component.literal("紅 5.5%｜金 ★罕見極品 1.5%").withStyle(ChatFormatting.GOLD)
                )));

        List<ComputerActions.PreviewEntry> preview = ComputerActions.getPreviewEntries(this.caseId);
        int maxSlots = Math.min(preview.size(), 27);
        for (int i = 0; i < maxSlots; i++) {
            ComputerActions.PreviewEntry entry = preview.get(i);
            ItemStack st = new ItemStack(entry.item(), entry.minCount());
            long minVal = ModEconomy.getCents(entry.item()) * entry.minCount();
            long maxVal = ModEconomy.getCents(entry.item()) * entry.maxCount();
            String countTxt = entry.minCount() == entry.maxCount()
                    ? ("數量：" + entry.minCount() + " 個")
                    : ("數量：" + entry.minCount() + "–" + entry.maxCount() + " 個");
            String valTxt = minVal == maxVal
                    ? ("價值：" + ModEconomy.formatCents(minVal) + " 金幣")
                    : ("價值：" + ModEconomy.formatCents(minVal) + "–" + ModEconomy.formatCents(maxVal) + " 金幣");
            st.set(DataComponents.LORE, new ItemLore(List.of(
                    Component.literal("等級：" + entry.rarityLabel()).withStyle(entry.color(), ChatFormatting.BOLD),
                    Component.literal("區間機率：" + entry.chanceText()).withStyle(ChatFormatting.YELLOW),
                    Component.literal(countTxt).withStyle(ChatFormatting.WHITE),
                    Component.literal(valTxt).withStyle(ChatFormatting.GOLD)
            )));
            this.grid.setItem(9 + i, st);
        }

        this.grid.setItem(36, ComputerMenu.makeIcon(Items.ARROW,
                Component.literal("← 返回電腦主頁").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD),
                List.of(Component.literal("回到多功能電腦介面").withStyle(ChatFormatting.GRAY))));

        this.grid.setItem(40, ComputerMenu.makeIcon(Items.EMERALD_BLOCK,
                Component.literal("🎰 開始 CS:GO 滾動開箱（" + ModEconomy.formatCents(this.costCents) + " 金幣）")
                        .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
                List.of(Component.literal("點擊立即扣款並開始橫向滾動抽獎").withStyle(ChatFormatting.GRAY))));

        long bal = ModEconomy.getBalanceCents(this.owner.getUUID());
        this.grid.setItem(44, ComputerMenu.makeIcon(Items.NETHER_STAR,
                Component.literal("餘額：" + ModEconomy.formatCents(bal) + " 金幣").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                List.of()));
    }

    @Override
    public void clicked(int slotId, int button, ContainerInput containerInput, Player player) {
        if (slotId >= 0 && slotId < 45) {
            if (player instanceof ServerPlayer sp) {
                handleClick(sp, slotId);
            }
            return;
        }
        if (containerInput == ContainerInput.QUICK_MOVE) {
            return;
        }
        super.clicked(slotId, button, containerInput, player);
    }

    private void handleClick(ServerPlayer sp, int slot) {
        if (slot == 36) {
            if (this.mode == Mode.SPINNING) {
                finishSpin(true);
            }
            ComputerItem.openFor(sp);
            return;
        }

        if (this.mode == Mode.SPINNING) {
            if (slot == 40) {
                finishSpin(false);
            }
            return;
        }

        if (this.mode == Mode.PREVIEW) {
            if (slot == 40) {
                trySpinAgain(sp);
            }
            return;
        }

        if (this.mode == Mode.RESULT) {
            if (slot == 38) {
                trySpinAgain(sp);
            } else if (slot == 42) {
                this.mode = Mode.PREVIEW;
                renderPreview();
                this.broadcastChanges();
            }
        }
    }

    private void trySpinAgain(ServerPlayer sp) {
        if (!ModEconomy.spendCents(sp.getUUID(), this.costCents)) {
            long bal = ModEconomy.getBalanceCents(sp.getUUID());
            sp.sendSystemMessage(Component.literal("金幣不足！需要 " + ModEconomy.formatCents(this.costCents)
                            + " 金幣（目前餘額：" + ModEconomy.formatCents(bal) + " 金幣）。")
                    .withStyle(ChatFormatting.RED));
            return;
        }
        beginSpinAlreadyPaid();
    }

    @Override
    public void removed(Player player) {
        this.closed = true;
        if (this.mode == Mode.SPINNING && !this.rewarded) {
            finishSpin(true);
        }
        ACTIVE_SPINS.remove(this);
        super.removed(player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }
}
