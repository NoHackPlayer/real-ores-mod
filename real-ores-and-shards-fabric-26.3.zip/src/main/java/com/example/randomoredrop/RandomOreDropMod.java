package com.example.randomoredrop;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

import java.util.ArrayList;
import java.util.List;

public class RandomOreDropMod implements ModInitializer {
    public static final String MOD_ID = "randomoredrop";

    private static final int MIN_SHARDS = 1;
    private static final int MAX_SHARDS = 4;
    private static final float WORLD_LOOT_MINERAL_KEEP_CHANCE = 0.35f;

    @Override
    public void onInitialize() {
        ModBlocks.initialize();
        ModItems.initialize();
        ModEconomy.initialize();
        ModWorldGen.initialize();
        UpgraderCompat.initialize();
        ComputerNetwork.registerCommon();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            ModEconomy.load(server);
            UpgraderCompat.syncWithUpgrader();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> ModEconomy.save());

        LootTableEvents.MODIFY_DROPS.register((holder, context, drops) -> {
            if (drops.isEmpty()) {
                return;
            }
            RandomSource random = context.getRandom();
            BlockState state = context.getOptional(LootContextParams.BLOCK_STATE);

            if (state != null) {
                if (!state.is(ConventionalBlockTags.ORES)) {
                    return;
                }

                ItemInstance toolInstance = context.getOptional(LootContextParams.TOOL);
                int fortuneLevel = 0;
                if (toolInstance instanceof ItemStack tool && !tool.isEmpty()) {
                    Holder<Enchantment> fortune = context.getLevel()
                            .registryAccess()
                            .lookupOrThrow(Registries.ENCHANTMENT)
                            .getOrThrow(Enchantments.FORTUNE);
                    fortuneLevel = EnchantmentHelper.getItemEnchantmentLevel(fortune, tool);
                }

                for (int i = 0; i < drops.size(); i++) {
                    ItemStack original = drops.get(i);
                    Item shard = ModItems.ORE_TO_SHARD.get(original.getItem());
                    if (shard != null) {
                        int baseCount = random.nextIntBetweenInclusive(MIN_SHARDS, MAX_SHARDS);
                        int fortuneBonus = fortuneLevel > 0 ? random.nextInt(fortuneLevel + 1) : 0;
                        drops.set(i, new ItemStack(shard, baseCount + fortuneBonus));
                    }
                }
                return;
            }

            // 鐵巨人掉落調整：固定改為 1-5 顆隨機鐵粒，大幅降低虞美人（玫瑰）掉落機率至 15%
            boolean isIronGolem = holder.unwrapKey()
                    .map(k -> k.identifier().equals(Identifier.withDefaultNamespace("entities/iron_golem")))
                    .orElse(false);
            if (isIronGolem) {
                drops.clear();
                drops.add(new ItemStack(Items.IRON_NUGGET, random.nextIntBetweenInclusive(1, 5)));
                if (random.nextFloat() < 0.15f) {
                    drops.add(new ItemStack(Items.POPPY, 1));
                }
                return;
            }

            List<ItemStack> updated = new ArrayList<>(drops.size());
            for (ItemStack stack : drops) {
                if (stack.isEmpty()) {
                    continue;
                }
                // 移除所有經驗修補附魔書與裝備上的經驗修補附魔
                ItemEnchantments storedEnch = stack.get(DataComponents.STORED_ENCHANTMENTS);
                if (storedEnch != null) {
                    boolean hasMendingBook = false;
                    for (Holder<Enchantment> h : storedEnch.keySet()) {
                        if (h.is(Enchantments.MENDING)) {
                            hasMendingBook = true;
                            break;
                        }
                    }
                    if (hasMendingBook) {
                        continue;
                    }
                }
                EnchantmentHelper.updateEnchantments(stack, mutable -> mutable.removeIf(h -> h.is(Enchantments.MENDING)));

                Item item = stack.getItem();
                Item shard = ModItems.LOOT_MINERAL_TO_SHARD.get(item);
                if (shard != null) {
                    if (random.nextFloat() <= WORLD_LOOT_MINERAL_KEEP_CHANCE) {
                        updated.add(new ItemStack(shard, random.nextIntBetweenInclusive(1, 2)));
                    }
                    continue;
                }
                if (item == Items.IRON_NUGGET || item == Items.GOLD_NUGGET
                        || item == Items.NETHERITE_SCRAP || item == Items.NETHERITE_INGOT
                        || item == Items.ANCIENT_DEBRIS) {
                    if (random.nextFloat() <= 0.30f) {
                        ItemStack reduced = stack.copy();
                        reduced.setCount(1);
                        updated.add(reduced);
                    }
                    continue;
                }
                String ns = BuiltInRegistries.ITEM.getKey(item).getNamespace();
                if ("artifacts".equals(ns) && random.nextFloat() < 0.55f) {
                    continue;
                }
                updated.add(stack);
            }
            drops.clear();
            drops.addAll(updated);
        });
    }
}
