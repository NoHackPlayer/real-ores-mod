package com.example.randomoredrop;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

import java.util.ArrayList;
import java.util.List;

public class RandomOreDropMod implements ModInitializer {
    public static final String MOD_ID = "randomoredrop";

    private static final int MIN_SHARDS = 1;
    private static final int MAX_SHARDS = 4;
    private static final float WORLD_LOOT_MINERAL_KEEP_CHANCE = 0.35f;

    @Override
    public void onInitialize() {
        ModBlocks.initialize();
        ModItems.initialize();
        ModEconomy.initialize();
        ModArtifacts.initialize();
        ModWorldGen.initialize();
        UpgraderCompat.initialize();
        CaseOpenerMenu.initialize();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            ModEconomy.load(server);
            UpgraderCompat.syncWithUpgrader();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> ModEconomy.save());

        LootTableEvents.MODIFY_DROPS.register((holder, context, drops) -> {
            if (drops.isEmpty()) {
                return;
            }
            RandomSource random = context.getRandom();
            BlockState state = context.getOptional(LootContextParams.BLOCK_STATE);

            if (state != null) {
                if (!state.is(ConventionalBlockTags.ORES)) {
                    return;
                }

                ItemInstance toolInstance = context.getOptional(LootContextParams.TOOL);
                int fortuneLevel = 0;
                if (toolInstance instanceof ItemStack tool && !tool.isEmpty()) {
                    Holder<Enchantment> fortune = context.getLevel()
                            .registryAccess()
                            .lookupOrThrow(Registries.ENCHANTMENT)
                            .getOrThrow(Enchantments.FORTUNE);
                    fortuneLevel = EnchantmentHelper.getItemEnchantmentLevel(fortune, tool);
                }

                net.minecraft.world.entity.Entity miner = context.getOptional(LootContextParams.THIS_ENTITY);
                net.minecraft.server.level.ServerPlayer serverMiner = (miner instanceof net.minecraft.server.level.ServerPlayer sp) ? sp : null;
                boolean hasResonator = serverMiner != null && ModArtifacts.isEquipped(serverMiner, ModItems.SHARD_RESONATOR_NECKLACE);
                boolean hasMerchantRing = serverMiner != null && ModArtifacts.isEquipped(serverMiner, ModItems.MERCHANT_FORTUNE_RING);

                for (int i = 0; i < drops.size(); i++) {
                    ItemStack original = drops.get(i);
                    Item shard = ModItems.ORE_TO_SHARD.get(original.getItem());
                    if (shard != null) {
                        int baseCount = random.nextIntBetweenInclusive(MIN_SHARDS, MAX_SHARDS);
                        int fortuneBonus = fortuneLevel > 0 ? random.nextInt(fortuneLevel + 1) : 0;
                        int resonatorBonus = (hasResonator && random.nextFloat() < 0.30f) ? 1 : 0;
                        drops.set(i, new ItemStack(shard, baseCount + fortuneBonus + resonatorBonus));

                        if (hasMerchantRing) {
                            long shardCents = ModEconomy.getCents(shard);
                            long pocketBonus = Math.max(50L, Math.min(300L, shardCents / 4L));
                            ModEconomy.addCents(serverMiner.getUUID(), pocketBonus);
                        }
                    }
                }
                return;
            }

            List<ItemStack> updated = new ArrayList<>(drops.size());
            for (ItemStack stack : drops) {
                if (stack.isEmpty()) {
                    continue;
                }
                Item item = stack.getItem();
                Item shard = ModItems.LOOT_MINERAL_TO_SHARD.get(item);
                if (shard != null) {
                    if (random.nextFloat() <= WORLD_LOOT_MINERAL_KEEP_CHANCE) {
                        updated.add(new ItemStack(shard, random.nextIntBetweenInclusive(1, 2)));
                    }
                    continue;
                }
                if (item == Items.IRON_NUGGET || item == Items.GOLD_NUGGET
                        || item == Items.NETHERITE_SCRAP || item == Items.NETHERITE_INGOT
                        || item == Items.ANCIENT_DEBRIS) {
                    if (random.nextFloat() <= 0.30f) {
                        ItemStack reduced = stack.copy();
                        reduced.setCount(1);
                        updated.add(reduced);
                    }
                    continue;
                }
                String ns = BuiltInRegistries.ITEM.getKey(item).getNamespace();
                if ("artifacts".equals(ns) && random.nextFloat() < 0.55f) {
                    continue;
                }
                updated.add(stack);
            }
            boolean isChest = holder.unwrapKey()
                    .map(k -> k.identifier().getPath().startsWith("chests/"))
                    .orElse(false);
            if (isChest && random.nextFloat() < 0.04f) {
                updated.add(ModArtifacts.rollRandomArtifact(random));
            }
            drops.clear();
            drops.addAll(updated);
        });
    }
}
