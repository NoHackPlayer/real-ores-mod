package com.example.randomoredrop;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ComputerActions {
    // 統一 CS:GO 5 階稀有度權重（總和 1000）：藍 52.0% | 紫 26.5% | 粉 14.5% | 紅 5.5% | 金 1.5%
    private static final int[] TIER_THRESHOLDS = {520, 785, 930, 985, 1000};
    private static final String[] TIER_CHANCES = {"52.0%", "26.5%", "14.5%", "5.5%", "1.5%"};

    public record DropSpec(Item item, int minCount, int maxCount) {}

    public record CaseDef(
            String id,
            String displayName,
            String subtitle,
            Item icon,
            ChatFormatting titleColor,
            long costCents,
            List<List<DropSpec>> tiers
    ) {}

    public record CaseEntry(
            ItemStack stack,
            int tierIndex,
            String rarityLabel,
            ChatFormatting color,
            Item glassPane,
            String chanceText
    ) {}

    public record PreviewEntry(
            Item item,
            int minCount,
            int maxCount,
            int tierIndex,
            String rarityLabel,
            ChatFormatting color,
            String chanceText
    ) {}

    private static Map<String, CaseDef> CASES;

    private static Map<String, CaseDef> getCases() {
        if (CASES != null) {
            return CASES;
        }
        Map<String, CaseDef> map = new LinkedHashMap<>();

        // 1. 新手補給箱 (10 金幣 | 期望值 ~7.7 金幣 / 77%)
        map.put("starter", new CaseDef(
                "starter", "🪵 新手補給箱", "基礎礦物碎片與入門裝備",
                Items.BARREL, ChatFormatting.WHITE, 1000L,
                List.of(
                        List.of(d(Items.COAL, 2, 4), d(Items.COPPER_INGOT, 1, 2), d(ModItems.TIN_SHARD, 3, 5), d(Items.REDSTONE, 1, 2)),
                        List.of(d(ModItems.TIN_INGOT, 2, 3), d(ModItems.IRON_SHARD, 3, 4), d(Items.LAPIS_LAZULI, 2, 3), d(ModItems.TIN_SWORD, 1, 1)),
                        List.of(d(Items.IRON_INGOT, 1, 2), d(ModItems.GOLD_SHARD, 3, 4), d(ModItems.SILVER_SHARD, 2, 3), d(ModItems.TIN_PICKAXE, 1, 2)),
                        List.of(d(Items.IRON_PICKAXE, 1, 1), d(ModItems.SILVER_INGOT, 1, 2), d(ModItems.TIN_CHESTPLATE, 1, 1), d(ModItems.EMERALD_SHARD, 2, 2)),
                        List.of(d(ModItems.DIAMOND_SHARD, 1, 2), d(Items.EMERALD, 1, 1), d(Items.IRON_CHESTPLATE, 1, 1))
                )
        ));

        // 2. 礦工寶箱 (50 金幣 | 期望值 ~43.5 金幣 / 87%)
        map.put("miner", new CaseDef(
                "miner", "⛏ 礦工寶箱", "鐵銀裝備、礦磚，低機率出鈦錠",
                Items.CHEST, ChatFormatting.GREEN, 5000L,
                List.of(
                        List.of(d(Items.IRON_INGOT, 1, 3), d(ModItems.TIN_INGOT, 4, 6), d(ModItems.GOLD_SHARD, 3, 5), d(Items.OBSIDIAN, 2, 3)),
                        List.of(d(ModItems.SILVER_INGOT, 1, 2), d(ModItems.EMERALD_SHARD, 2, 3), d(Items.IRON_PICKAXE, 1, 2), d(Items.GHAST_TEAR, 1, 1)),
                        List.of(d(Items.EMERALD, 1, 1), d(ModItems.SILVER_PICKAXE, 1, 1), d(Items.IRON_CHESTPLATE, 1, 1), d(Items.IRON_BLOCK, 1, 1)),
                        List.of(d(Items.DIAMOND, 1, 1), d(ModItems.SILVER_CHESTPLATE, 1, 1), d(Items.GOLD_BLOCK, 1, 1), d(Items.SHULKER_SHELL, 1, 1)),
                        List.of(d(ModItems.TITANIUM_INGOT, 1, 1), d(Items.DIAMOND, 2, 2), d(Items.GOLDEN_APPLE, 1, 1))
                )
        ));

        // 3. 寶石商箱 (200 金幣 | 期望值 ~168.7 金幣 / 84%)
        map.put("gem", new CaseDef(
                "gem", "💎 寶石商箱", "鑽石、鈦錠、圖騰，金賞出鑽甲／奇物",
                Items.ENDER_CHEST, ChatFormatting.AQUA, 20000L,
                List.of(
                        List.of(d(Items.EMERALD, 1, 1), d(ModItems.SILVER_INGOT, 3, 4), d(ModItems.DIAMOND_SHARD, 1, 2), d(Items.GHAST_TEAR, 1, 2)),
                        List.of(d(Items.DIAMOND, 1, 1), d(ModItems.SILVER_CHESTPLATE, 1, 1), d(Items.SHULKER_SHELL, 1, 1), d(ModItems.TITANIUM_SHARD, 1, 1)),
                        List.of(d(ModItems.TITANIUM_SHARD, 2, 2), d(Items.GOLDEN_APPLE, 1, 1), d(Items.ANVIL, 1, 1), d(Items.DIAMOND, 2, 2)),
                        List.of(d(ModItems.TITANIUM_INGOT, 1, 1), d(Items.TOTEM_OF_UNDYING, 1, 1), d(Items.EMERALD_BLOCK, 1, 1)),
                        List.of(d(Items.DIAMOND_CHESTPLATE, 1, 1), d(ModItems.GRAVITY_ANCHOR_BOOTS, 1, 1), d(ModItems.ALCHEMIST_COIN_BELT, 1, 1))
                )
        ));

        // 4. 遠古奇物箱 (700 金幣 | 期望值 ~561.2 金幣 / 80%)
        map.put("artifact", new CaseDef(
                "artifact", "🏺 遠古奇物箱", "主打 6 款穿戴奇物與稀有原版珍寶",
                Items.AMETHYST_CLUSTER, ChatFormatting.LIGHT_PURPLE, 70000L,
                List.of(
                        List.of(d(Items.DIAMOND, 1, 2), d(ModItems.TITANIUM_SHARD, 1, 2), d(Items.ANVIL, 1, 1), d(Items.GOLDEN_APPLE, 1, 1)),
                        List.of(d(ModItems.TITANIUM_INGOT, 1, 1), d(Items.TOTEM_OF_UNDYING, 1, 1), d(ModItems.TUNGSTEN_SHARD, 1, 1), d(Items.DIAMOND, 2, 3)),
                        List.of(d(ModItems.GRAVITY_ANCHOR_BOOTS, 1, 1), d(ModItems.ALCHEMIST_COIN_BELT, 1, 1), d(ModItems.VEIN_COMPASS_CROWN, 1, 1)),
                        List.of(d(ModItems.SHARD_RESONATOR_NECKLACE, 1, 1), d(ModItems.SHARD_COMPRESSOR_GLOVE, 1, 1), d(ModItems.TUNGSTEN_INGOT, 1, 1)),
                        List.of(d(Items.ELYTRA, 1, 1), d(Items.ENCHANTED_GOLDEN_APPLE, 1, 1), d(ModItems.MERCHANT_FORTUNE_RING, 1, 1))
                )
        ));

        // 5. 鍛造武器箱 (1,800 金幣 | 期望值 ~1,462.3 金幣 / 81%)
        map.put("armory", new CaseDef(
                "armory", "⚔ 鍛造武器箱", "鑽石／鈦／防火鎢全系列武器與護甲",
                Items.SHULKER_BOX, ChatFormatting.YELLOW, 180000L,
                List.of(
                        List.of(d(Items.DIAMOND_PICKAXE, 1, 1), d(Items.DIAMOND_BOOTS, 1, 1), d(ModItems.TITANIUM_INGOT, 1, 1), d(ModItems.TUNGSTEN_SHARD, 1, 2)),
                        List.of(d(ModItems.TITANIUM_SWORD, 1, 1), d(Items.DIAMOND_LEGGINGS, 1, 1), d(ModItems.TITANIUM_PICKAXE, 1, 1), d(Items.DIAMOND_CHESTPLATE, 1, 1)),
                        List.of(d(ModItems.TITANIUM_BOOTS, 1, 1), d(ModItems.TITANIUM_HELMET, 1, 1), d(ModItems.TUNGSTEN_SWORD, 1, 1)),
                        List.of(d(ModItems.TITANIUM_CHESTPLATE, 1, 1), d(ModItems.TUNGSTEN_PICKAXE, 1, 1), d(Items.NETHERITE_CHESTPLATE, 1, 1)),
                        List.of(d(ModItems.TUNGSTEN_BOOTS, 1, 1), d(ModItems.TUNGSTEN_HELMET, 1, 1), d(ModItems.TUNGSTEN_LEGGINGS, 1, 1))
                )
        ));

        // 6. 深淵獄髓箱 (4,000 金幣 | 期望值 ~3,317.1 金幣 / 83%)
        map.put("netherite", new CaseDef(
                "netherite", "🔥 深淵獄髓箱", "遠古遺骸、獄髓裝備與頂級鎢甲",
                Items.ANCIENT_DEBRIS, ChatFormatting.RED, 400000L,
                List.of(
                        List.of(d(Items.ANCIENT_DEBRIS, 1, 2), d(ModItems.TUNGSTEN_INGOT, 1, 1), d(ModItems.TITANIUM_BOOTS, 1, 1), d(Items.DIAMOND_BLOCK, 1, 1)),
                        List.of(d(Items.NETHERITE_INGOT, 1, 1), d(Items.ELYTRA, 1, 1), d(ModItems.MERCHANT_FORTUNE_RING, 1, 1), d(ModItems.TITANIUM_HELMET, 1, 1)),
                        List.of(d(Items.NETHERITE_CHESTPLATE, 1, 1), d(ModItems.TUNGSTEN_PICKAXE, 1, 1), d(Items.NETHER_STAR, 1, 1), d(ModItems.TUNGSTEN_BOOTS, 1, 1)),
                        List.of(d(ModItems.TUNGSTEN_HELMET, 1, 1), d(ModItems.TUNGSTEN_LEGGINGS, 1, 1), d(Items.BEACON, 1, 2), d(Items.NETHERITE_INGOT, 2, 3)),
                        List.of(d(ModItems.TUNGSTEN_CHESTPLATE, 1, 2), d(Items.NETHERITE_BLOCK, 1, 1), d(Items.NETHER_STAR, 3, 3))
                )
        ));

        // 7. 終極傳說箱 (10,000 金幣 | 期望值 ~7,504.7 金幣 / 75%)
        map.put("legendary", new CaseDef(
                "legendary", "👑 終極傳說箱", "豪賭專區：大量獄髓磚、烽火台與頂級鎢甲",
                Items.BEACON, ChatFormatting.GOLD, 1000000L,
                List.of(
                        List.of(d(Items.NETHERITE_CHESTPLATE, 1, 1), d(ModItems.TUNGSTEN_PICKAXE, 1, 1), d(Items.NETHERITE_INGOT, 1, 1), d(ModItems.TUNGSTEN_SWORD, 1, 1)),
                        List.of(d(ModItems.TUNGSTEN_BOOTS, 1, 1), d(ModItems.TUNGSTEN_HELMET, 1, 1), d(Items.NETHER_STAR, 1, 1), d(Items.BEACON, 1, 1)),
                        List.of(d(ModItems.TUNGSTEN_LEGGINGS, 1, 1), d(ModItems.TUNGSTEN_CHESTPLATE, 1, 1), d(Items.NETHERITE_INGOT, 3, 4), d(Items.ENCHANTED_GOLDEN_APPLE, 3, 4)),
                        List.of(d(Items.NETHERITE_BLOCK, 1, 1), d(ModItems.TUNGSTEN_CHESTPLATE, 2, 2), d(Items.NETHER_STAR, 3, 4)),
                        List.of(d(Items.NETHERITE_BLOCK, 1, 2), d(ModItems.TUNGSTEN_CHESTPLATE, 3, 3), d(Items.BEACON, 5, 6))
                )
        ));

        CASES = map;
        return CASES;
    }

    private static DropSpec d(Item item, int min, int max) {
        return new DropSpec(item, min, max);
    }

    public static CaseDef getCaseDef(String caseId) {
        Map<String, CaseDef> map = getCases();
        return map.getOrDefault(caseId, map.get("starter"));
    }

    public static String getCaseTitle(String caseId) {
        return getCaseDef(caseId).displayName();
    }

    public static void withdrawSingle(ServerPlayer player, long wholeCoins, Item coinItem) {
        long centsNeeded = wholeCoins * 100L;
        if (!ModEconomy.spendCents(player.getUUID(), centsNeeded)) {
            player.sendSystemMessage(Component.literal("餘額不足！無法提款 " + wholeCoins + " 金幣。")
                    .withStyle(ChatFormatting.RED));
            return;
        }
        giveOrDrop(player, new ItemStack(coinItem, 1));
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.1F);
        long bal = ModEconomy.getBalanceCents(player.getUUID());
        player.sendSystemMessage(Component.literal("已提款 " + wholeCoins + " 金幣（餘額：" + ModEconomy.formatCents(bal) + " 金幣）")
                .withStyle(ChatFormatting.YELLOW));
    }

    public static void depositAll(ServerPlayer player) {
        Inventory inv = player.getInventory();
        long totalCentsAdded = 0L;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && st.getItem() instanceof CoinItem coin) {
                totalCentsAdded += coin.getCentsValue() * st.getCount();
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
        if (totalCentsAdded <= 0L) {
            player.sendSystemMessage(Component.literal("背包裡沒有可存入的實體金幣。").withStyle(ChatFormatting.RED));
            return;
        }
        long newBal = ModEconomy.addCents(player.getUUID(), totalCentsAdded);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.4F);
        player.sendSystemMessage(Component.literal("已存入 " + ModEconomy.formatCents(totalCentsAdded) + " 金幣（餘額：" + ModEconomy.formatCents(newBal) + " 金幣）")
                .withStyle(ChatFormatting.GREEN));
    }

    public static void sellOffhand(ServerPlayer player) {
        ItemStack stack = player.getOffhandItem();
        if (stack.isEmpty()) {
            player.sendSystemMessage(Component.literal("請先把要販售的物品放進副手再點擊此按鈕！").withStyle(ChatFormatting.RED));
            return;
        }
        if (stack.getItem() instanceof CoinItem coin) {
            long cents = coin.getCentsValue() * stack.getCount();
            stack.setCount(0);
            long total = ModEconomy.addCents(player.getUUID(), cents);
            player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.35F);
            player.sendSystemMessage(Component.literal("已存入 " + ModEconomy.formatCents(cents) + " 金幣（餘額：" + ModEconomy.formatCents(total) + " 金幣）")
                    .withStyle(ChatFormatting.GREEN));
            return;
        }
        long unitCents = ModEconomy.getCents(stack.getItem());
        if (unitCents <= 0L) {
            player.sendSystemMessage(Component.literal("副手物品無法販售。").withStyle(ChatFormatting.RED));
            return;
        }
        int count = stack.getCount();
        long earned = unitCents * count;
        if (ModArtifacts.isEquipped(player, ModItems.ALCHEMIST_COIN_BELT)) {
            earned = Math.round(earned * 1.15);
        }
        Component itemName = stack.getHoverName().copy();
        stack.setCount(0);
        long total = ModEconomy.addCents(player.getUUID(), earned);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.2F);
        player.sendSystemMessage(Component.literal("已售出 ")
                .withStyle(ChatFormatting.GREEN)
                .append(itemName)
                .append(Component.literal(" x" + count + "，獲得 " + ModEconomy.formatCents(earned) + " 金幣（餘額：" + ModEconomy.formatCents(total) + " 金幣）").withStyle(ChatFormatting.GOLD)));
    }

    public static void sellAllMinerals(ServerPlayer player) {
        Inventory inv = player.getInventory();
        long earned = 0L;
        int soldItems = 0;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty() || stack.getItem() instanceof CoinItem) {
                continue;
            }
            if (ModEconomy.isBulkSellable(stack.getItem())) {
                long unitCents = ModEconomy.getCents(stack.getItem());
                if (unitCents > 0L) {
                    earned += unitCents * stack.getCount();
                    soldItems += stack.getCount();
                    inv.setItem(i, ItemStack.EMPTY);
                }
            }
        }
        if (earned <= 0L) {
            player.sendSystemMessage(Component.literal("背包中沒有可批次販售的礦物或碎片。").withStyle(ChatFormatting.RED));
            return;
        }
        if (ModArtifacts.isEquipped(player, ModItems.ALCHEMIST_COIN_BELT)) {
            earned = Math.round(earned * 1.15);
        }
        long total = ModEconomy.addCents(player.getUUID(), earned);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.3F);
        player.sendSystemMessage(Component.literal("已批次售出 " + soldItems + " 個礦物/碎片，獲得 "
                + ModEconomy.formatCents(earned) + " 金幣（餘額：" + ModEconomy.formatCents(total) + " 金幣）").withStyle(ChatFormatting.GOLD));
    }

    private static String rarityName(int tierIdx) {
        return switch (tierIdx) {
            case 0 -> "軍規級";
            case 1 -> "受限級";
            case 2 -> "保密級";
            case 3 -> "隱秘級";
            default -> "★ 罕見極品 ★";
        };
    }

    private static ChatFormatting rarityColor(int tierIdx) {
        return switch (tierIdx) {
            case 0 -> ChatFormatting.BLUE;
            case 1 -> ChatFormatting.DARK_PURPLE;
            case 2 -> ChatFormatting.LIGHT_PURPLE;
            case 3 -> ChatFormatting.RED;
            default -> ChatFormatting.GOLD;
        };
    }

    private static Item rarityPane(int tierIdx) {
        return switch (tierIdx) {
            case 0 -> Items.BLUE_STAINED_GLASS_PANE;
            case 1 -> Items.PURPLE_STAINED_GLASS_PANE;
            case 2 -> Items.MAGENTA_STAINED_GLASS_PANE;
            case 3 -> Items.RED_STAINED_GLASS_PANE;
            default -> Items.YELLOW_STAINED_GLASS_PANE;
        };
    }

    public static CaseEntry rollCaseEntry(String caseId, RandomSource rng) {
        CaseDef def = getCaseDef(caseId);
        int roll = rng.nextInt(1000);
        int tierIdx = 4;
        for (int i = 0; i < TIER_THRESHOLDS.length; i++) {
            if (roll < TIER_THRESHOLDS[i]) {
                tierIdx = i;
                break;
            }
        }
        List<DropSpec> pool = def.tiers().get(tierIdx);
        DropSpec pick = pool.get(rng.nextInt(pool.size()));
        int count = pick.minCount() == pick.maxCount()
                ? pick.minCount()
                : rng.nextIntBetweenInclusive(pick.minCount(), pick.maxCount());
        return new CaseEntry(
                new ItemStack(pick.item(), count),
                tierIdx,
                rarityName(tierIdx),
                rarityColor(tierIdx),
                rarityPane(tierIdx),
                TIER_CHANCES[tierIdx]
        );
    }

    public static List<PreviewEntry> getPreviewEntries(String caseId) {
        CaseDef def = getCaseDef(caseId);
        List<PreviewEntry> out = new ArrayList<>();
        for (int t = 0; t < def.tiers().size(); t++) {
            for (DropSpec spec : def.tiers().get(t)) {
                out.add(new PreviewEntry(
                        spec.item(), spec.minCount(), spec.maxCount(),
                        t, rarityName(t), rarityColor(t), TIER_CHANCES[t]
                ));
            }
        }
        return out;
    }

    public static void giveOrDrop(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) {
            player.level().addFreshEntity(new ItemEntity(player.level(), player.getX(), player.getY(), player.getZ(), stack));
        }
    }
}
