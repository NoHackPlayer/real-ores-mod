package com.example.randomoredrop;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ComputerActions {
    // 統一 CS:GO 5 階稀有度權重（總和 1000）：藍 52.0% | 紫 26.5% | 粉 14.5% | 紅 5.5% | 金 1.5%
    private static final int[] TIER_THRESHOLDS = {520, 785, 930, 985, 1000};
    private static final String[] TIER_CHANCES = {"52.0%", "26.5%", "14.5%", "5.5%", "1.5%"};

    public record DropSpec(Item item, int minCount, int maxCount) {}

    public record CaseDef(
            String id,
            String displayName,
            String subtitle,
            Item icon,
            ChatFormatting titleColor,
            long costCents,
            List<List<DropSpec>> tiers
    ) {}

    public record CaseEntry(
            ItemStack stack,
            int tierIndex,
            String rarityLabel,
            ChatFormatting color,
            Item glassPane,
            String chanceText
    ) {}

    public record PreviewEntry(
            Item item,
            int minCount,
            int maxCount,
            int tierIndex,
            String rarityLabel,
            ChatFormatting color,
            String chanceText
    ) {}

    public record ActionMsg(String key, String arg1, String arg2, boolean isError) {}

    private static Map<String, CaseDef> CASES;

    private static Map<String, CaseDef> getCases() {
        if (CASES != null) {
            return CASES;
        }
        Map<String, CaseDef> map = new LinkedHashMap<>();

        // 1. 新手補給箱 (10 金幣 | EV ~7.5 / 75%)
        map.put("starter", new CaseDef(
                "starter", "🪵 新手補給箱", "基礎礦物碎片與入門工具裝備",
                Items.BARREL, ChatFormatting.WHITE, 1000L,
                List.of(
                        List.of(d(Items.COAL, 2, 4), d(Items.COPPER_INGOT, 1, 2), d(ModItems.TIN_SHARD, 3, 5), d(Items.REDSTONE, 1, 2)),
                        List.of(d(ModItems.TIN_INGOT, 2, 3), d(ModItems.IRON_SHARD, 3, 4), d(Items.LAPIS_LAZULI, 2, 3), d(ModItems.TIN_SWORD, 1, 1)),
                        List.of(d(Items.IRON_INGOT, 1, 2), d(ModItems.GOLD_SHARD, 3, 4), d(ModItems.SILVER_SHARD, 2, 3), d(ModItems.TIN_PICKAXE, 1, 1)),
                        List.of(d(Items.IRON_PICKAXE, 1, 1), d(ModItems.SILVER_INGOT, 1, 2), d(ModItems.TIN_CHESTPLATE, 1, 1), d(ModItems.EMERALD_SHARD, 2, 2)),
                        List.of(d(ModItems.DIAMOND_SHARD, 1, 2), d(Items.EMERALD, 1, 1), d(Items.IRON_CHESTPLATE, 1, 1))
                )
        ));

        // 2. 礦工寶箱 (50 金幣 | EV ~42.7 / 85%)
        map.put("miner", new CaseDef(
                "miner", "⛏ 礦工寶箱", "鐵銀裝備與礦磚，金賞出鈦錠",
                Items.CHEST, ChatFormatting.GREEN, 5000L,
                List.of(
                        List.of(d(Items.IRON_INGOT, 1, 3), d(ModItems.TIN_INGOT, 4, 6), d(ModItems.GOLD_SHARD, 3, 5), d(Items.OBSIDIAN, 2, 3)),
                        List.of(d(ModItems.SILVER_INGOT, 1, 2), d(ModItems.EMERALD_SHARD, 2, 3), d(Items.IRON_PICKAXE, 1, 1), d(Items.GHAST_TEAR, 1, 1)),
                        List.of(d(Items.EMERALD, 1, 1), d(ModItems.SILVER_PICKAXE, 1, 1), d(Items.IRON_CHESTPLATE, 1, 1), d(Items.IRON_BLOCK, 1, 1)),
                        List.of(d(Items.DIAMOND, 1, 1), d(ModItems.SILVER_CHESTPLATE, 1, 1), d(Items.GOLD_BLOCK, 1, 1), d(Items.SHULKER_SHELL, 1, 1)),
                        List.of(d(ModItems.TITANIUM_INGOT, 1, 1), d(Items.DIAMOND, 2, 2), d(Items.GOLDEN_APPLE, 1, 1))
                )
        ));

        // 3. 寶石商箱 (200 金幣 | EV ~168.8 / 84%)
        map.put("gem", new CaseDef(
                "gem", "💎 寶石商箱", "鑽石、鈦碎片與圖騰，金賞出鑽甲",
                Items.ENDER_CHEST, ChatFormatting.AQUA, 20000L,
                List.of(
                        List.of(d(Items.EMERALD, 1, 1), d(ModItems.SILVER_INGOT, 3, 4), d(ModItems.DIAMOND_SHARD, 1, 2), d(Items.GHAST_TEAR, 1, 2)),
                        List.of(d(Items.DIAMOND, 1, 1), d(ModItems.SILVER_CHESTPLATE, 1, 1), d(Items.SHULKER_SHELL, 1, 1), d(ModItems.TITANIUM_SHARD, 1, 1)),
                        List.of(d(ModItems.TITANIUM_SHARD, 2, 2), d(Items.GOLDEN_APPLE, 1, 1), d(Items.ANVIL, 1, 1), d(Items.DIAMOND, 2, 2)),
                        List.of(d(ModItems.TITANIUM_INGOT, 1, 1), d(Items.TOTEM_OF_UNDYING, 1, 1), d(Items.EMERALD_BLOCK, 1, 1)),
                        List.of(d(Items.DIAMOND_HELMET, 1, 1), d(Items.DIAMOND_LEGGINGS, 1, 1), d(Items.DIAMOND_CHESTPLATE, 1, 1))
                )
        ));

        // 4. 冒險珍寶箱 (600 金幣 | EV ~457.8 / 76%)
        map.put("explorer", new CaseDef(
                "explorer", "🧭 冒險珍寶箱", "探索珍寶與高階鑽石／鈦武器，金賞出鞘翅",
                Items.AMETHYST_CLUSTER, ChatFormatting.LIGHT_PURPLE, 60000L,
                List.of(
                        List.of(d(Items.DIAMOND, 1, 1), d(ModItems.TITANIUM_SHARD, 1, 2), d(Items.SHULKER_SHELL, 1, 1), d(Items.GOLDEN_APPLE, 1, 1)),
                        List.of(d(Items.ANVIL, 1, 1), d(Items.DIAMOND, 2, 3), d(ModItems.TITANIUM_INGOT, 1, 1), d(Items.TOTEM_OF_UNDYING, 1, 1)),
                        List.of(d(Items.DIAMOND_BOOTS, 1, 1), d(Items.DIAMOND_HELMET, 1, 1), d(ModItems.TITANIUM_SWORD, 1, 1), d(ModItems.TUNGSTEN_SHARD, 2, 2)),
                        List.of(d(Items.DIAMOND_LEGGINGS, 1, 1), d(Items.DIAMOND_CHESTPLATE, 1, 1), d(Items.DIAMOND_BLOCK, 1, 1)),
                        List.of(d(ModItems.TITANIUM_PICKAXE, 1, 1), d(ModItems.TUNGSTEN_INGOT, 1, 1), d(Items.ELYTRA, 1, 1))
                )
        ));

        // 5. 鈦金鍛造箱 (1,400 金幣 | EV ~1,090.9 / 78%)
        map.put("titanium", new CaseDef(
                "titanium", "🛡 鈦金鍛造箱", "主打全套鈦金工具與護甲，金賞出鎢鎬／獄髓甲",
                Items.DIAMOND_BLOCK, ChatFormatting.BLUE, 140000L,
                List.of(
                        List.of(d(Items.DIAMOND_PICKAXE, 1, 1), d(Items.DIAMOND_BOOTS, 1, 1), d(ModItems.TITANIUM_INGOT, 1, 1), d(ModItems.TUNGSTEN_SHARD, 1, 1)),
                        List.of(d(Items.DIAMOND_HELMET, 1, 1), d(Items.DIAMOND_LEGGINGS, 1, 1), d(ModItems.TITANIUM_SWORD, 1, 1), d(Items.DIAMOND_CHESTPLATE, 1, 1)),
                        List.of(d(Items.DIAMOND_BLOCK, 1, 1), d(ModItems.TUNGSTEN_INGOT, 1, 1), d(ModItems.TITANIUM_PICKAXE, 1, 1), d(ModItems.TITANIUM_BOOTS, 1, 1)),
                        List.of(d(ModItems.TITANIUM_HELMET, 1, 1), d(ModItems.TUNGSTEN_SWORD, 1, 1), d(ModItems.TITANIUM_LEGGINGS, 1, 1)),
                        List.of(d(ModItems.TITANIUM_CHESTPLATE, 1, 1), d(ModItems.TUNGSTEN_PICKAXE, 1, 1), d(Items.NETHERITE_CHESTPLATE, 1, 1))
                )
        ));

        // 6. 防火鎢武箱 (3,600 金幣 | EV ~2,936.1 / 82%)
        map.put("tungsten", new CaseDef(
                "tungsten", "⚔ 防火鎢武箱", "頂級防火鎢武器護甲與地獄之星",
                Items.SHULKER_BOX, ChatFormatting.YELLOW, 360000L,
                List.of(
                        List.of(d(ModItems.TITANIUM_INGOT, 2, 2), d(ModItems.TUNGSTEN_INGOT, 1, 1), d(ModItems.TITANIUM_PICKAXE, 1, 1), d(ModItems.TITANIUM_BOOTS, 1, 1)),
                        List.of(d(Items.ELYTRA, 1, 1), d(ModItems.TITANIUM_HELMET, 1, 1), d(ModItems.TUNGSTEN_SWORD, 1, 1), d(Items.NETHERITE_INGOT, 1, 1)),
                        List.of(d(ModItems.TITANIUM_LEGGINGS, 1, 1), d(ModItems.TITANIUM_CHESTPLATE, 1, 1), d(Items.NETHERITE_CHESTPLATE, 1, 1), d(ModItems.TUNGSTEN_PICKAXE, 1, 1)),
                        List.of(d(ModItems.TUNGSTEN_BOOTS, 1, 1), d(ModItems.TUNGSTEN_HELMET, 1, 1), d(Items.NETHER_STAR, 1, 1), d(Items.BEACON, 1, 1)),
                        List.of(d(ModItems.TUNGSTEN_LEGGINGS, 1, 1), d(ModItems.TUNGSTEN_CHESTPLATE, 1, 1), d(Items.NETHERITE_INGOT, 4, 4))
                )
        ));

        // 7. 深淵獄髓箱 (6,000 金幣 | EV ~4,795.1 / 80%)
        map.put("netherite", new CaseDef(
                "netherite", "🔥 深淵獄髓箱", "遠古遺骸、獄髓裝備與大量地獄之星",
                Items.ANCIENT_DEBRIS, ChatFormatting.RED, 600000L,
                List.of(
                        List.of(d(Items.ANCIENT_DEBRIS, 2, 3), d(ModItems.TUNGSTEN_SWORD, 1, 1), d(Items.NETHERITE_INGOT, 1, 1), d(Items.ENCHANTED_GOLDEN_APPLE, 1, 1)),
                        List.of(d(Items.NETHERITE_PICKAXE, 1, 1), d(Items.NETHERITE_CHESTPLATE, 1, 1), d(ModItems.TUNGSTEN_PICKAXE, 1, 1), d(ModItems.TITANIUM_CHESTPLATE, 1, 1)),
                        List.of(d(ModItems.TUNGSTEN_BOOTS, 1, 1), d(Items.NETHER_STAR, 1, 1), d(Items.BEACON, 1, 1), d(ModItems.TUNGSTEN_HELMET, 1, 1)),
                        List.of(d(ModItems.TUNGSTEN_LEGGINGS, 1, 1), d(ModItems.TUNGSTEN_CHESTPLATE, 1, 1), d(Items.NETHERITE_INGOT, 4, 4)),
                        List.of(d(Items.NETHERITE_BLOCK, 1, 1), d(Items.NETHER_STAR, 4, 5), d(Items.BEACON, 4, 5))
                )
        ));

        // 8. 終極傳說箱 (12,000 金幣 | EV ~9,756.1 / 81%)
        map.put("legendary", new CaseDef(
                "legendary", "👑 終極傳說箱", "終局豪賭：大量獄髓磚、烽火台與頂級鎢甲",
                Items.BEACON, ChatFormatting.GOLD, 1200000L,
                List.of(
                        List.of(d(ModItems.TUNGSTEN_PICKAXE, 1, 1), d(Items.NETHERITE_CHESTPLATE, 1, 1), d(ModItems.TUNGSTEN_BOOTS, 1, 1), d(Items.NETHERITE_INGOT, 2, 2)),
                        List.of(d(ModItems.TUNGSTEN_HELMET, 1, 1), d(Items.NETHER_STAR, 1, 2), d(Items.BEACON, 1, 2), d(Items.NETHERITE_INGOT, 3, 3)),
                        List.of(d(ModItems.TUNGSTEN_LEGGINGS, 1, 1), d(ModItems.TUNGSTEN_CHESTPLATE, 1, 1), d(Items.NETHERITE_INGOT, 5, 6), d(Items.ENCHANTED_GOLDEN_APPLE, 4, 5)),
                        List.of(d(Items.NETHERITE_BLOCK, 1, 1), d(Items.NETHER_STAR, 4, 5), d(Items.BEACON, 4, 5)),
                        List.of(d(Items.NETHERITE_BLOCK, 2, 2), d(Items.NETHER_STAR, 9, 10), d(Items.BEACON, 9, 10))
                )
        ));

        CASES = map;
        return CASES;
    }

    private static DropSpec d(Item item, int min, int max) {
        return new DropSpec(item, min, max);
    }

    public static CaseDef getCaseDef(String caseId) {
        Map<String, CaseDef> map = getCases();
        return map.getOrDefault(caseId, map.get("starter"));
    }

    public static String getCaseTitle(String caseId) {
        return getCaseDef(caseId).displayName();
    }

    public static void withdrawSingle(ServerPlayer player, long wholeCoins, Item coinItem) {
        long centsNeeded = wholeCoins * 100L;
        if (!ModEconomy.spendCents(player.getUUID(), centsNeeded)) {
            player.sendSystemMessage(Component.literal("餘額不足！無法提款 " + wholeCoins + " 金幣。")
                    .withStyle(ChatFormatting.RED));
            return;
        }
        giveOrDrop(player, new ItemStack(coinItem, 1));
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.1F);
        long bal = ModEconomy.getBalanceCents(player.getUUID());
        player.sendSystemMessage(Component.literal("已提款 " + wholeCoins + " 金幣（餘額：" + ModEconomy.formatCents(bal) + " 金幣）")
                .withStyle(ChatFormatting.YELLOW));
    }

    public static void depositAll(ServerPlayer player) {
        Inventory inv = player.getInventory();
        long totalCentsAdded = 0L;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && st.getItem() instanceof CoinItem coin) {
                totalCentsAdded += coin.getCentsValue() * st.getCount();
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
        if (totalCentsAdded <= 0L) {
            player.sendSystemMessage(Component.literal("背包裡沒有可存入的實體金幣。").withStyle(ChatFormatting.RED));
            return;
        }
        long newBal = ModEconomy.addCents(player.getUUID(), totalCentsAdded);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.4F);
        player.sendSystemMessage(Component.literal("已存入 " + ModEconomy.formatCents(totalCentsAdded) + " 金幣（餘額：" + ModEconomy.formatCents(newBal) + " 金幣）")
                .withStyle(ChatFormatting.GREEN));
    }

    public static void sellOffhand(ServerPlayer player) {
        ItemStack stack = player.getOffhandItem();
        if (stack.isEmpty()) {
            player.sendSystemMessage(Component.literal("請先把要販售的物品放進副手再點擊此按鈕！").withStyle(ChatFormatting.RED));
            return;
        }
        if (stack.getItem() instanceof CoinItem coin) {
            long cents = coin.getCentsValue() * stack.getCount();
            stack.setCount(0);
            long total = ModEconomy.addCents(player.getUUID(), cents);
            player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.35F);
            player.sendSystemMessage(Component.literal("已存入 " + ModEconomy.formatCents(cents) + " 金幣（餘額：" + ModEconomy.formatCents(total) + " 金幣）")
                    .withStyle(ChatFormatting.GREEN));
            return;
        }
        long unitCents = ModEconomy.getCents(stack.getItem());
        if (unitCents <= 0L) {
            player.sendSystemMessage(Component.literal("副手物品無法販售。").withStyle(ChatFormatting.RED));
            return;
        }
        int count = stack.getCount();
        long earned = unitCents * count;
        Component itemName = stack.getHoverName().copy();
        stack.setCount(0);
        long total = ModEconomy.addCents(player.getUUID(), earned);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.2F);
        player.sendSystemMessage(Component.literal("已售出 ")
                .withStyle(ChatFormatting.GREEN)
                .append(itemName)
                .append(Component.literal(" x" + count + "，獲得 " + ModEconomy.formatCents(earned) + " 金幣（餘額：" + ModEconomy.formatCents(total) + " 金幣）").withStyle(ChatFormatting.GOLD)));
    }

    public static void sellAllMinerals(ServerPlayer player) {
        Inventory inv = player.getInventory();
        long earned = 0L;
        int soldItems = 0;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty() || stack.getItem() instanceof CoinItem) {
                continue;
            }
            if (ModEconomy.isBulkSellable(stack.getItem())) {
                long unitCents = ModEconomy.getCents(stack.getItem());
                if (unitCents > 0L) {
                    earned += unitCents * stack.getCount();
                    soldItems += stack.getCount();
                    inv.setItem(i, ItemStack.EMPTY);
                }
            }
        }
        if (earned <= 0L) {
            player.sendSystemMessage(Component.literal("背包中沒有可批次販售的礦物或碎片。").withStyle(ChatFormatting.RED));
            return;
        }
        long total = ModEconomy.addCents(player.getUUID(), earned);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.3F);
        player.sendSystemMessage(Component.literal("已批次售出 " + soldItems + " 個礦物/碎片，獲得 "
                + ModEconomy.formatCents(earned) + " 金幣（餘額：" + ModEconomy.formatCents(total) + " 金幣）").withStyle(ChatFormatting.GOLD));
    }

    public static String rarityKey(int tierIdx) {
        return switch (tierIdx) {
            case 0 -> "rarity.randomoredrop.mil_spec";
            case 1 -> "rarity.randomoredrop.restricted";
            case 2 -> "rarity.randomoredrop.classified";
            case 3 -> "rarity.randomoredrop.covert";
            default -> "rarity.randomoredrop.exceedingly_rare";
        };
    }

    private static String rarityName(int tierIdx) {
        return switch (tierIdx) {
            case 0 -> "軍規級";
            case 1 -> "受限級";
            case 2 -> "保密級";
            case 3 -> "隱秘級";
            default -> "★ 罕見極品 ★";
        };
    }

    private static ChatFormatting rarityColor(int tierIdx) {
        return switch (tierIdx) {
            case 0 -> ChatFormatting.BLUE;
            case 1 -> ChatFormatting.DARK_PURPLE;
            case 2 -> ChatFormatting.LIGHT_PURPLE;
            case 3 -> ChatFormatting.RED;
            default -> ChatFormatting.GOLD;
        };
    }

    public static Item vanillaItem(String path, Item fallback) {
        return BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace(path)).orElse(fallback);
    }

    private static Item rarityPane(int tierIdx) {
        return switch (tierIdx) {
            case 0 -> vanillaItem("blue_stained_glass_pane", Items.GLASS_PANE);
            case 1 -> vanillaItem("purple_stained_glass_pane", Items.GLASS_PANE);
            case 2 -> vanillaItem("magenta_stained_glass_pane", Items.GLASS_PANE);
            case 3 -> vanillaItem("red_stained_glass_pane", Items.GLASS_PANE);
            default -> vanillaItem("yellow_stained_glass_pane", Items.GLASS_PANE);
        };
    }

    public static CaseEntry rollCaseEntry(String caseId, RandomSource rng) {
        CaseDef def = getCaseDef(caseId);
        int roll = rng.nextInt(1000);
        int tierIdx = 4;
        for (int i = 0; i < TIER_THRESHOLDS.length; i++) {
            if (roll < TIER_THRESHOLDS[i]) {
                tierIdx = i;
                break;
            }
        }
        List<DropSpec> pool = def.tiers().get(tierIdx);
        DropSpec pick = pool.get(rng.nextInt(pool.size()));
        int count = pick.minCount() == pick.maxCount()
                ? pick.minCount()
                : rng.nextIntBetweenInclusive(pick.minCount(), pick.maxCount());
        ItemStack stack = new ItemStack(pick.item(), count);
        // 所有工具、武器、護具上限為 1 件，並套用 CS:GO 隨機磨損度（嶄新 12% / 輕微 22% / 久經 34% / 破損 20% / 戰痕 12%）
        if (stack.isDamageableItem() && stack.getMaxDamage() > 1) {
            stack.setCount(1);
            float wearFloat = rollRandomWearFloat(rng);
            int dmg = Math.min(stack.getMaxDamage() - 1, Math.round(wearFloat * stack.getMaxDamage()));
            stack.setDamageValue(Math.max(0, dmg));
        }
        return new CaseEntry(
                stack,
                tierIdx,
                rarityName(tierIdx),
                rarityColor(tierIdx),
                rarityPane(tierIdx),
                TIER_CHANCES[tierIdx]
        );
    }

    public static List<PreviewEntry> getPreviewEntries(String caseId) {
        CaseDef def = getCaseDef(caseId);
        List<PreviewEntry> out = new ArrayList<>();
        for (int t = 0; t < def.tiers().size(); t++) {
            for (DropSpec spec : def.tiers().get(t)) {
                out.add(new PreviewEntry(
                        spec.item(), spec.minCount(), spec.maxCount(),
                        t, rarityName(t), rarityColor(t), TIER_CHANCES[t]
                ));
            }
        }
        return out;
    }

    public static CaseEntry makeEntryForClient(ItemStack stack, int tierIdx) {
        int t = Math.max(0, Math.min(4, tierIdx));
        return new CaseEntry(stack.copy(), t, rarityKey(t), rarityColor(t), rarityPane(t), TIER_CHANCES[t]);
    }

    public static ActionMsg withdrawSingleAction(ServerPlayer player, long wholeCoins, Item coinItem) {
        long centsNeeded = wholeCoins * 100L;
        if (!ModEconomy.spendCents(player.getUUID(), centsNeeded)) {
            return new ActionMsg("msg.randomoredrop.withdraw_fail", String.valueOf(wholeCoins), "", true);
        }
        giveOrDrop(player, new ItemStack(coinItem, 1));
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.1F);
        return new ActionMsg("msg.randomoredrop.withdraw_ok", String.valueOf(wholeCoins), "", false);
    }

    public static ActionMsg depositAllAction(ServerPlayer player) {
        Inventory inv = player.getInventory();
        long totalCentsAdded = 0L;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && st.getItem() instanceof CoinItem coin) {
                totalCentsAdded += coin.getCentsValue() * st.getCount();
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
        if (totalCentsAdded <= 0L) {
            return new ActionMsg("msg.randomoredrop.deposit_empty", "", "", true);
        }
        ModEconomy.addCents(player.getUUID(), totalCentsAdded);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.4F);
        return new ActionMsg("msg.randomoredrop.deposit_ok", ModEconomy.formatCents(totalCentsAdded), "", false);
    }

    public static ActionMsg sellSelectedSlotsAction(ServerPlayer player, String csvSlots) {
        if (csvSlots == null || csvSlots.isBlank()) {
            return new ActionMsg("msg.randomoredrop.sell_none_selected", "", "", true);
        }
        Inventory inv = player.getInventory();
        java.util.Set<Integer> slots = new java.util.LinkedHashSet<>();
        for (String part : csvSlots.split(",")) {
            try {
                int idx = Integer.parseInt(part.trim());
                if (idx >= 0 && idx < 36) {
                    slots.add(idx);
                }
            } catch (NumberFormatException ignored) {
            }
        }
        long totalCents = 0L;
        int totalItems = 0;
        for (int idx : slots) {
            ItemStack st = inv.getItem(idx);
            if (st.isEmpty()) continue;
            if (st.getItem() instanceof CoinItem coin) {
                totalCents += coin.getCentsValue() * st.getCount();
                totalItems += st.getCount();
                inv.setItem(idx, ItemStack.EMPTY);
            } else {
                long stackVal = ModEconomy.getStackCents(st);
                if (stackVal > 0L) {
                    totalCents += stackVal;
                    totalItems += st.getCount();
                    inv.setItem(idx, ItemStack.EMPTY);
                }
            }
        }
        if (totalCents <= 0L) {
            return new ActionMsg("msg.randomoredrop.sell_none_valid", "", "", true);
        }
        ModEconomy.addCents(player.getUUID(), totalCents);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.3F);
        return new ActionMsg("msg.randomoredrop.sell_selected_ok", String.valueOf(totalItems), ModEconomy.formatCents(totalCents), false);
    }

    public static ActionMsg sellOffhandAction(ServerPlayer player) {
        ItemStack stack = player.getOffhandItem();
        if (stack.isEmpty()) {
            return new ActionMsg("msg.randomoredrop.offhand_empty", "", "", true);
        }
        if (stack.getItem() instanceof CoinItem coin) {
            long cents = coin.getCentsValue() * stack.getCount();
            stack.setCount(0);
            ModEconomy.addCents(player.getUUID(), cents);
            player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.35F);
            return new ActionMsg("msg.randomoredrop.deposit_ok", ModEconomy.formatCents(cents), "", false);
        }
        long unitCents = ModEconomy.getCents(stack.getItem());
        if (unitCents <= 0L) {
            return new ActionMsg("msg.randomoredrop.offhand_unsellable", "", "", true);
        }
        int count = stack.getCount();
        long earned = unitCents * count;
        stack.setCount(0);
        ModEconomy.addCents(player.getUUID(), earned);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.2F);
        return new ActionMsg("msg.randomoredrop.sell_offhand_ok", String.valueOf(count), ModEconomy.formatCents(earned), false);
    }

    public static ActionMsg sellAllMineralsAction(ServerPlayer player) {
        Inventory inv = player.getInventory();
        long earned = 0L;
        int soldItems = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty() || stack.getItem() instanceof CoinItem) continue;
            if (ModEconomy.isBulkSellable(stack.getItem())) {
                long unitCents = ModEconomy.getCents(stack.getItem());
                if (unitCents > 0L) {
                    earned += unitCents * stack.getCount();
                    soldItems += stack.getCount();
                    inv.setItem(i, ItemStack.EMPTY);
                }
            }
        }
        if (earned <= 0L) {
            return new ActionMsg("msg.randomoredrop.minerals_empty", "", "", true);
        }
        ModEconomy.addCents(player.getUUID(), earned);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.3F);
        return new ActionMsg("msg.randomoredrop.sell_minerals_ok", String.valueOf(soldItems), ModEconomy.formatCents(earned), false);
    }

    private static float rollRandomWearFloat(RandomSource rng) {
        int r = rng.nextInt(100);
        if (r < 12) return rng.nextFloat() * 0.19F;
        if (r < 34) return 0.20F + rng.nextFloat() * 0.19F;
        if (r < 68) return 0.40F + rng.nextFloat() * 0.19F;
        if (r < 88) return 0.60F + rng.nextFloat() * 0.19F;
        return 0.80F + rng.nextFloat() * 0.15F;
    }

    public static Component formatWearComponent(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isDamageableItem() || stack.getMaxDamage() <= 0) {
            return Component.empty();
        }
        float wear = Math.min(1.0F, Math.max(0.0F, stack.getDamageValue() / (float) stack.getMaxDamage()));
        String key;
        ChatFormatting col;
        if (wear < 0.20F) { key = "wear.randomoredrop.fn"; col = ChatFormatting.GREEN; }
        else if (wear < 0.40F) { key = "wear.randomoredrop.mw"; col = ChatFormatting.AQUA; }
        else if (wear < 0.60F) { key = "wear.randomoredrop.ft"; col = ChatFormatting.YELLOW; }
        else if (wear < 0.80F) { key = "wear.randomoredrop.ww"; col = ChatFormatting.GOLD; }
        else { key = "wear.randomoredrop.bs"; col = ChatFormatting.RED; }
        String pct = String.format("%.0f%%", wear * 100.0F);
        return Component.literal(" [").withStyle(ChatFormatting.GRAY)
                .append(Component.translatable(key).withStyle(col))
                .append(Component.literal(" " + pct + "]").withStyle(ChatFormatting.GRAY));
    }

    public static double getExactDropChancePct(String caseId, int tierIdx) {
        CaseDef def = getCaseDef(caseId);
        double[] tierPcts = {52.0, 26.5, 14.5, 5.5, 1.5};
        int t = Math.max(0, Math.min(4, tierIdx));
        int poolSize = Math.max(1, def.tiers().get(t).size());
        return tierPcts[t] / poolSize;
    }

    public static void giveOrDrop(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) {
            player.level().addFreshEntity(new ItemEntity(player.level(), player.getX(), player.getY(), player.getZ(), stack));
        }
    }
}
