package com.example.randomoredrop;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Consumer;

public final class WaystonesCompat {
    private static boolean hooked = false;

    private WaystonesCompat() {}

    public static void initialize() {
        if (hooked || !FabricLoader.getInstance().isModLoaded("waystones")) {
            return;
        }
        try {
            Class<?> beforeCls = Class.forName("net.blay09.mods.waystones.api.event.WaystoneTeleportEvent$Before");
            Field eventField = beforeCls.getField("EVENT");
            Object eventMapper = eventField.get(null);
            if (eventMapper == null) return;

            Method registerMethod = null;
            for (Method m : eventMapper.getClass().getMethods()) {
                if ("register".equals(m.getName()) && m.getParameterCount() == 1
                        && Consumer.class.isAssignableFrom(m.getParameterTypes()[0])) {
                    registerMethod = m;
                    break;
                }
            }
            if (registerMethod == null) return;

            Consumer<Object> listener = WaystonesCompat::onBeforeTeleport;
            registerMethod.invoke(eventMapper, listener);
            hooked = true;
        } catch (Throwable ignored) {
        }
    }

    private static void onBeforeTeleport(Object event) {
        try {
            Method isCanceled = event.getClass().getMethod("isCanceled");
            if ((Boolean) isCanceled.invoke(event)) return;

            Object ctx = event.getClass().getMethod("getContext").invoke(event);
            if (ctx == null) return;

            Object entity = ctx.getClass().getMethod("getEntity").invoke(ctx);
            if (!(entity instanceof ServerPlayer sp)) return;
            if (sp.isCreative() || sp.isSpectator()) return;

            Object targetWs = ctx.getClass().getMethod("getTargetWaystone").invoke(ctx);
            if (targetWs == null) return;

            boolean crossDim = (Boolean) ctx.getClass().getMethod("isDimensionalTeleport").invoke(ctx);
            BlockPos targetPos = (BlockPos) targetWs.getClass().getMethod("getPos").invoke(targetWs);
            Component wsName = (Component) targetWs.getClass().getMethod("getEffectiveName").invoke(targetWs);
            if (wsName == null) wsName = Component.literal("Waystone");

            long feeCoins;
            long distBlocks = 0L;
            if (crossDim) {
                // Balanced flat cross-dimension fee: 40 Coins (= 1 Silver Ingot)
                feeCoins = 40L;
            } else {
                double dx = sp.getX() - (targetPos.getX() + 0.5D);
                double dz = sp.getZ() - (targetPos.getZ() + 0.5D);
                distBlocks = Math.round(Math.sqrt(dx * dx + dz * dz));
                // Balanced same-dimension fee: 5 Coins base + 1 Coin per 60 blocks, capped at 100 Coins
                feeCoins = Math.min(100L, 5L + Math.round(distBlocks / 60.0D));
            }
            long feeCents = feeCoins * 100L;

            if (!ModEconomy.spendCents(sp.getUUID(), feeCents)) {
                Method setCanceled = event.getClass().getMethod("setCanceled", boolean.class);
                setCanceled.invoke(event, true);
                long bal = ModEconomy.getBalanceCents(sp.getUUID());
                sp.sendSystemMessage(Component.translatable("msg.randomoredrop.waystone_no_coins",
                                ModEconomy.formatCents(feeCents), ModEconomy.formatCents(bal))
                        .withStyle(ChatFormatting.RED));
                return;
            }

            long newBal = ModEconomy.getBalanceCents(sp.getUUID());
            if (crossDim) {
                sp.sendSystemMessage(Component.translatable("msg.randomoredrop.waystone_paid_dim",
                                wsName, ModEconomy.formatCents(feeCents), ModEconomy.formatCents(newBal))
                        .withStyle(ChatFormatting.GOLD));
            } else {
                sp.sendSystemMessage(Component.translatable("msg.randomoredrop.waystone_paid",
                                wsName, distBlocks, ModEconomy.formatCents(feeCents), ModEconomy.formatCents(newBal))
                        .withStyle(ChatFormatting.GOLD));
            }
        } catch (Throwable ignored) {
        }
    }
}
