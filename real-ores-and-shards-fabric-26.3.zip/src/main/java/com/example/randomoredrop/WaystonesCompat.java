package com.example.randomoredrop;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

public final class WaystonesCompat {
    private static boolean hooked = false;

    private WaystonesCompat() {}

    public static void initialize() {
        if (hooked || !FabricLoader.getInstance().isModLoaded("waystones")) {
            return;
        }
        try {
            registerBalmEvent("net.blay09.mods.waystones.api.event.WaystoneTeleportEvent$Before", WaystonesCompat::onBeforeTeleport);
            registerBalmEvent("net.blay09.mods.waystones.api.event.BuildWaystoneSelectionMenuEvent", WaystonesCompat::onBuildSelectionMenu);
            hooked = true;
        } catch (Throwable ignored) {
        }
    }

    private static void registerBalmEvent(String eventClassName, Consumer<Object> listener) throws Exception {
        Class<?> cls = Class.forName(eventClassName);
        Field eventField = cls.getField("EVENT");
        Object eventMapper = eventField.get(null);
        if (eventMapper == null) return;
        Method registerMethod = eventMapper.getClass().getMethod("register", Object.class);
        registerMethod.invoke(eventMapper, listener);
    }

    public static long calculateFeeCoins(Player player, BlockPos targetPos, boolean crossDim) {
        if (player.isCreative() || player.isSpectator()) return 0L;
        if (crossDim) return 40L;
        double dx = player.getX() - (targetPos.getX() + 0.5D);
        double dz = player.getZ() - (targetPos.getZ() + 0.5D);
        long distBlocks = Math.round(Math.sqrt(dx * dx + dz * dz));
        return Math.min(100L, 5L + Math.round(distBlocks / 60.0D));
    }

    private static void onBuildSelectionMenu(Object event) {
        try {
            Object pObj = event.getClass().getMethod("getPlayer").invoke(event);
            if (!(pObj instanceof Player player)) return;

            Object sourceWs = event.getClass().getMethod("getSourceWaystone").invoke(event);
            UUID sourceUid = null;
            if (sourceWs != null) {
                sourceUid = (UUID) sourceWs.getClass().getMethod("getWaystoneUid").invoke(sourceWs);
            }

            List<?> list = (List<?>) event.getClass().getMethod("getWaystones").invoke(event);
            if (list == null) return;

            long balCents = ModEconomy.getBalanceCents(player.getUUID());
            ResourceKey<?> playerDim = player.level().dimension();

            for (Object mpw : list) {
                if (mpw == null) continue;
                UUID uid = (UUID) mpw.getClass().getMethod("getWaystoneUid").invoke(mpw);
                if (sourceUid != null && sourceUid.equals(uid)) continue;

                BlockPos targetPos = (BlockPos) mpw.getClass().getMethod("getPos").invoke(mpw);
                ResourceKey<?> targetDim = (ResourceKey<?>) mpw.getClass().getMethod("getDimension").invoke(mpw);
                Component baseName = (Component) mpw.getClass().getMethod("getEffectiveName").invoke(mpw);
                if (targetPos == null || baseName == null) continue;

                boolean crossDim = targetDim != null && !targetDim.equals(playerDim);
                long feeCoins = calculateFeeCoins(player, targetPos, crossDim);

                Component feeBadge;
                if (feeCoins <= 0L) {
                    feeBadge = Component.translatable("ui.randomoredrop.waystone_fee_free").withStyle(ChatFormatting.GREEN);
                } else {
                    boolean canAfford = balCents >= feeCoins * 100L;
                    feeBadge = Component.translatable("ui.randomoredrop.waystone_fee_tag", feeCoins)
                            .withStyle(canAfford ? ChatFormatting.GOLD : ChatFormatting.RED);
                }

                Component newAlias = baseName.copy().append(Component.literal(" ")).append(feeBadge);
                mpw.getClass().getMethod("setAlias", Component.class).invoke(mpw, newAlias);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void onBeforeTeleport(Object event) {
        try {
            Method isCanceled = event.getClass().getMethod("isCanceled");
            if ((Boolean) isCanceled.invoke(event)) return;

            Object ctx = event.getClass().getMethod("getContext").invoke(event);
            if (ctx == null) return;

            Object entity = ctx.getClass().getMethod("getEntity").invoke(ctx);
            if (!(entity instanceof ServerPlayer sp)) return;
            if (sp.isCreative() || sp.isSpectator()) return;

            Object targetWs = ctx.getClass().getMethod("getTargetWaystone").invoke(ctx);
            if (targetWs == null) return;

            boolean crossDim = (Boolean) ctx.getClass().getMethod("isDimensionalTeleport").invoke(ctx);
            BlockPos targetPos = (BlockPos) targetWs.getClass().getMethod("getPos").invoke(targetWs);
            Component wsName = (Component) targetWs.getClass().getMethod("getEffectiveName").invoke(targetWs);
            if (wsName == null) wsName = Component.literal("Waystone");

            long feeCoins = calculateFeeCoins(sp, targetPos, crossDim);
            long feeCents = feeCoins * 100L;
            double dx = sp.getX() - (targetPos.getX() + 0.5D);
            double dz = sp.getZ() - (targetPos.getZ() + 0.5D);
            long distBlocks = Math.round(Math.sqrt(dx * dx + dz * dz));

            if (!ModEconomy.spendCents(sp.getUUID(), feeCents)) {
                Method setCanceled = event.getClass().getMethod("setCanceled", boolean.class);
                setCanceled.invoke(event, true);
                long bal = ModEconomy.getBalanceCents(sp.getUUID());
                sp.sendSystemMessage(Component.translatable("msg.randomoredrop.waystone_no_coins",
                                ModEconomy.formatCents(feeCents), ModEconomy.formatCents(bal))
                        .withStyle(ChatFormatting.RED));
                return;
            }

            long newBal = ModEconomy.getBalanceCents(sp.getUUID());
            if (crossDim) {
                sp.sendSystemMessage(Component.translatable("msg.randomoredrop.waystone_paid_dim",
                                wsName, ModEconomy.formatCents(feeCents), ModEconomy.formatCents(newBal))
                        .withStyle(ChatFormatting.GOLD));
            } else {
                sp.sendSystemMessage(Component.translatable("msg.randomoredrop.waystone_paid",
                                wsName, distBlocks, ModEconomy.formatCents(feeCents), ModEconomy.formatCents(newBal))
                        .withStyle(ChatFormatting.GOLD));
            }
        } catch (Throwable ignored) {
        }
    }
}
