package com.example.randomoredrop;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

import java.util.Map;

public class ModMaterials {
    public static final TagKey<Item> REPAIRS_TIN = itemTag("repairs_tin");
    public static final TagKey<Item> REPAIRS_SILVER = itemTag("repairs_silver");
    public static final TagKey<Item> REPAIRS_TITANIUM = itemTag("repairs_titanium");
    public static final TagKey<Item> REPAIRS_TUNGSTEN = itemTag("repairs_tungsten");

    public static final ToolMaterial TIN_TOOL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_IRON_TOOL, 190, 6.5F, 1.5F, 16, REPAIRS_TIN
    );
    public static final ToolMaterial SILVER_TOOL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_IRON_TOOL, 420, 7.0F, 2.5F, 22, REPAIRS_SILVER
    );
    public static final ToolMaterial TITANIUM_TOOL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1850, 8.5F, 3.5F, 12, REPAIRS_TITANIUM
    );
    public static final ToolMaterial TUNGSTEN_TOOL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2400, 8.0F, 4.5F, 8, REPAIRS_TUNGSTEN
    );

    public static final int TIN_ARMOR_DURABILITY = 12;
    public static final int SILVER_ARMOR_DURABILITY = 18;
    public static final int TITANIUM_ARMOR_DURABILITY = 35;
    public static final int TUNGSTEN_ARMOR_DURABILITY = 42;

    public static final ArmorMaterial TIN_ARMOR = new ArmorMaterial(
            TIN_ARMOR_DURABILITY,
            Map.of(ArmorType.BOOTS, 1, ArmorType.LEGGINGS, 4, ArmorType.CHESTPLATE, 5, ArmorType.HELMET, 2, ArmorType.BODY, 4),
            16, SoundEvents.ARMOR_EQUIP_IRON, 0.0F, 0.0F, REPAIRS_TIN, assetKey("tin")
    );

    public static final ArmorMaterial SILVER_ARMOR = new ArmorMaterial(
            SILVER_ARMOR_DURABILITY,
            Map.of(ArmorType.BOOTS, 2, ArmorType.LEGGINGS, 5, ArmorType.CHESTPLATE, 6, ArmorType.HELMET, 2, ArmorType.BODY, 5),
            22, SoundEvents.ARMOR_EQUIP_GOLD, 0.5F, 0.0F, REPAIRS_SILVER, assetKey("silver")
    );

    public static final ArmorMaterial TITANIUM_ARMOR = new ArmorMaterial(
            TITANIUM_ARMOR_DURABILITY,
            Map.of(ArmorType.BOOTS, 3, ArmorType.LEGGINGS, 6, ArmorType.CHESTPLATE, 8, ArmorType.HELMET, 3, ArmorType.BODY, 11),
            12, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.5F, 0.05F, REPAIRS_TITANIUM, assetKey("titanium")
    );

    public static final ArmorMaterial TUNGSTEN_ARMOR = new ArmorMaterial(
            TUNGSTEN_ARMOR_DURABILITY,
            Map.of(ArmorType.BOOTS, 3, ArmorType.LEGGINGS, 6, ArmorType.CHESTPLATE, 8, ArmorType.HELMET, 3, ArmorType.BODY, 12),
            8, SoundEvents.ARMOR_EQUIP_NETHERITE, 3.5F, 0.15F, REPAIRS_TUNGSTEN, assetKey("tungsten")
    );

    private static TagKey<Item> itemTag(String name) {
        return TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name));
    }

    private static ResourceKey<EquipmentAsset> assetKey(String name) {
        return ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name));
    }
}
