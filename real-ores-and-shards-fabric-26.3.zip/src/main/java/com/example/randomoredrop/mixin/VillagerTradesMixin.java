package com.example.randomoredrop.mixin;

import com.example.randomoredrop.ModItems;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.npc.villager.AbstractVillager;
import net.minecraft.world.item.*;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(AbstractVillager.class)
public class VillagerTradesMixin {
    private static final float TOOL_OR_GEAR_KEEP_CHANCE = 0.25f;

    @Unique
    private int randomoredrop$sanitizedCount = 0;

    @Inject(method = "getOffers", at = @At("RETURN"))
    private void sanitizeVillagerOffers(CallbackInfoReturnable<MerchantOffers> cir) {
        MerchantOffers offers = cir.getReturnValue();
        if (offers == null || offers.size() <= this.randomoredrop$sanitizedCount) {
            return;
        }

        RandomSource random = ((AbstractVillager) (Object) this).getRandom();

        for (int i = offers.size() - 1; i >= this.randomoredrop$sanitizedCount; i--) {
            MerchantOffer offer = offers.get(i);
            ItemStack result = offer.getResult();

            if (isDiamondOrHigherGear(result)) {
                offers.remove(i);
                continue;
            }

            if (isAnyToolOrGear(result) && random.nextFloat() > TOOL_OR_GEAR_KEEP_CHANCE) {
                offers.remove(i);
                continue;
            }

            ItemCost costA = offer.getItemCostA();
            ItemCost newCostA = convertCostToShard(costA);

            Optional<ItemCost> costB = offer.getItemCostB();
            Optional<ItemCost> newCostB = costB.map(VillagerTradesMixin::convertCostToShard);

            ItemStack newResult = convertStackToShard(result);

            if (newCostA != costA || !newCostB.equals(costB) || newResult != result) {
                MerchantOffer replaced = new MerchantOffer(
                        newCostA,
                        newCostB,
                        newResult,
                        offer.getMaxUses(),
                        offer.getXp(),
                        offer.getPriceMultiplier()
                );
                offers.set(i, replaced);
            }
        }

        this.randomoredrop$sanitizedCount = offers.size();
    }

    @Unique
    private static boolean isDiamondOrHigherGear(ItemStack stack) {
        Item item = stack.getItem();
        if (item == Items.DIAMOND_HORSE_ARMOR) {
            return true;
        }
        if (!isAnyToolOrGear(stack)) {
            return false;
        }
        String path = BuiltInRegistries.ITEM.getKey(item).getPath();
        return path.contains("diamond_")
                || path.contains("netherite_")
                || path.contains("titanium_")
                || path.contains("tungsten_");
    }

    @Unique
    private static boolean isAnyToolOrGear(ItemStack stack) {
        Item item = stack.getItem();
        return stack.has(DataComponents.TOOL)
                || stack.has(DataComponents.EQUIPPABLE)
                || stack.is(ItemTags.SWORDS)
                || stack.is(ItemTags.PICKAXES)
                || stack.is(ItemTags.AXES)
                || stack.is(ItemTags.SHOVELS)
                || stack.is(ItemTags.HOES)
                || stack.is(ItemTags.HEAD_ARMOR)
                || stack.is(ItemTags.CHEST_ARMOR)
                || stack.is(ItemTags.LEG_ARMOR)
                || stack.is(ItemTags.FOOT_ARMOR)
                || item instanceof BowItem
                || item instanceof CrossbowItem
                || item instanceof ShieldItem
                || item instanceof FishingRodItem
                || item instanceof ShearsItem
                || item instanceof FlintAndSteelItem;
    }

    @Unique
    private static ItemCost convertCostToShard(ItemCost cost) {
        Item shard = ModItems.TRADE_MINERAL_TO_SHARD.get(cost.item().value());
        if (shard != null) {
            return new ItemCost(shard, cost.count());
        }
        return cost;
    }

    @Unique
    private static ItemStack convertStackToShard(ItemStack stack) {
        Item shard = ModItems.TRADE_MINERAL_TO_SHARD.get(stack.getItem());
        if (shard != null) {
            return new ItemStack(shard, stack.getCount());
        }
        return stack;
    }
}
