package com.example.randomoredrop;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

public class UpgraderCompat {
    public static void initialize() {
        if (!FabricLoader.getInstance().isModLoaded("upgrader")) {
            return;
        }
        // 停用的 upgrader 物品不再給予價值，避免出現在轉盤
        if (FabricLoader.getInstance().isModLoaded("artifacts")) {
            for (Item item : BuiltInRegistries.ITEM) {
                if ("artifacts".equals(BuiltInRegistries.ITEM.getKey(item).getNamespace())) {
                    ModEconomy.setExternalCents(item, 150000L);
                }
            }
        }
        syncWithUpgrader();
    }

    @SuppressWarnings("unchecked")
    public static void syncWithUpgrader() {
        if (!FabricLoader.getInstance().isModLoaded("upgrader")) {
            return;
        }
        try {
            Class<?> baseValuesCls = Class.forName("net.execheinz.upgrader.value.BaseValues");
            Field valuesField = baseValuesCls.getDeclaredField("VALUES");
            valuesField.setAccessible(true);
            Map<Item, Double> upgraderValues = (Map<Item, Double>) valuesField.get(null);

            for (Item item : BuiltInRegistries.ITEM) {
                if (ModEconomy.isForbiddenOrUnobtainable(item) || item instanceof CoinItem) {
                    upgraderValues.remove(item);
                    continue;
                }
                double val = ModEconomy.getCoinsDouble(item);
                if (val > 0.0) {
                    upgraderValues.put(item, val);
                } else {
                    upgraderValues.remove(item);
                }
            }

            Class<?> itemValuesCls = Class.forName("net.execheinz.upgrader.value.ItemValues");
            Method invalidate = itemValuesCls.getMethod("invalidate");
            invalidate.invoke(null);
        } catch (Throwable ignored) {
        }
    }

    public static void openUpgraderGui(net.minecraft.server.level.ServerPlayer player) {
        if (!FabricLoader.getInstance().isModLoaded("upgrader")) {
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("尚未安裝 Upgrader 模組（upgrader-fabric-1.3.1+26.3.jar）！")
                    .withStyle(net.minecraft.ChatFormatting.RED));
            return;
        }
        try {
            Class<?> itemCls = Class.forName("net.execheinz.upgrader.item.UpgraderItem");
            Method openFor = itemCls.getMethod("openFor", net.minecraft.world.entity.player.Player.class);
            openFor.invoke(null, player);
        } catch (Throwable e) {
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("無法開啟 Upgrader 介面，請確認 Upgrader 版本為 26.3。")
                    .withStyle(net.minecraft.ChatFormatting.RED));
        }
    }
}
