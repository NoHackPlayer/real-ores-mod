package com.example.randomoredrop;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

public class UpgraderCompat {
    private static boolean synced = false;

    public static void initialize() {
        if (!FabricLoader.getInstance().isModLoaded("upgrader")) {
            return;
        }
        // 若有安裝 Upgrader，也幫 upgrader:upgrader 本身設定金幣價值（對應其配方：4 金錠 + 4 鑽石 + 1 鐵砧）
        BuiltInRegistries.ITEM.getOptional(Identifier.fromNamespaceAndPath("upgrader", "upgrader"))
                .ifPresent(item -> ModEconomy.setExternalValue(item, 6000L));
        syncWithUpgrader();
    }

    @SuppressWarnings("unchecked")
    public static void syncWithUpgrader() {
        if (!FabricLoader.getInstance().isModLoaded("upgrader")) {
            return;
        }
        try {
            Class<?> baseValuesCls = Class.forName("net.execheinz.upgrader.value.BaseValues");
            Field valuesField = baseValuesCls.getDeclaredField("VALUES");
            valuesField.setAccessible(true);
            Map<Item, Double> upgraderValues = (Map<Item, Double>) valuesField.get(null);

            for (Map.Entry<Item, Long> entry : ModEconomy.getAllValues().entrySet()) {
                upgraderValues.put(entry.getKey(), entry.getValue().doubleValue());
            }

            if (!synced) {
                synced = true;
            }
            // 通知 Upgrader 清除舊快取，重新套用我們的新礦物/碎片/裝備價值表
            Class<?> itemValuesCls = Class.forName("net.execheinz.upgrader.value.ItemValues");
            Method invalidate = itemValuesCls.getMethod("invalidate");
            invalidate.invoke(null);
        } catch (Throwable ignored) {
            // 若 Upgrader 版本介面變動則安全略過，不影響主模組運作
        }
    }
}
