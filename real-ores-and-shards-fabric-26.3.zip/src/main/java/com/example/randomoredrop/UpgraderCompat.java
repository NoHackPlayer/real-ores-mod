package com.example.randomoredrop;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public class UpgraderCompat {
    private record ScheduledBroadcast(MinecraftServer server, Component message, long fireTick) {}
    private static final List<ScheduledBroadcast> PENDING_BROADCASTS = new CopyOnWriteArrayList<>();
    private static long tickCounter = 0L;
    private static boolean senderHooked = false;

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;
            if (PENDING_BROADCASTS.isEmpty()) {
                return;
            }
            for (ScheduledBroadcast sb : PENDING_BROADCASTS) {
                if (tickCounter >= sb.fireTick()) {
                    PENDING_BROADCASTS.remove(sb);
                    if (sb.server() != null) {
                        sb.server().getPlayerList().broadcastSystemMessage(sb.message(), false);
                    }
                }
            }
        });

        if (!FabricLoader.getInstance().isModLoaded("upgrader")) {
            return;
        }
        syncWithUpgrader();
        hookUpgradeBroadcast();
    }

    @SuppressWarnings("unchecked")
    public static void syncWithUpgrader() {
        if (!FabricLoader.getInstance().isModLoaded("upgrader")) {
            return;
        }
        try {
            Class<?> baseValuesCls = Class.forName("net.execheinz.upgrader.value.BaseValues");
            Field valuesField = baseValuesCls.getDeclaredField("VALUES");
            valuesField.setAccessible(true);
            Map<Item, Double> upgraderValues = (Map<Item, Double>) valuesField.get(null);

            Set<Item> upgraderBlacklist = null;
            try {
                Field blField = baseValuesCls.getDeclaredField("BLACKLIST");
                blField.setAccessible(true);
                upgraderBlacklist = (Set<Item>) blField.get(null);
            } catch (Throwable ignored) {
            }

            for (Item item : BuiltInRegistries.ITEM) {
                if (ModEconomy.isForbiddenOrUnobtainable(item) || ModEconomy.isArtifactItem(item) || item instanceof CoinItem) {
                    upgraderValues.remove(item);
                    if (upgraderBlacklist != null) {
                        try {
                            upgraderBlacklist.add(item);
                        } catch (UnsupportedOperationException ignored) {
                        }
                    }
                    continue;
                }
                double val = ModEconomy.getCoinsDouble(item);
                if (val > 0.0) {
                    upgraderValues.put(item, val);
                } else {
                    upgraderValues.remove(item);
                }
            }

            Class<?> itemValuesCls = Class.forName("net.execheinz.upgrader.value.ItemValues");
            Method invalidate = itemValuesCls.getMethod("invalidate");
            invalidate.invoke(null);
        } catch (Throwable ignored) {
        }
        hookUpgradeBroadcast();
    }

    /**
     * 透過動態代理攔截 UpgraderNetwork.sender.toClient：
     * 當玩家以 <= 10% 成功率升級成功時，於轉盤停止瞬間向全服廣播賀喜訊息！
     */
    public static void hookUpgradeBroadcast() {
        if (senderHooked || !FabricLoader.getInstance().isModLoaded("upgrader")) {
            return;
        }
        try {
            Class<?> netCls = Class.forName("net.execheinz.upgrader.network.UpgraderNetwork");
            Class<?> senderIface = Class.forName("net.execheinz.upgrader.network.UpgraderNetwork$Sender");
            Field senderField = netCls.getDeclaredField("sender");
            senderField.setAccessible(true);
            Object original = senderField.get(null);
            if (original == null) {
                return;
            }
            Object proxy = Proxy.newProxyInstance(
                    senderIface.getClassLoader(),
                    new Class<?>[]{senderIface},
                    (p, method, args) -> {
                        if ("toClient".equals(method.getName()) && args != null && args.length == 2
                                && args[0] instanceof ServerPlayer sp && args[1] != null) {
                            onUpgraderPacketToClient(sp, args[1]);
                        }
                        return method.invoke(original, args);
                    }
            );
            senderField.set(null, proxy);
            senderHooked = true;
        } catch (Throwable ignored) {
        }
    }

    private static void onUpgraderPacketToClient(ServerPlayer sp, Object packet) {
        try {
            if (!"net.execheinz.upgrader.network.ClientboundUpgradeResultPacket".equals(packet.getClass().getName())) {
                return;
            }
            boolean success = (Boolean) packet.getClass().getMethod("success").invoke(packet);
            if (!success) {
                return;
            }
            float rawChance = (Float) packet.getClass().getMethod("chance").invoke(packet);
            double chancePct = (rawChance <= 1.0F) ? (rawChance * 100.0) : rawChance;
            if (chancePct > 10.0001) {
                return;
            }

            int durationTicks = 0;
            try {
                durationTicks = (Integer) packet.getClass().getMethod("durationTicks").invoke(packet);
            } catch (Throwable ignored) {
            }

            ItemStack wonStack = ItemStack.EMPTY;
            if (sp.containerMenu != null && "net.execheinz.upgrader.menu.UpgraderMenu".equals(sp.containerMenu.getClass().getName())) {
                Field targetField = sp.containerMenu.getClass().getDeclaredField("target");
                targetField.setAccessible(true);
                Object tObj = targetField.get(sp.containerMenu);
                Field countField = sp.containerMenu.getClass().getDeclaredField("targetCount");
                countField.setAccessible(true);
                int cnt = Math.max(1, (Integer) countField.get(sp.containerMenu));
                if (tObj instanceof Item targetItem) {
                    wonStack = new ItemStack(targetItem, cnt);
                }
            }

            Component itemName = wonStack.isEmpty() ? Component.translatable("msg.randomoredrop.rare_item") : wonStack.getHoverName().copy();
            int count = wonStack.isEmpty() ? 1 : wonStack.getCount();
            Component wearComp = ComputerActions.formatWearComponent(wonStack);
            long valCents = wonStack.isEmpty() ? 0L : ModEconomy.getCents(wonStack.getItem()) * count;
            String pctStr = String.format("%.2f%%", chancePct);

            Component itemAndWear = Component.empty()
                    .append(itemName.copy().withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD))
                    .append(Component.literal(" x" + count).withStyle(ChatFormatting.WHITE))
                    .append(wearComp);
            Component globalMsg = Component.translatable(
                    "msg.randomoredrop.broadcast_upgrade",
                    Component.literal(sp.getName().getString()).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD),
                    pctStr,
                    itemAndWear,
                    ModEconomy.formatCents(valCents)
            ).withStyle(ChatFormatting.LIGHT_PURPLE);

            MinecraftServer server = sp.level().getServer();
            if (server != null) {
                long delay = Math.max(1L, durationTicks);
                PENDING_BROADCASTS.add(new ScheduledBroadcast(server, globalMsg, tickCounter + delay));
            }
        } catch (Throwable ignored) {
        }
    }

    public static void openUpgraderGui(ServerPlayer player) {
        if (!FabricLoader.getInstance().isModLoaded("upgrader")) {
            player.sendSystemMessage(Component.translatable("msg.randomoredrop.upgrader_missing")
                    .withStyle(ChatFormatting.RED));
            return;
        }
        try {
            Class<?> itemCls = Class.forName("net.execheinz.upgrader.item.UpgraderItem");
            Method openFor = itemCls.getDeclaredMethod("openFor", net.minecraft.world.entity.player.Player.class);
            openFor.setAccessible(true);
            openFor.invoke(null, player);
        } catch (Throwable e) {
            player.sendSystemMessage(Component.translatable("msg.randomoredrop.upgrader_error")
                    .withStyle(ChatFormatting.RED));
        }
    }
}
