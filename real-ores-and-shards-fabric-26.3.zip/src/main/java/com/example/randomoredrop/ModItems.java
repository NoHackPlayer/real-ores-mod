package com.example.randomoredrop;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.*;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModItems {
    // 多功能電腦終端機（整合 Upgrader、開箱、販售與金幣存提款，取代所有指令與舊 Upgrader 物品）
    public static final Item COMPUTER = registerComputer("computer");

    // 5 種面額實體金幣（可透過電腦提款丟給他人、右鍵/Shift+右鍵存入）
    public static final Item COIN_1 = registerCoin("coin_1", 1, Rarity.COMMON, false);
    public static final Item COIN_10 = registerCoin("coin_10", 10, Rarity.COMMON, false);
    public static final Item COIN_100 = registerCoin("coin_100", 100, Rarity.UNCOMMON, false);
    public static final Item COIN_1000 = registerCoin("coin_1000", 1000, Rarity.RARE, false);
    public static final Item COIN_10000 = registerCoin("coin_10000", 10000, Rarity.EPIC, true);

    // 原版礦物碎片
    public static final Item COAL_SHARD = registerSimple("coal_shard", Rarity.COMMON);
    public static final Item COPPER_SHARD = registerSimple("copper_shard", Rarity.COMMON);
    public static final Item IRON_SHARD = registerSimple("iron_shard", Rarity.UNCOMMON);
    public static final Item REDSTONE_SHARD = registerSimple("redstone_shard", Rarity.UNCOMMON);
    public static final Item LAPIS_SHARD = registerSimple("lapis_shard", Rarity.UNCOMMON);
    public static final Item QUARTZ_SHARD = registerSimple("quartz_shard", Rarity.UNCOMMON);
    public static final Item GOLD_SHARD = registerSimple("gold_shard", Rarity.UNCOMMON);
    public static final Item DIAMOND_SHARD = registerSimple("diamond_shard", Rarity.RARE);
    public static final Item EMERALD_SHARD = registerSimple("emerald_shard", Rarity.RARE);

    // 4 種現實金屬：碎片、粗礦、金屬錠
    public static final Item TIN_SHARD = registerSimple("tin_shard", Rarity.COMMON);
    public static final Item RAW_TIN = registerSimple("raw_tin", Rarity.COMMON);
    public static final Item TIN_INGOT = registerSimple("tin_ingot", Rarity.COMMON);

    public static final Item SILVER_SHARD = registerSimple("silver_shard", Rarity.UNCOMMON);
    public static final Item RAW_SILVER = registerSimple("raw_silver", Rarity.UNCOMMON);
    public static final Item SILVER_INGOT = registerSimple("silver_ingot", Rarity.UNCOMMON);

    public static final Item TITANIUM_SHARD = registerSimple("titanium_shard", Rarity.RARE);
    public static final Item RAW_TITANIUM = registerSimple("raw_titanium", Rarity.RARE);
    public static final Item TITANIUM_INGOT = registerSimple("titanium_ingot", Rarity.RARE);

    public static final Item TUNGSTEN_SHARD = registerFireproof("tungsten_shard", Rarity.EPIC);
    public static final Item RAW_TUNGSTEN = registerFireproof("raw_tungsten", Rarity.EPIC);
    public static final Item TUNGSTEN_INGOT = registerFireproof("tungsten_ingot", Rarity.EPIC);

    // 錫裝備與工具
    public static final Item TIN_SWORD = registerSword("tin_sword", ModMaterials.TIN_TOOL, 3.0F, -2.4F, false, Rarity.COMMON);
    public static final Item TIN_PICKAXE = registerPickaxe("tin_pickaxe", ModMaterials.TIN_TOOL, 1.0F, -2.8F, false, Rarity.COMMON);
    public static final Item TIN_AXE = registerAxe("tin_axe", ModMaterials.TIN_TOOL, 6.0F, -3.1F, false, Rarity.COMMON);
    public static final Item TIN_SHOVEL = registerShovel("tin_shovel", ModMaterials.TIN_TOOL, 1.5F, -3.0F, false, Rarity.COMMON);
    public static final Item TIN_HOE = registerHoe("tin_hoe", ModMaterials.TIN_TOOL, -1.5F, -1.5F, false, Rarity.COMMON);
    public static final Item TIN_HELMET = registerArmor("tin_helmet", ModMaterials.TIN_ARMOR, ArmorType.HELMET, ModMaterials.TIN_ARMOR_DURABILITY, false, Rarity.COMMON);
    public static final Item TIN_CHESTPLATE = registerArmor("tin_chestplate", ModMaterials.TIN_ARMOR, ArmorType.CHESTPLATE, ModMaterials.TIN_ARMOR_DURABILITY, false, Rarity.COMMON);
    public static final Item TIN_LEGGINGS = registerArmor("tin_leggings", ModMaterials.TIN_ARMOR, ArmorType.LEGGINGS, ModMaterials.TIN_ARMOR_DURABILITY, false, Rarity.COMMON);
    public static final Item TIN_BOOTS = registerArmor("tin_boots", ModMaterials.TIN_ARMOR, ArmorType.BOOTS, ModMaterials.TIN_ARMOR_DURABILITY, false, Rarity.COMMON);

    // 銀裝備與工具
    public static final Item SILVER_SWORD = registerSword("silver_sword", ModMaterials.SILVER_TOOL, 3.0F, -2.3F, false, Rarity.UNCOMMON);
    public static final Item SILVER_PICKAXE = registerPickaxe("silver_pickaxe", ModMaterials.SILVER_TOOL, 1.0F, -2.8F, false, Rarity.UNCOMMON);
    public static final Item SILVER_AXE = registerAxe("silver_axe", ModMaterials.SILVER_TOOL, 5.5F, -3.0F, false, Rarity.UNCOMMON);
    public static final Item SILVER_SHOVEL = registerShovel("silver_shovel", ModMaterials.SILVER_TOOL, 1.5F, -3.0F, false, Rarity.UNCOMMON);
    public static final Item SILVER_HOE = registerHoe("silver_hoe", ModMaterials.SILVER_TOOL, -2.0F, -1.0F, false, Rarity.UNCOMMON);
    public static final Item SILVER_HELMET = registerArmor("silver_helmet", ModMaterials.SILVER_ARMOR, ArmorType.HELMET, ModMaterials.SILVER_ARMOR_DURABILITY, false, Rarity.UNCOMMON);
    public static final Item SILVER_CHESTPLATE = registerArmor("silver_chestplate", ModMaterials.SILVER_ARMOR, ArmorType.CHESTPLATE, ModMaterials.SILVER_ARMOR_DURABILITY, false, Rarity.UNCOMMON);
    public static final Item SILVER_LEGGINGS = registerArmor("silver_leggings", ModMaterials.SILVER_ARMOR, ArmorType.LEGGINGS, ModMaterials.SILVER_ARMOR_DURABILITY, false, Rarity.UNCOMMON);
    public static final Item SILVER_BOOTS = registerArmor("silver_boots", ModMaterials.SILVER_ARMOR, ArmorType.BOOTS, ModMaterials.SILVER_ARMOR_DURABILITY, false, Rarity.UNCOMMON);

    // 鈦裝備與工具
    public static final Item TITANIUM_SWORD = registerSword("titanium_sword", ModMaterials.TITANIUM_TOOL, 3.0F, -2.3F, false, Rarity.RARE);
    public static final Item TITANIUM_PICKAXE = registerPickaxe("titanium_pickaxe", ModMaterials.TITANIUM_TOOL, 1.0F, -2.8F, false, Rarity.RARE);
    public static final Item TITANIUM_AXE = registerAxe("titanium_axe", ModMaterials.TITANIUM_TOOL, 5.0F, -2.9F, false, Rarity.RARE);
    public static final Item TITANIUM_SHOVEL = registerShovel("titanium_shovel", ModMaterials.TITANIUM_TOOL, 1.5F, -3.0F, false, Rarity.RARE);
    public static final Item TITANIUM_HOE = registerHoe("titanium_hoe", ModMaterials.TITANIUM_TOOL, -3.0F, 0.0F, false, Rarity.RARE);
    public static final Item TITANIUM_HELMET = registerArmor("titanium_helmet", ModMaterials.TITANIUM_ARMOR, ArmorType.HELMET, ModMaterials.TITANIUM_ARMOR_DURABILITY, false, Rarity.RARE);
    public static final Item TITANIUM_CHESTPLATE = registerArmor("titanium_chestplate", ModMaterials.TITANIUM_ARMOR, ArmorType.CHESTPLATE, ModMaterials.TITANIUM_ARMOR_DURABILITY, false, Rarity.RARE);
    public static final Item TITANIUM_LEGGINGS = registerArmor("titanium_leggings", ModMaterials.TITANIUM_ARMOR, ArmorType.LEGGINGS, ModMaterials.TITANIUM_ARMOR_DURABILITY, false, Rarity.RARE);
    public static final Item TITANIUM_BOOTS = registerArmor("titanium_boots", ModMaterials.TITANIUM_ARMOR, ArmorType.BOOTS, ModMaterials.TITANIUM_ARMOR_DURABILITY, false, Rarity.RARE);

    // 鎢裝備與工具（全系列防火）
    public static final Item TUNGSTEN_SWORD = registerSword("tungsten_sword", ModMaterials.TUNGSTEN_TOOL, 3.0F, -2.5F, true, Rarity.EPIC);
    public static final Item TUNGSTEN_PICKAXE = registerPickaxe("tungsten_pickaxe", ModMaterials.TUNGSTEN_TOOL, 1.0F, -2.8F, true, Rarity.EPIC);
    public static final Item TUNGSTEN_AXE = registerAxe("tungsten_axe", ModMaterials.TUNGSTEN_TOOL, 5.0F, -3.1F, true, Rarity.EPIC);
    public static final Item TUNGSTEN_SHOVEL = registerShovel("tungsten_shovel", ModMaterials.TUNGSTEN_TOOL, 1.5F, -3.0F, true, Rarity.EPIC);
    public static final Item TUNGSTEN_HOE = registerHoe("tungsten_hoe", ModMaterials.TUNGSTEN_TOOL, -4.0F, 0.0F, true, Rarity.EPIC);
    public static final Item TUNGSTEN_HELMET = registerArmor("tungsten_helmet", ModMaterials.TUNGSTEN_ARMOR, ArmorType.HELMET, ModMaterials.TUNGSTEN_ARMOR_DURABILITY, true, Rarity.EPIC);
    public static final Item TUNGSTEN_CHESTPLATE = registerArmor("tungsten_chestplate", ModMaterials.TUNGSTEN_ARMOR, ArmorType.CHESTPLATE, ModMaterials.TUNGSTEN_ARMOR_DURABILITY, true, Rarity.EPIC);
    public static final Item TUNGSTEN_LEGGINGS = registerArmor("tungsten_leggings", ModMaterials.TUNGSTEN_ARMOR, ArmorType.LEGGINGS, ModMaterials.TUNGSTEN_ARMOR_DURABILITY, true, Rarity.EPIC);
    public static final Item TUNGSTEN_BOOTS = registerArmor("tungsten_boots", ModMaterials.TUNGSTEN_ARMOR, ArmorType.BOOTS, ModMaterials.TUNGSTEN_ARMOR_DURABILITY, true, Rarity.EPIC);

    // 6 款原創不重複可穿戴奇物（Trinkets 飾品欄：頭／頸／腰／手／腳／戒）

    public static final Map<Item, Item> ORE_TO_SHARD = new LinkedHashMap<>();
    public static final Map<Item, Item> LOOT_MINERAL_TO_SHARD = new LinkedHashMap<>();
    public static final Map<Item, Item> TRADE_MINERAL_TO_SHARD = new LinkedHashMap<>();

    static {
        ORE_TO_SHARD.put(Items.RAW_IRON, IRON_SHARD);
        ORE_TO_SHARD.put(Items.RAW_GOLD, GOLD_SHARD);
        ORE_TO_SHARD.put(Items.RAW_COPPER, COPPER_SHARD);
        ORE_TO_SHARD.put(Items.DIAMOND, DIAMOND_SHARD);
        ORE_TO_SHARD.put(Items.COAL, COAL_SHARD);
        ORE_TO_SHARD.put(Items.EMERALD, EMERALD_SHARD);
        ORE_TO_SHARD.put(Items.LAPIS_LAZULI, LAPIS_SHARD);
        ORE_TO_SHARD.put(Items.REDSTONE, REDSTONE_SHARD);
        ORE_TO_SHARD.put(Items.QUARTZ, QUARTZ_SHARD);
        ORE_TO_SHARD.put(RAW_TIN, TIN_SHARD);
        ORE_TO_SHARD.put(RAW_SILVER, SILVER_SHARD);
        ORE_TO_SHARD.put(RAW_TITANIUM, TITANIUM_SHARD);
        ORE_TO_SHARD.put(RAW_TUNGSTEN, TUNGSTEN_SHARD);

        LOOT_MINERAL_TO_SHARD.putAll(ORE_TO_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.IRON_INGOT, IRON_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.IRON_BLOCK, IRON_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.GOLD_INGOT, GOLD_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.GOLD_BLOCK, GOLD_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.COPPER_INGOT, COPPER_SHARD);
        BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace("copper_block")).ifPresent(item -> LOOT_MINERAL_TO_SHARD.put(item, COPPER_SHARD));
        LOOT_MINERAL_TO_SHARD.put(Items.DIAMOND_BLOCK, DIAMOND_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.COAL_BLOCK, COAL_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.EMERALD_BLOCK, EMERALD_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.LAPIS_BLOCK, LAPIS_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.REDSTONE_BLOCK, REDSTONE_SHARD);
        LOOT_MINERAL_TO_SHARD.put(Items.QUARTZ_BLOCK, QUARTZ_SHARD);
        LOOT_MINERAL_TO_SHARD.put(TIN_INGOT, TIN_SHARD);
        LOOT_MINERAL_TO_SHARD.put(SILVER_INGOT, SILVER_SHARD);
        LOOT_MINERAL_TO_SHARD.put(TITANIUM_INGOT, TITANIUM_SHARD);
        LOOT_MINERAL_TO_SHARD.put(TUNGSTEN_INGOT, TUNGSTEN_SHARD);

        TRADE_MINERAL_TO_SHARD.putAll(LOOT_MINERAL_TO_SHARD);
        TRADE_MINERAL_TO_SHARD.remove(Items.EMERALD);
    }

    private static Item register(String name, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name));
        Item item = new Item(props.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    private static Item registerComputer(String name) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name));
        return Registry.register(BuiltInRegistries.ITEM, key, new ComputerItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE).setId(key)));
    }

    private static Item registerCoin(String name, long value, Rarity rarity, boolean fireproof) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name));
        Item.Properties props = new Item.Properties().rarity(rarity).setId(key);
        if (fireproof) {
            props = props.fireResistant();
        }
        return Registry.register(BuiltInRegistries.ITEM, key, new CoinItem(value, props));
    }

    private static Item.Properties baseProps(boolean fireproof, Rarity rarity) {
        Item.Properties props = new Item.Properties().rarity(rarity);
        return fireproof ? props.fireResistant() : props;
    }

    private static Item registerSimple(String name, Rarity rarity) {
        return register(name, new Item.Properties().rarity(rarity));
    }

    private static Item registerFireproof(String name, Rarity rarity) {
        return register(name, new Item.Properties().fireResistant().rarity(rarity));
    }

    private static Item registerArtifact(String name, Rarity rarity, boolean fireproof) {
        Item.Properties props = new Item.Properties().stacksTo(1).rarity(rarity);
        return register(name, fireproof ? props.fireResistant() : props);
    }

    private static Item registerSword(String name, ToolMaterial mat, float damage, float speed, boolean fireproof, Rarity rarity) {
        return register(name, baseProps(fireproof, rarity).sword(mat, damage, speed));
    }

    private static Item registerPickaxe(String name, ToolMaterial mat, float damage, float speed, boolean fireproof, Rarity rarity) {
        return register(name, baseProps(fireproof, rarity).pickaxe(mat, damage, speed));
    }

    private static Item registerAxe(String name, ToolMaterial mat, float damage, float speed, boolean fireproof, Rarity rarity) {
        return register(name, baseProps(fireproof, rarity).axe(mat, damage, speed));
    }

    private static Item registerShovel(String name, ToolMaterial mat, float damage, float speed, boolean fireproof, Rarity rarity) {
        return register(name, baseProps(fireproof, rarity).shovel(mat, damage, speed));
    }

    private static Item registerHoe(String name, ToolMaterial mat, float damage, float speed, boolean fireproof, Rarity rarity) {
        return register(name, baseProps(fireproof, rarity).hoe(mat, damage, speed));
    }

    private static Item registerArmor(String name, ArmorMaterial mat, ArmorType type, int durabilityMult, boolean fireproof, Rarity rarity) {
        return register(name, baseProps(fireproof, rarity).humanoidArmor(mat, type).durability(type.getDurability(durabilityMult)));
    }

    public static final ResourceKey<CreativeModeTab> MOD_TAB_KEY = ResourceKey.create(
            BuiltInRegistries.CREATIVE_MODE_TAB.key(),
            Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "main")
    );

    public static final CreativeModeTab MOD_TAB = FabricCreativeModeTab.builder()
            .icon(() -> new ItemStack(COMPUTER))
            .title(Component.translatable("creativeTab.randomoredrop"))
            .displayItems((params, output) -> {
                // 0. 多功能電腦與實體金幣
                output.accept(COMPUTER);
                output.accept(COIN_1);
                output.accept(COIN_10);
                output.accept(COIN_100);
                output.accept(COIN_1000);
                output.accept(COIN_10000);

                // 1. 原版礦物碎片
                output.accept(COAL_SHARD);
                output.accept(COPPER_SHARD);
                output.accept(IRON_SHARD);
                output.accept(REDSTONE_SHARD);
                output.accept(LAPIS_SHARD);
                output.accept(QUARTZ_SHARD);
                output.accept(GOLD_SHARD);
                output.accept(DIAMOND_SHARD);
                output.accept(EMERALD_SHARD);

                // 2. 四款現實新礦石方塊
                output.accept(ModBlocks.TIN_ORE);
                output.accept(ModBlocks.DEEPSLATE_TIN_ORE);
                output.accept(ModBlocks.SILVER_ORE);
                output.accept(ModBlocks.DEEPSLATE_SILVER_ORE);
                output.accept(ModBlocks.TITANIUM_ORE);
                output.accept(ModBlocks.DEEPSLATE_TITANIUM_ORE);
                output.accept(ModBlocks.TUNGSTEN_ORE);
                output.accept(ModBlocks.DEEPSLATE_TUNGSTEN_ORE);

                // 3. 錫全套
                output.accept(TIN_SHARD); output.accept(RAW_TIN); output.accept(TIN_INGOT);
                output.accept(TIN_SWORD); output.accept(TIN_PICKAXE); output.accept(TIN_AXE); output.accept(TIN_SHOVEL); output.accept(TIN_HOE);
                output.accept(TIN_HELMET); output.accept(TIN_CHESTPLATE); output.accept(TIN_LEGGINGS); output.accept(TIN_BOOTS);

                // 4. 銀全套
                output.accept(SILVER_SHARD); output.accept(RAW_SILVER); output.accept(SILVER_INGOT);
                output.accept(SILVER_SWORD); output.accept(SILVER_PICKAXE); output.accept(SILVER_AXE); output.accept(SILVER_SHOVEL); output.accept(SILVER_HOE);
                output.accept(SILVER_HELMET); output.accept(SILVER_CHESTPLATE); output.accept(SILVER_LEGGINGS); output.accept(SILVER_BOOTS);

                // 5. 鈦全套
                output.accept(TITANIUM_SHARD); output.accept(RAW_TITANIUM); output.accept(TITANIUM_INGOT);
                output.accept(TITANIUM_SWORD); output.accept(TITANIUM_PICKAXE); output.accept(TITANIUM_AXE); output.accept(TITANIUM_SHOVEL); output.accept(TITANIUM_HOE);
                output.accept(TITANIUM_HELMET); output.accept(TITANIUM_CHESTPLATE); output.accept(TITANIUM_LEGGINGS); output.accept(TITANIUM_BOOTS);

                // 6. 鎢全套
                output.accept(TUNGSTEN_SHARD); output.accept(RAW_TUNGSTEN); output.accept(TUNGSTEN_INGOT);
                output.accept(TUNGSTEN_SWORD); output.accept(TUNGSTEN_PICKAXE); output.accept(TUNGSTEN_AXE); output.accept(TUNGSTEN_SHOVEL); output.accept(TUNGSTEN_HOE);
                output.accept(TUNGSTEN_HELMET); output.accept(TUNGSTEN_CHESTPLATE); output.accept(TUNGSTEN_LEGGINGS); output.accept(TUNGSTEN_BOOTS);

                // 7. 6 款原創不重複可穿戴奇物（Trinkets 飾品欄）
            })
            .build();

    public static void initialize() {
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, MOD_TAB_KEY, MOD_TAB);

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(COIN_1); entries.accept(COIN_10); entries.accept(COIN_100); entries.accept(COIN_1000); entries.accept(COIN_10000);
            ORE_TO_SHARD.values().forEach(entries::accept);
            entries.accept(RAW_TIN); entries.accept(TIN_INGOT);
            entries.accept(RAW_SILVER); entries.accept(SILVER_INGOT);
            entries.accept(RAW_TITANIUM); entries.accept(TITANIUM_INGOT);
            entries.accept(RAW_TUNGSTEN); entries.accept(TUNGSTEN_INGOT);
        });

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(TIN_PICKAXE); entries.accept(TIN_AXE); entries.accept(TIN_SHOVEL); entries.accept(TIN_HOE);
            entries.accept(SILVER_PICKAXE); entries.accept(SILVER_AXE); entries.accept(SILVER_SHOVEL); entries.accept(SILVER_HOE);
            entries.accept(TITANIUM_PICKAXE); entries.accept(TITANIUM_AXE); entries.accept(TITANIUM_SHOVEL); entries.accept(TITANIUM_HOE);
            entries.accept(TUNGSTEN_PICKAXE); entries.accept(TUNGSTEN_AXE); entries.accept(TUNGSTEN_SHOVEL); entries.accept(TUNGSTEN_HOE);
        });

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(entries -> {
            entries.accept(TIN_SWORD); entries.accept(TIN_HELMET); entries.accept(TIN_CHESTPLATE); entries.accept(TIN_LEGGINGS); entries.accept(TIN_BOOTS);
            entries.accept(SILVER_SWORD); entries.accept(SILVER_HELMET); entries.accept(SILVER_CHESTPLATE); entries.accept(SILVER_LEGGINGS); entries.accept(SILVER_BOOTS);
            entries.accept(TITANIUM_SWORD); entries.accept(TITANIUM_HELMET); entries.accept(TITANIUM_CHESTPLATE); entries.accept(TITANIUM_LEGGINGS); entries.accept(TITANIUM_BOOTS);
            entries.accept(TUNGSTEN_SWORD); entries.accept(TUNGSTEN_HELMET); entries.accept(TUNGSTEN_CHESTPLATE); entries.accept(TUNGSTEN_LEGGINGS); entries.accept(TUNGSTEN_BOOTS);
        });
    }
}
