package com.example.randomoredrop;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class ComputerItem extends Item {
    public ComputerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            openFor(serverPlayer);
        }
        return InteractionResult.SUCCESS;
    }

    public static void openFor(ServerPlayer player) {
        long bal = ModEconomy.getBalanceCents(player.getUUID());
        Component title = Component.literal("電腦終端機｜餘額：" + ModEconomy.formatCents(bal) + " 金幣")
                .withStyle(ChatFormatting.DARK_AQUA, ChatFormatting.BOLD);
        player.openMenu(new SimpleMenuProvider(
                (syncId, inv, p) -> new ComputerMenu(syncId, inv, player),
                title
        ));
    }
}
