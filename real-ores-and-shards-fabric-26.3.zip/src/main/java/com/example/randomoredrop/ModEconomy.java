package com.example.randomoredrop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DecimalFormat;
import java.util.*;

public class ModEconomy {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, Long>>() {}.getType();
    private static final DecimalFormat FMT_DEC = new DecimalFormat("#,##0.##");

    // 全部以「分（cents）」儲存：100 cents = 1.00 金幣，10 cents = 0.1 金幣，25 cents = 0.25 金幣（完全無浮點誤差）
    private static final Map<Item, Long> EXPLICIT_CENTS = new LinkedHashMap<>();
    private static final Set<Item> BULK_SELLABLE = new HashSet<>();
    private static final Map<UUID, Long> BALANCES_CENTS = new HashMap<>();
    private static Path saveFile;

    public static void initialize() {
        // 實體金幣等值面額（不可透過 /sell all 賣，應使用右鍵或 /deposit 存入）
        EXPLICIT_CENTS.put(ModItems.COMPUTER, 5000L); // 50 金幣
        EXPLICIT_CENTS.put(ModItems.COIN_1, 100L);
        EXPLICIT_CENTS.put(ModItems.COIN_10, 1000L);
        EXPLICIT_CENTS.put(ModItems.COIN_100, 10000L);
        EXPLICIT_CENTS.put(ModItems.COIN_1000, 100000L);
        EXPLICIT_CENTS.put(ModItems.COIN_10000, 1000000L);

        // === 嚴格材料加總計價（4 碎片 = 1 礦，9 礦 = 1 礦磚，工具/盔甲 = 消耗金屬錠總值，絕無刷錢漏洞）===
        // 煤炭：碎片 0.25 | 煤炭 1 | 煤磚 9
        registerMineralFamily(ModItems.COAL_SHARD, Items.COAL, Items.COAL, Items.COAL_BLOCK, 100L);
        EXPLICIT_CENTS.put(Items.CHARCOAL, 100L);

        // 銅：碎片 0.5 | 粗銅/銅錠 2 | 銅磚 18
        registerMineralFamily(ModItems.COPPER_SHARD, Items.RAW_COPPER, Items.COPPER_INGOT, null, 200L);
        EXPLICIT_CENTS.put(Items.RAW_COPPER_BLOCK, 1800L);
        BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace("copper_block")).ifPresent(i -> EXPLICIT_CENTS.put(i, 1800L));

        // 紅石：碎片 0.5 | 紅石 2 | 紅石磚 18
        registerMineralFamily(ModItems.REDSTONE_SHARD, Items.REDSTONE, Items.REDSTONE, Items.REDSTONE_BLOCK, 200L);

        // 青金石：碎片 0.75 | 青金石 3 | 青金石磚 27
        registerMineralFamily(ModItems.LAPIS_SHARD, Items.LAPIS_LAZULI, Items.LAPIS_LAZULI, Items.LAPIS_BLOCK, 300L);

        // 地獄石英：碎片 1 | 石英 4 | 石英塊(4石英) 16
        registerBulk(ModItems.QUARTZ_SHARD, 100L);
        registerBulk(Items.QUARTZ, 400L);
        EXPLICIT_CENTS.put(Items.QUARTZ_BLOCK, 1600L);

        // 鐵：碎片 2 | 粗鐵/鐵錠 8 | 鐵磚 72 | 鐵粒 = 錠/9（嚴格 1/9，避免 Upgrader 套利）
        registerMineralFamily(ModItems.IRON_SHARD, Items.RAW_IRON, Items.IRON_INGOT, Items.IRON_BLOCK, 800L);
        EXPLICIT_CENTS.put(Items.RAW_IRON_BLOCK, 7200L);
        EXPLICIT_CENTS.put(Items.IRON_NUGGET, 800L / 9L); // 88 cents ≈ 0.88 金幣（9 粒 = 1 錠）
        registerExactGearSet(800L,
                Items.IRON_SWORD, Items.IRON_PICKAXE, Items.IRON_AXE, Items.IRON_SHOVEL, Items.IRON_HOE,
                Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS);

        // 金：碎片 4 | 粗金/金錠 16 | 金磚 144 | 金粒 = 錠/9
        registerMineralFamily(ModItems.GOLD_SHARD, Items.RAW_GOLD, Items.GOLD_INGOT, Items.GOLD_BLOCK, 1600L);
        EXPLICIT_CENTS.put(Items.RAW_GOLD_BLOCK, 14400L);
        EXPLICIT_CENTS.put(Items.GOLD_NUGGET, 1600L / 9L); // 177 cents
        registerExactGearSet(1600L,
                Items.GOLDEN_SWORD, Items.GOLDEN_PICKAXE, Items.GOLDEN_AXE, Items.GOLDEN_SHOVEL, Items.GOLDEN_HOE,
                Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS);

        // 綠寶石：碎片 15 | 綠寶石 60 | 綠寶石磚 540
        registerMineralFamily(ModItems.EMERALD_SHARD, Items.EMERALD, Items.EMERALD, Items.EMERALD_BLOCK, 6000L);

        // 鑽石：碎片 40 | 鑽石 160 | 鑽石磚 1,440
        registerMineralFamily(ModItems.DIAMOND_SHARD, Items.DIAMOND, Items.DIAMOND, Items.DIAMOND_BLOCK, 16000L);
        registerExactGearSet(16000L,
                Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE,
                Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);

        // 獄髓：遠古遺骸/碎片 800 | 獄髓錠(4碎片+4金錠) 3,264 | 獄髓磚(9錠) 29,376
        registerBulk(Items.ANCIENT_DEBRIS, 80000L);
        registerBulk(Items.NETHERITE_SCRAP, 80000L);
        registerBulk(Items.NETHERITE_INGOT, 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_BLOCK, 326400L * 9L);
        // 獄髓裝備 = 對應鑽石裝備 + 1 獄髓錠
        EXPLICIT_CENTS.put(Items.NETHERITE_SWORD, 32000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_PICKAXE, 48000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_AXE, 48000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_SHOVEL, 16000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_HOE, 32000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_HELMET, 80000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_CHESTPLATE, 128000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_LEGGINGS, 112000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_BOOTS, 64000L + 326400L);

        // === 4 款現實世界金屬（嚴格材料加總）===
        // 錫：碎片 0.75 | 粗錫/錫錠 3 | 裝備 = 消耗錠數 × 3
        registerBulk(ModBlocks.TIN_ORE.asItem(), 300L);
        registerBulk(ModBlocks.DEEPSLATE_TIN_ORE.asItem(), 300L);
        registerMineralFamily(ModItems.TIN_SHARD, ModItems.RAW_TIN, ModItems.TIN_INGOT, null, 300L);
        registerExactGearSet(300L,
                ModItems.TIN_SWORD, ModItems.TIN_PICKAXE, ModItems.TIN_AXE, ModItems.TIN_SHOVEL, ModItems.TIN_HOE,
                ModItems.TIN_HELMET, ModItems.TIN_CHESTPLATE, ModItems.TIN_LEGGINGS, ModItems.TIN_BOOTS);

        // 銀：碎片 5 | 粗銀/銀錠 20 | 裝備 = 消耗錠數 × 20
        registerBulk(ModBlocks.SILVER_ORE.asItem(), 2000L);
        registerBulk(ModBlocks.DEEPSLATE_SILVER_ORE.asItem(), 2000L);
        registerMineralFamily(ModItems.SILVER_SHARD, ModItems.RAW_SILVER, ModItems.SILVER_INGOT, null, 2000L);
        registerExactGearSet(2000L,
                ModItems.SILVER_SWORD, ModItems.SILVER_PICKAXE, ModItems.SILVER_AXE, ModItems.SILVER_SHOVEL, ModItems.SILVER_HOE,
                ModItems.SILVER_HELMET, ModItems.SILVER_CHESTPLATE, ModItems.SILVER_LEGGINGS, ModItems.SILVER_BOOTS);

        // 鈦：碎片 150 | 粗鈦/鈦錠 600 | 裝備 = 消耗錠數 × 600
        registerBulk(ModBlocks.TITANIUM_ORE.asItem(), 60000L);
        registerBulk(ModBlocks.DEEPSLATE_TITANIUM_ORE.asItem(), 60000L);
        registerMineralFamily(ModItems.TITANIUM_SHARD, ModItems.RAW_TITANIUM, ModItems.TITANIUM_INGOT, null, 60000L);
        registerExactGearSet(60000L,
                ModItems.TITANIUM_SWORD, ModItems.TITANIUM_PICKAXE, ModItems.TITANIUM_AXE, ModItems.TITANIUM_SHOVEL, ModItems.TITANIUM_HOE,
                ModItems.TITANIUM_HELMET, ModItems.TITANIUM_CHESTPLATE, ModItems.TITANIUM_LEGGINGS, ModItems.TITANIUM_BOOTS);

        // 鎢：碎片 400 | 粗鎢/鎢錠 1,600 | 裝備 = 消耗錠數 × 1,600
        registerBulk(ModBlocks.TUNGSTEN_ORE.asItem(), 160000L);
        registerBulk(ModBlocks.DEEPSLATE_TUNGSTEN_ORE.asItem(), 160000L);
        registerMineralFamily(ModItems.TUNGSTEN_SHARD, ModItems.RAW_TUNGSTEN, ModItems.TUNGSTEN_INGOT, null, 160000L);
        registerExactGearSet(160000L,
                ModItems.TUNGSTEN_SWORD, ModItems.TUNGSTEN_PICKAXE, ModItems.TUNGSTEN_AXE, ModItems.TUNGSTEN_SHOVEL, ModItems.TUNGSTEN_HOE,
                ModItems.TUNGSTEN_HELMET, ModItems.TUNGSTEN_CHESTPLATE, ModItems.TUNGSTEN_LEGGINGS, ModItems.TUNGSTEN_BOOTS);


        // ============================================================
        // 所有價值單位 = 金幣（內部存 cents，100 cents = 1 金幣）
        // 原則：成品價值 = 配方材料價值加總，杜絕 Upgrader 低價升高價
        // ============================================================
        final long C = 100L;          // 1 金幣
        final long IRON = 800L;       // 鐵錠 8
        final long GOLD = 1600L;      // 金錠 16
        final long DIA = 16000L;      // 鑽石 160
        final long RED = 200L;        // 紅石 2
        final long COAL = 100L;       // 煤炭 1
        final long QUARTZ = 400L;     // 石英 4
        final long INUG = IRON / 9L;  // 鐵粒
        final long GNUG = GOLD / 9L;  // 金粒

        // --- 鐵製品（按消耗鐵錠）---
        EXPLICIT_CENTS.put(Items.ANVIL, IRON * 31L);                    // 248（3鐵磚+4錠）
        EXPLICIT_CENTS.put(Items.CHIPPED_ANVIL, IRON * 23L);            // 184
        EXPLICIT_CENTS.put(Items.DAMAGED_ANVIL, IRON * 15L);            // 120
        EXPLICIT_CENTS.put(Items.IRON_DOOR, IRON * 2L);                 // 16
        EXPLICIT_CENTS.put(Items.IRON_TRAPDOOR, IRON * 4L);             // 32
        EXPLICIT_CENTS.put(Items.IRON_BARS, Math.max(1L, IRON * 6L / 16L)); // 6錠→16個 ≈3
        EXPLICIT_CENTS.put(Items.HEAVY_WEIGHTED_PRESSURE_PLATE, IRON * 2L); // 16
        EXPLICIT_CENTS.put(Items.BUCKET, IRON * 3L);                    // 24
        EXPLICIT_CENTS.put(Items.WATER_BUCKET, IRON * 3L + 10L);
        EXPLICIT_CENTS.put(Items.LAVA_BUCKET, IRON * 3L + 200L);
        EXPLICIT_CENTS.put(Items.POWDER_SNOW_BUCKET, IRON * 3L + 20L);
        EXPLICIT_CENTS.put(Items.MILK_BUCKET, IRON * 3L + 30L);
        EXPLICIT_CENTS.put(Items.AXOLOTL_BUCKET, IRON * 3L + 500L);
        EXPLICIT_CENTS.put(Items.TADPOLE_BUCKET, IRON * 3L + 200L);
        EXPLICIT_CENTS.put(Items.COD_BUCKET, IRON * 3L + 100L);
        EXPLICIT_CENTS.put(Items.SALMON_BUCKET, IRON * 3L + 100L);
        EXPLICIT_CENTS.put(Items.PUFFERFISH_BUCKET, IRON * 3L + 150L);
        EXPLICIT_CENTS.put(Items.TROPICAL_FISH_BUCKET, IRON * 3L + 150L);
        EXPLICIT_CENTS.put(Items.CAULDRON, IRON * 7L);                  // 56
        EXPLICIT_CENTS.put(Items.HOPPER, IRON * 5L + 50L);              // 40.5 → 5錠+箱
        EXPLICIT_CENTS.put(Items.MINECART, IRON * 5L);                  // 40
        EXPLICIT_CENTS.put(Items.CHEST_MINECART, IRON * 5L + 50L);
        EXPLICIT_CENTS.put(Items.FURNACE_MINECART, IRON * 5L + 50L);
        EXPLICIT_CENTS.put(Items.TNT_MINECART, IRON * 5L + 150L);
        EXPLICIT_CENTS.put(Items.HOPPER_MINECART, IRON * 5L + IRON * 5L + 50L); // 80.5
        EXPLICIT_CENTS.put(Items.RAIL, Math.max(1L, (IRON * 6L + 20L) / 16L)); // 6錠+棒→16
        EXPLICIT_CENTS.put(Items.POWERED_RAIL, Math.max(1L, (GNUG * 6L + 20L + RED) / 6L));
        EXPLICIT_CENTS.put(Items.DETECTOR_RAIL, Math.max(1L, (IRON * 6L + RED + 20L) / 6L));
        EXPLICIT_CENTS.put(Items.ACTIVATOR_RAIL, Math.max(1L, (IRON * 6L + RED + 20L) / 6L));
        EXPLICIT_CENTS.put(Items.SHEARS, IRON * 2L);                    // 16
        EXPLICIT_CENTS.put(Items.FLINT_AND_STEEL, IRON + 10L);          // 8.1
        EXPLICIT_CENTS.put(Items.COMPASS, IRON * 4L + RED);             // 34
        EXPLICIT_CENTS.put(Items.CLOCK, GOLD * 4L + RED);               // 66
        // MC 26.3：Items.CHAIN 可能已移除／改名，改用 registry id
        BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace("chain"))
                .ifPresent(i -> EXPLICIT_CENTS.put(i, INUG + IRON * 2L));
        BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace("iron_chain"))
                .ifPresent(i -> EXPLICIT_CENTS.put(i, INUG + IRON * 2L));
        EXPLICIT_CENTS.put(Items.LANTERN, INUG * 8L + 20L);             // 8粒+火把
        EXPLICIT_CENTS.put(Items.SOUL_LANTERN, INUG * 8L + 40L);
        EXPLICIT_CENTS.put(Items.IRON_HORSE_ARMOR, IRON * 7L);          // 不可合成，給合理高價
        EXPLICIT_CENTS.put(Items.BLAST_FURNACE, IRON * 5L + 80L);       // 5錠+爐+平滑石
        EXPLICIT_CENTS.put(Items.SMOKER, 80L);
        EXPLICIT_CENTS.put(Items.SMITHING_TABLE, IRON * 2L + 50L);
        EXPLICIT_CENTS.put(Items.STONECUTTER, IRON + 40L);
        EXPLICIT_CENTS.put(Items.GRINDSTONE, 2 * 30L + 40L);            // 2棒+石板+石
        EXPLICIT_CENTS.put(Items.TRIPWIRE_HOOK, IRON / 2L + 15L);
        EXPLICIT_CENTS.put(Items.PISTON, IRON + RED + 60L);
        EXPLICIT_CENTS.put(Items.STICKY_PISTON, IRON + RED + 60L + 100L);
        EXPLICIT_CENTS.put(Items.HOPPER, IRON * 5L + 50L);
        EXPLICIT_CENTS.put(Items.CROSSBOW, IRON + 80L);
        EXPLICIT_CENTS.put(Items.SHIELD, IRON + 60L);
        // lightning_rod 在 26.3 為 WeatheringCopperCollection，不能當 Item 常數使用
        for (String id : new String[]{
                "lightning_rod", "exposed_lightning_rod", "weathered_lightning_rod", "oxidized_lightning_rod",
                "waxed_lightning_rod", "waxed_exposed_lightning_rod", "waxed_weathered_lightning_rod", "waxed_oxidized_lightning_rod"
        }) {
            BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace(id))
                    .ifPresent(i -> EXPLICIT_CENTS.put(i, 200L * 3L));
        }
        BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace("spyglass"))
                .ifPresent(i -> EXPLICIT_CENTS.put(i, 200L * 2L + 400L));

        // --- 金製品 ---
        EXPLICIT_CENTS.put(Items.LIGHT_WEIGHTED_PRESSURE_PLATE, GOLD * 2L); // 32
        EXPLICIT_CENTS.put(Items.GOLDEN_APPLE, GOLD * 8L + 50L);        // 128.5
        EXPLICIT_CENTS.put(Items.ENCHANTED_GOLDEN_APPLE, 350000L);      // 3500 稀有
        EXPLICIT_CENTS.put(Items.GOLDEN_CARROT, GNUG * 8L + 30L);       // 8金粒+胡蘿蔔
        EXPLICIT_CENTS.put(Items.GOLDEN_HORSE_ARMOR, GOLD * 7L);
        EXPLICIT_CENTS.put(Items.GLISTERING_MELON_SLICE, GNUG * 8L + 20L);
        EXPLICIT_CENTS.put(Items.GOLDEN_SWORD, GOLD * 2L); // 已在 gear set，覆蓋無妨
        EXPLICIT_CENTS.put(Items.CLOCK, GOLD * 4L + RED);

        // --- 鑽石成品 ---
        EXPLICIT_CENTS.put(Items.DIAMOND_HORSE_ARMOR, DIA * 7L);
        EXPLICIT_CENTS.put(Items.JUKEBOX, DIA + 50L);
        EXPLICIT_CENTS.put(Items.ENCHANTING_TABLE, DIA * 2L + 800L * 4L); // 2鑽+4黑曜石
        EXPLICIT_CENTS.put(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE, 50000L); // 500 稀有模板

        // --- 紅石元件（材料加總）---
        EXPLICIT_CENTS.put(Items.REPEATER, RED * 3L + 40L);             // 3紅石+石+火把
        EXPLICIT_CENTS.put(Items.COMPARATOR, RED * 3L + QUARTZ + 40L);
        EXPLICIT_CENTS.put(Items.REDSTONE_TORCH, RED + 10L);
        EXPLICIT_CENTS.put(Items.REDSTONE_LAMP, RED * 4L + 100L);       // 4紅石+螢光石
        EXPLICIT_CENTS.put(Items.DISPENSER, RED + COAL + 80L);          // 簡化
        EXPLICIT_CENTS.put(Items.DROPPER, RED + 60L);
        EXPLICIT_CENTS.put(Items.OBSERVER, RED + QUARTZ + 40L);
        EXPLICIT_CENTS.put(Items.DAYLIGHT_DETECTOR, QUARTZ * 3L + 50L);
        EXPLICIT_CENTS.put(Items.HOPPER, IRON * 5L + 50L);
        EXPLICIT_CENTS.put(Items.NOTE_BLOCK, RED + 50L);
        EXPLICIT_CENTS.put(Items.TARGET, RED + 40L);

        // --- 下界 / 終界稀有 ---
        EXPLICIT_CENTS.put(Items.OBSIDIAN, 800L);                       // 8
        EXPLICIT_CENTS.put(Items.CRYING_OBSIDIAN, 1200L);               // 12
        EXPLICIT_CENTS.put(Items.ENDER_PEARL, 1500L);                   // 15
        EXPLICIT_CENTS.put(Items.BLAZE_ROD, 2400L);                     // 24
        EXPLICIT_CENTS.put(Items.BLAZE_POWDER, 1200L);                  // 12
        EXPLICIT_CENTS.put(Items.ENDER_EYE, 1500L + 1200L);             // 27
        EXPLICIT_CENTS.put(Items.GHAST_TEAR, 6000L);                    // 60
        EXPLICIT_CENTS.put(Items.MAGMA_CREAM, 1500L);
        EXPLICIT_CENTS.put(Items.SHULKER_SHELL, 18000L);                // 180
        EXPLICIT_CENTS.put(Items.SHULKER_BOX, 18000L * 2L + 50L);       // 360.5
        EXPLICIT_CENTS.put(Items.TOTEM_OF_UNDYING, 65000L);             // 650
        EXPLICIT_CENTS.put(Items.ELYTRA, 280000L);                      // 2800
        EXPLICIT_CENTS.put(Items.NETHER_STAR, 600000L);                 // 6000
        EXPLICIT_CENTS.put(Items.BEACON, 600000L + 800L * 3L);          // 6024
        EXPLICIT_CENTS.put(Items.HEART_OF_THE_SEA, 45000L);             // 450
        EXPLICIT_CENTS.put(Items.NAUTILUS_SHELL, 2500L);                // 25
        EXPLICIT_CENTS.put(Items.TRIDENT, 80000L);                      // 800
        EXPLICIT_CENTS.put(Items.PHANTOM_MEMBRANE, 1200L);              // 12
        EXPLICIT_CENTS.put(Items.ECHO_SHARD, 8000L);                    // 80
        EXPLICIT_CENTS.put(Items.RECOVERY_COMPASS, 8000L * 8L + IRON * 4L + RED);
        EXPLICIT_CENTS.put(Items.DRAGON_BREATH, 5000L);                 // 50
        EXPLICIT_CENTS.put(Items.EXPERIENCE_BOTTLE, 800L);              // 8
        EXPLICIT_CENTS.put(Items.SADDLE, 5000L);                        // 50
        EXPLICIT_CENTS.put(Items.NAME_TAG, 3000L);                      // 30
        EXPLICIT_CENTS.put(Items.GOAT_HORN, 4000L);                     // 40
        EXPLICIT_CENTS.put(Items.FIREWORK_ROCKET, 40L);
        EXPLICIT_CENTS.put(Items.FIREWORK_STAR, 50L);

        // 音樂唱片：依稀有度（用 registry 名稱避免版本缺項編譯失敗）
        long discCommon = 15000L;   // 150 金幣
        long discRare = 25000L;     // 250 金幣
        long discEpic = 40000L;     // 400 金幣
        for (String id : new String[]{
                "music_disc_11", "music_disc_13", "music_disc_blocks", "music_disc_cat",
                "music_disc_chirp", "music_disc_far", "music_disc_mall", "music_disc_mellohi",
                "music_disc_stal", "music_disc_strad", "music_disc_wait", "music_disc_ward",
                "music_disc_otherside", "music_disc_5", "music_disc_pigstep", "music_disc_relic",
                "music_disc_creator", "music_disc_creator_music_box", "music_disc_precipice"
        }) {
            final long price = id.contains("pigstep") || id.contains("relic") || id.contains("creator")
                    ? discEpic
                    : (id.contains("otherside") || id.endsWith("_5") || id.contains("precipice") ? discRare : discCommon);
            BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace(id))
                    .ifPresent(i -> EXPLICIT_CENTS.put(i, price));
        }

        // 木頭工具（極低，避免當高價素材）
        EXPLICIT_CENTS.put(Items.WOODEN_SWORD, 40L);
        EXPLICIT_CENTS.put(Items.WOODEN_PICKAXE, 60L);
        EXPLICIT_CENTS.put(Items.WOODEN_AXE, 60L);
        EXPLICIT_CENTS.put(Items.WOODEN_SHOVEL, 20L);
        EXPLICIT_CENTS.put(Items.WOODEN_HOE, 40L);
        // 石製工具
        EXPLICIT_CENTS.put(Items.STONE_SWORD, 80L);
        EXPLICIT_CENTS.put(Items.STONE_PICKAXE, 120L);
        EXPLICIT_CENTS.put(Items.STONE_AXE, 120L);
        EXPLICIT_CENTS.put(Items.STONE_SHOVEL, 40L);
        EXPLICIT_CENTS.put(Items.STONE_HOE, 80L);
        // 皮革甲
        EXPLICIT_CENTS.put(Items.LEATHER_HELMET, 250L);
        EXPLICIT_CENTS.put(Items.LEATHER_CHESTPLATE, 400L);
        EXPLICIT_CENTS.put(Items.LEATHER_LEGGINGS, 350L);
        EXPLICIT_CENTS.put(Items.LEATHER_BOOTS, 200L);
        EXPLICIT_CENTS.put(Items.LEATHER, 50L);
        EXPLICIT_CENTS.put(Items.RABBIT_HIDE, 40L);

        // 食物保底（避免堆疊食物當升級燃料打高價）
        EXPLICIT_CENTS.put(Items.BREAD, 30L);
        EXPLICIT_CENTS.put(Items.COOKED_BEEF, 40L);
        EXPLICIT_CENTS.put(Items.COOKED_PORKCHOP, 40L);
        EXPLICIT_CENTS.put(Items.COOKED_CHICKEN, 30L);
        EXPLICIT_CENTS.put(Items.COOKED_MUTTON, 30L);
        EXPLICIT_CENTS.put(Items.COOKED_COD, 25L);
        EXPLICIT_CENTS.put(Items.COOKED_SALMON, 30L);
        EXPLICIT_CENTS.put(Items.APPLE, 20L);
        EXPLICIT_CENTS.put(Items.GOLDEN_APPLE, GOLD * 8L + 50L); // 再寫一次確保
        EXPLICIT_CENTS.put(Items.POTATO, 10L);
        EXPLICIT_CENTS.put(Items.BAKED_POTATO, 15L);
        EXPLICIT_CENTS.put(Items.CARROT, 15L);
        EXPLICIT_CENTS.put(Items.BEETROOT, 10L);
        EXPLICIT_CENTS.put(Items.MELON_SLICE, 8L);
        EXPLICIT_CENTS.put(Items.PUMPKIN_PIE, 40L);
        EXPLICIT_CENTS.put(Items.COOKIE, 15L);
        EXPLICIT_CENTS.put(Items.CAKE, 120L);
        EXPLICIT_CENTS.put(Items.MUSHROOM_STEW, 30L);
        EXPLICIT_CENTS.put(Items.RABBIT_STEW, 50L);
        EXPLICIT_CENTS.put(Items.SUSPICIOUS_STEW, 40L);
        EXPLICIT_CENTS.put(Items.ROTTEN_FLESH, 5L);
        EXPLICIT_CENTS.put(Items.SPIDER_EYE, 40L);
        EXPLICIT_CENTS.put(Items.FERMENTED_SPIDER_EYE, 80L);
        EXPLICIT_CENTS.put(Items.BOWL, 10L);

        // 箭矢 / 彈藥
        EXPLICIT_CENTS.put(Items.ARROW, 15L);
        EXPLICIT_CENTS.put(Items.SPECTRAL_ARROW, 80L);
        EXPLICIT_CENTS.put(Items.TIPPED_ARROW, 60L);
        EXPLICIT_CENTS.put(Items.FIRE_CHARGE, 50L);
        EXPLICIT_CENTS.put(Items.SNOWBALL, 2L);
        EXPLICIT_CENTS.put(Items.EGG, 8L);
        EXPLICIT_CENTS.put(Items.ENDER_PEARL, 1500L);

        // 瓶子 / 釀造
        EXPLICIT_CENTS.put(Items.GLASS_BOTTLE, 15L);
        EXPLICIT_CENTS.put(Items.POTION, 100L);
        EXPLICIT_CENTS.put(Items.SPLASH_POTION, 150L);
        EXPLICIT_CENTS.put(Items.LINGERING_POTION, 200L);
        EXPLICIT_CENTS.put(Items.BREWING_STAND, 2400L + 60L); // 1烈焰棒+石
        EXPLICIT_CENTS.put(Items.GLISTERING_MELON_SLICE, GNUG * 8L + 20L);
        EXPLICIT_CENTS.put(Items.MAGMA_CREAM, 1500L);
        EXPLICIT_CENTS.put(Items.NETHER_WART, 80L);
        EXPLICIT_CENTS.put(Items.BLAZE_POWDER, 1200L);
        EXPLICIT_CENTS.put(Items.BLAZE_ROD, 2400L);

        // 螢光石 / 其他常用
        EXPLICIT_CENTS.put(Items.GLOWSTONE_DUST, 50L);
        EXPLICIT_CENTS.put(Items.GLOWSTONE, 200L);
        EXPLICIT_CENTS.put(Items.GUNPOWDER, 40L);
        EXPLICIT_CENTS.put(Items.SUGAR, 10L);
        EXPLICIT_CENTS.put(Items.PAPER, 8L);
        EXPLICIT_CENTS.put(Items.BOOK, 40L);
        EXPLICIT_CENTS.put(Items.BOOKSHELF, 200L);
        EXPLICIT_CENTS.put(Items.WRITABLE_BOOK, 60L);
        EXPLICIT_CENTS.put(Items.MAP, 50L);
        EXPLICIT_CENTS.put(Items.FILLED_MAP, 80L);
        EXPLICIT_CENTS.put(Items.ITEM_FRAME, 40L);
        EXPLICIT_CENTS.put(Items.GLOW_ITEM_FRAME, 60L);
        EXPLICIT_CENTS.put(Items.PAINTING, 50L);
        EXPLICIT_CENTS.put(Items.FLOWER_POT, 20L);
        EXPLICIT_CENTS.put(Items.ARMOR_STAND, 80L);
        EXPLICIT_CENTS.put(Items.LEAD, 60L);
        EXPLICIT_CENTS.put(Items.BONE, 20L);
        EXPLICIT_CENTS.put(Items.BONE_BLOCK, 180L);
        EXPLICIT_CENTS.put(Items.STRING, 15L);
        EXPLICIT_CENTS.put(Items.FEATHER, 10L);
        EXPLICIT_CENTS.put(Items.FLINT, 10L);
        EXPLICIT_CENTS.put(Items.LEATHER, 50L);
        EXPLICIT_CENTS.put(Items.SLIME_BALL, 80L);
        EXPLICIT_CENTS.put(Items.SLIME_BLOCK, 720L);
        EXPLICIT_CENTS.put(Items.HONEY_BOTTLE, 40L);
        EXPLICIT_CENTS.put(Items.HONEYCOMB, 30L);
        EXPLICIT_CENTS.put(Items.HONEY_BLOCK, 120L);
        EXPLICIT_CENTS.put(Items.HONEYCOMB_BLOCK, 120L);
        EXPLICIT_CENTS.put(Items.ENDER_CHEST, 1500L * 8L + 800L); // 8珍珠+黑曜石
        EXPLICIT_CENTS.put(Items.RESPAWN_ANCHOR, 1200L * 6L + 200L * 3L); // 哭黑曜石+螢光石
    }

    private static void registerMineralFamily(Item shard, Item raw, Item ingot, Item block, long unitCents) {
        registerBulk(shard, unitCents / 4L);
        registerBulk(raw, unitCents);
        registerBulk(ingot, unitCents);
        if (block != null) {
            EXPLICIT_CENTS.put(block, unitCents * 9L);
        }
    }

    private static void registerBulk(Item item, long cents) {
        EXPLICIT_CENTS.put(item, cents);
        BULK_SELLABLE.add(item);
    }

    private static void registerExactGearSet(long ingotCents, Item sword, Item pick, Item axe, Item shovel, Item hoe,
                                             Item helmet, Item chest, Item legs, Item boots) {
        EXPLICIT_CENTS.put(sword, ingotCents * 2L);
        EXPLICIT_CENTS.put(pick, ingotCents * 3L);
        EXPLICIT_CENTS.put(axe, ingotCents * 3L);
        EXPLICIT_CENTS.put(shovel, ingotCents);
        EXPLICIT_CENTS.put(hoe, ingotCents * 2L);
        EXPLICIT_CENTS.put(helmet, ingotCents * 5L);
        EXPLICIT_CENTS.put(chest, ingotCents * 8L);
        EXPLICIT_CENTS.put(legs, ingotCents * 7L);
        EXPLICIT_CENTS.put(boots, ingotCents * 4L);
    }

    /**
     * 遊戲內「所有物品」都有對應的精準金幣價值（以分 cents 計，100 = 1.00 金幣）
     */
    private static final Set<String> FORBIDDEN_PATHS = Set.of(
            "barrier", "bedrock", "end_portal_frame", "dragon_egg",
            "command_block", "chain_command_block", "repeating_command_block", "command_block_minecart",
            "structure_block", "structure_void", "jigsaw", "light", "debug_stick", "knowledge_book",
            "test_block", "test_instance_block", "spawner", "trial_spawner", "vault",
            "reinforced_deepslate", "budding_amethyst", "petrified_oak_slab",
            "farmland", "dirt_path", "frogspawn", "chorus_plant", "player_head", "upgrader"
    );

    /**
     * 生存模式無法正常取得、管理員專用或全世界極度唯一（如龍蛋、基岩、屏障、終界傳送門框）的物品
     */
    public static boolean isForbiddenOrUnobtainable(Item item) {
        if (item == null || item == Items.AIR) {
            return true;
        }
        String path = BuiltInRegistries.ITEM.getKey(item).getPath();
        return FORBIDDEN_PATHS.contains(path)
                || path.endsWith("_spawn_egg")
                || path.startsWith("infested_")
                || path.contains("command_block")
                || path.contains("structure_")
                || path.contains("end_portal");
    }

    /**
     * 判斷是否為任何奇物（含 Artifacts 模組全系列與本模組 6 款奇物）；奇物禁止透過開箱或 Upgrader 取得
     */
    public static boolean isArtifactItem(Item item) {
        if (item == null || item == Items.AIR) {
            return false;
        }
        return "artifacts".equals(BuiltInRegistries.ITEM.getKey(item).getNamespace());
    }

    /**
     * 依 Artifacts 模組每款奇物的正面實戰強度分級定價（以 cents 計，100 = 1 金幣）
     */
    private static long getExternalArtifactCents(String path) {
        return switch (path) {
            // Tier S：質變級生存／戰鬥／經濟神器（10,000 – 15,000 金幣）
            case "everlasting_beef", "eternal_steak" -> 1500000L;                // 15,000（無限食物）
            case "crystal_heart", "vampiric_glove", "chorus_totem" -> 1200000L;  // 12,000（加血／吸血／免死傳送）
            case "helium_flamingo" -> 1100000L;                                  // 11,000（空中游泳滑翔）
            case "cloud_in_a_bottle", "antidote_vessel", "villager_hat", "lucky_scarf" -> 1000000L; // 10,000

            // Tier A：強力戰鬥／機動／採礦奇物（7,500 – 9,000 金幣）
            case "power_glove" -> 900000L;                                       // 9,000
            case "feral_claws", "digging_claws", "night_vision_goggles" -> 850000L; // 8,500
            case "obsidian_skull", "running_shoes", "bunny_hoppers", "scarf_of_invisibility" -> 800000L; // 8,000
            case "universal_attractor", "cross_necklace", "fire_gauntlet",
                    "withered_bracelet", "pickaxe_heater", "warp_drive" -> 750000L; // 7,500

            // Tier B：中高階功能／水陸移動／反擊奇物（5,000 – 6,000 金幣）
            case "flame_pendant", "shock_pendant", "thorn_pendant",
                    "aqua_dashers", "strider_shoes", "kitty_slippers" -> 600000L; // 6,000
            case "charm_of_sinking", "snorkel", "flippers" -> 550000L;           // 5,500
            case "panic_necklace", "steadfast_spikes", "pocket_piston", "umbrella",
                    "onion_ring", "rooted_boots", "superstitious_hat", "witch_hat" -> 500000L; // 5,000

            // Tier C：輕度情境／輔助奇物（3,500 金幣）與純趣味道具（1,000 金幣）
            case "cowboy_hat", "golden_hook", "angler_hat", "snowshoes",
                    "charm_of_shrinking", "plastic_drinking_hat", "novelty_drinking_hat" -> 350000L; // 3,500
            case "whoopee_cushion" -> 100000L;                                   // 1,000
            default -> 450000L;                                                  // 其他奇物保底 4,500
        };
    }

    public static long getCents(Item item) {
        if (isForbiddenOrUnobtainable(item)) {
            return 0L;
        }
        Identifier key = BuiltInRegistries.ITEM.getKey(item);
        if ("artifacts".equals(key.getNamespace())) {
            return getExternalArtifactCents(key.getPath());
        }
        Long explicit = EXPLICIT_CENTS.get(item);
        if (explicit != null) {
            return explicit;
        }
        return computeFallbackCents(item);
    }

    private static long computeFallbackCents(Item item) {
        String path = BuiltInRegistries.ITEM.getKey(item).getPath();

        // 含金屬關鍵字的物品：至少按「相關材料」保底，避免鐵門/鐵砧變體等被当成 0.3 金幣雜物
        if (path.contains("netherite")) {
            return 326400L; // 至少 1 獄髓錠
        }
        if (path.contains("diamond")) {
            return 16000L; // 至少 1 鑽石
        }
        if (path.contains("golden") || path.contains("gold")) {
            if (path.contains("nugget")) return 1600L / 9L;
            return 1600L; // 至少 1 金錠
        }
        if (path.contains("iron") || path.contains("anvil") || path.contains("hopper")
                || path.contains("cauldron") || path.contains("minecart") || path.equals("bucket")
                || path.endsWith("_bucket") || path.contains("shears") || path.contains("compass")
                || path.contains("chain") || path.contains("lantern") && !path.contains("sea")) {
            if (path.contains("nugget")) return 800L / 9L;
            if (path.contains("block")) return 7200L;
            return 800L; // 至少 1 鐵錠價值，堵住鐵粒堆升級出高階鐵器
        }
        if (path.contains("copper")) {
            return 200L;
        }
        if (path.contains("emerald")) {
            return 6000L;
        }

        // 最常見地形方塊（泥土、石頭、鵝卵石、砂、礫石、深板岩、地獄石、樹葉、木棒等）：0.1 金幣
        if (path.contains("dirt") || path.contains("cobblestone") || path.equals("stone")
                || path.contains("deepslate") || path.contains("sand") || path.contains("gravel")
                || path.contains("netherrack") || path.contains("basalt") || path.contains("blackstone")
                || path.contains("granite") || path.contains("diorite") || path.contains("andesite")
                || path.contains("tuff") || path.contains("calcite") || path.contains("dripstone")
                || path.contains("leaves") || path.contains("sapling") || path.contains("grass")
                || path.contains("snow") || path.equals("stick") || path.contains("seed")
                || path.contains("flower") || path.contains("fern") || path.contains("kelp")
                || path.contains("moss") || path.contains("mud") || path.contains("clay_ball")) {
            return 10L; // 0.1 金幣
        }

        // 木材、木板、羊毛、玻璃、普通磚、陶土：0.2 ~ 0.5 金幣
        // 注意：不再用 path.contains("door"/"trapdoor"/"brick") 一刀切，避免鐵門/鐵磚被低估
        if (path.contains("planks") || path.contains("slab") || path.contains("stairs")
                || path.contains("fence") || path.contains("button") || path.contains("pressure_plate")
                || path.contains("carpet") || path.contains("pane") || path.contains("torch")) {
            return 20L; // 0.2 金幣
        }
        if (path.contains("log") || path.contains("wood") || path.contains("stem")
                || path.contains("wool") || path.contains("glass")
                || path.contains("terracotta") || path.contains("concrete")
                || path.contains("chest") || path.contains("barrel")
                || path.contains("brick") || path.contains("door") || path.contains("trapdoor")) {
            return 50L; // 0.5 金幣（木門等）
        }

        // 原版礦石本體（絲綢之觸挖下來的礦石方塊）：對應礦物等值
        if (path.endsWith("_ore")) {
            if (path.contains("diamond")) return 16000L;
            if (path.contains("emerald")) return 6000L;
            if (path.contains("gold")) return 1600L;
            if (path.contains("iron")) return 800L;
            if (path.contains("lapis")) return 300L;
            if (path.contains("redstone")) return 200L;
            if (path.contains("copper")) return 200L;
            if (path.contains("coal")) return 100L;
            if (path.contains("quartz")) return 400L;
        }

        // 依原版稀有度決定合理保底價值（金幣）
        ItemStack defaultStack = item.getDefaultInstance();
        Rarity rarity = defaultStack.getOrDefault(DataComponents.RARITY, Rarity.COMMON);
        return switch (rarity) {
            case COMMON -> 30L;       // 0.3 金幣
            case UNCOMMON -> 1200L;   // 12 金幣
            case RARE -> 15000L;      // 150 金幣
            case EPIC -> 150000L;     // 1,500 金幣
        };
    }

    public static double getCoinsDouble(Item item) {
        return getCents(item) / 100.0;
    }

    public static boolean isBulkSellable(Item item) {
        return BULK_SELLABLE.contains(item);
    }

    public static Map<Item, Long> getExplicitCents() {
        return Collections.unmodifiableMap(EXPLICIT_CENTS);
    }

    public static void setExternalCents(Item item, long cents) {
        if (item != null && cents > 0) {
            EXPLICIT_CENTS.putIfAbsent(item, cents);
        }
    }

    public static String formatCents(long cents) {
        return FMT_DEC.format(cents / 100.0);
    }

    public static void load(MinecraftServer server) {
        BALANCES_CENTS.clear();
        saveFile = server.getWorldPath(LevelResource.ROOT).resolve("data").resolve("randomoredrop_coins_v3.json");
        if (Files.exists(saveFile)) {
            try {
                String json = Files.readString(saveFile);
                Map<String, Long> loaded = GSON.fromJson(json, MAP_TYPE);
                if (loaded != null) {
                    loaded.forEach((k, v) -> {
                        try {
                            BALANCES_CENTS.put(UUID.fromString(k), Math.max(0L, v));
                        } catch (IllegalArgumentException ignored) {
                        }
                    });
                }
            } catch (IOException ignored) {
            }
        }
    }

    public static void save() {
        if (saveFile == null) {
            return;
        }
        try {
            Files.createDirectories(saveFile.getParent());
            Map<String, Long> out = new LinkedHashMap<>();
            BALANCES_CENTS.forEach((k, v) -> out.put(k.toString(), v));
            Files.writeString(saveFile, GSON.toJson(out));
        } catch (IOException ignored) {
        }
    }

    public static long getBalanceCents(UUID playerId) {
        return BALANCES_CENTS.getOrDefault(playerId, 0L);
    }

    public static long addCents(UUID playerId, long cents) {
        long next = Math.max(0L, getBalanceCents(playerId) + cents);
        BALANCES_CENTS.put(playerId, next);
        save();
        return next;
    }

    public static boolean spendCents(UUID playerId, long cents) {
        long current = getBalanceCents(playerId);
        if (current < cents) {
            return false;
        }
        BALANCES_CENTS.put(playerId, current - cents);
        save();
        return true;
    }
}
