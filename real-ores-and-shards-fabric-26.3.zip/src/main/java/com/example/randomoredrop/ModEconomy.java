package com.example.randomoredrop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class ModEconomy {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, Long>>() {}.getType();

    private static final Map<Item, Long> ITEM_VALUES = new LinkedHashMap<>();
    private static final Set<Item> BULK_SELLABLE = new HashSet<>();
    private static final Map<UUID, Long> BALANCES = new HashMap<>();
    private static Path saveFile;

    public static void initialize() {
        // 平衡後階梯價值曲線：常見礦物大幅拉低、稀有/史詩礦物大幅拉高（同步壓低 Upgrader 跨級賭博機率）
        registerBulk(ModItems.COAL_SHARD, 1);
        registerBulk(Items.COAL, 4);
        registerBulk(ModItems.COPPER_SHARD, 2);
        registerBulk(Items.RAW_COPPER, 8);
        registerBulk(Items.COPPER_INGOT, 10);

        registerBulk(ModItems.REDSTONE_SHARD, 3);
        registerBulk(Items.REDSTONE, 12);
        registerBulk(ModItems.LAPIS_SHARD, 4);
        registerBulk(Items.LAPIS_LAZULI, 16);
        registerBulk(ModItems.QUARTZ_SHARD, 4);
        registerBulk(Items.QUARTZ, 16);

        registerBulk(ModItems.IRON_SHARD, 5);
        registerBulk(Items.RAW_IRON, 20);
        registerBulk(Items.IRON_INGOT, 28);

        registerBulk(ModItems.GOLD_SHARD, 10);
        registerBulk(Items.RAW_GOLD, 40);
        registerBulk(Items.GOLD_INGOT, 55);

        registerBulk(ModItems.EMERALD_SHARD, 60);
        registerBulk(Items.EMERALD, 240);
        registerBulk(ModItems.DIAMOND_SHARD, 120);
        registerBulk(Items.DIAMOND, 480);

        registerBulk(Items.ANCIENT_DEBRIS, 1500);
        registerBulk(Items.NETHERITE_SCRAP, 1800);
        registerBulk(Items.NETHERITE_INGOT, 8000);

        // 錫（Tin — Common 早期金屬，低價值）
        registerBulk(ModBlocks.TIN_ORE.asItem(), 10);
        registerBulk(ModBlocks.DEEPSLATE_TIN_ORE.asItem(), 12);
        registerBulk(ModItems.TIN_SHARD, 2);
        registerBulk(ModItems.RAW_TIN, 8);
        registerBulk(ModItems.TIN_INGOT, 12);
        registerGearSet(12,
                ModItems.TIN_SWORD, ModItems.TIN_PICKAXE, ModItems.TIN_AXE, ModItems.TIN_SHOVEL, ModItems.TIN_HOE,
                ModItems.TIN_HELMET, ModItems.TIN_CHESTPLATE, ModItems.TIN_LEGGINGS, ModItems.TIN_BOOTS);

        // 銀（Silver — Uncommon 中期高附魔金屬）
        registerBulk(ModBlocks.SILVER_ORE.asItem(), 55);
        registerBulk(ModBlocks.DEEPSLATE_SILVER_ORE.asItem(), 60);
        registerBulk(ModItems.SILVER_SHARD, 12);
        registerBulk(ModItems.RAW_SILVER, 48);
        registerBulk(ModItems.SILVER_INGOT, 65);
        registerGearSet(65,
                ModItems.SILVER_SWORD, ModItems.SILVER_PICKAXE, ModItems.SILVER_AXE, ModItems.SILVER_SHOVEL, ModItems.SILVER_HOE,
                ModItems.SILVER_HELMET, ModItems.SILVER_CHESTPLATE, ModItems.SILVER_LEGGINGS, ModItems.SILVER_BOOTS);

        // 鈦（Titanium — Rare 後期高耐久金屬，大幅拉高）
        registerBulk(ModBlocks.TITANIUM_ORE.asItem(), 1100);
        registerBulk(ModBlocks.DEEPSLATE_TITANIUM_ORE.asItem(), 1200);
        registerBulk(ModItems.TITANIUM_SHARD, 250);
        registerBulk(ModItems.RAW_TITANIUM, 1000);
        registerBulk(ModItems.TITANIUM_INGOT, 1300);
        registerGearSet(1300,
                ModItems.TITANIUM_SWORD, ModItems.TITANIUM_PICKAXE, ModItems.TITANIUM_AXE, ModItems.TITANIUM_SHOVEL, ModItems.TITANIUM_HOE,
                ModItems.TITANIUM_HELMET, ModItems.TITANIUM_CHESTPLATE, ModItems.TITANIUM_LEGGINGS, ModItems.TITANIUM_BOOTS);

        // 鎢（Tungsten — Epic 終局防火重裝金屬，極高價值）
        registerBulk(ModBlocks.TUNGSTEN_ORE.asItem(), 2600);
        registerBulk(ModBlocks.DEEPSLATE_TUNGSTEN_ORE.asItem(), 2800);
        registerBulk(ModItems.TUNGSTEN_SHARD, 600);
        registerBulk(ModItems.RAW_TUNGSTEN, 2400);
        registerBulk(ModItems.TUNGSTEN_INGOT, 3200);
        registerGearSet(3200,
                ModItems.TUNGSTEN_SWORD, ModItems.TUNGSTEN_PICKAXE, ModItems.TUNGSTEN_AXE, ModItems.TUNGSTEN_SHOVEL, ModItems.TUNGSTEN_HOE,
                ModItems.TUNGSTEN_HELMET, ModItems.TUNGSTEN_CHESTPLATE, ModItems.TUNGSTEN_LEGGINGS, ModItems.TUNGSTEN_BOOTS);
    }

    private static void registerBulk(Item item, long value) {
        ITEM_VALUES.put(item, value);
        BULK_SELLABLE.add(item);
    }

    private static void registerGearSet(long ingotVal, Item sword, Item pick, Item axe, Item shovel, Item hoe,
                                        Item helmet, Item chest, Item legs, Item boots) {
        // 裝備價值 = 消耗金屬錠總值 + 10% 鍛造加成
        ITEM_VALUES.put(sword, Math.round(ingotVal * 2 * 1.1));
        ITEM_VALUES.put(pick, Math.round(ingotVal * 3 * 1.1));
        ITEM_VALUES.put(axe, Math.round(ingotVal * 3 * 1.1));
        ITEM_VALUES.put(shovel, Math.round(ingotVal * 1 * 1.15));
        ITEM_VALUES.put(hoe, Math.round(ingotVal * 2 * 1.1));
        ITEM_VALUES.put(helmet, Math.round(ingotVal * 5 * 1.1));
        ITEM_VALUES.put(chest, Math.round(ingotVal * 8 * 1.1));
        ITEM_VALUES.put(legs, Math.round(ingotVal * 7 * 1.1));
        ITEM_VALUES.put(boots, Math.round(ingotVal * 4 * 1.1));
    }

    public static long getValue(Item item) {
        return ITEM_VALUES.getOrDefault(item, 0L);
    }

    public static Map<Item, Long> getAllValues() {
        return Collections.unmodifiableMap(ITEM_VALUES);
    }

    public static void setExternalValue(Item item, long value) {
        if (item != null && value > 0) {
            ITEM_VALUES.putIfAbsent(item, value);
        }
    }

    public static boolean isBulkSellable(Item item) {
        return BULK_SELLABLE.contains(item);
    }

    public static void load(MinecraftServer server) {
        BALANCES.clear();
        saveFile = server.getWorldPath(LevelResource.ROOT).resolve("data").resolve("randomoredrop_coins.json");
        if (Files.exists(saveFile)) {
            try {
                String json = Files.readString(saveFile);
                Map<String, Long> loaded = GSON.fromJson(json, MAP_TYPE);
                if (loaded != null) {
                    loaded.forEach((k, v) -> {
                        try {
                            BALANCES.put(UUID.fromString(k), Math.max(0L, v));
                        } catch (IllegalArgumentException ignored) {
                        }
                    });
                }
            } catch (IOException ignored) {
            }
        }
    }

    public static void save() {
        if (saveFile == null) {
            return;
        }
        try {
            Files.createDirectories(saveFile.getParent());
            Map<String, Long> out = new LinkedHashMap<>();
            BALANCES.forEach((k, v) -> out.put(k.toString(), v));
            Files.writeString(saveFile, GSON.toJson(out));
        } catch (IOException ignored) {
        }
    }

    public static long getBalance(UUID playerId) {
        return BALANCES.getOrDefault(playerId, 0L);
    }

    public static long addCoins(UUID playerId, long amount) {
        long next = Math.max(0L, getBalance(playerId) + amount);
        BALANCES.put(playerId, next);
        save();
        return next;
    }

    public static boolean spendCoins(UUID playerId, long amount) {
        long current = getBalance(playerId);
        if (current < amount) {
            return false;
        }
        BALANCES.put(playerId, current - amount);
        save();
        return true;
    }
}
