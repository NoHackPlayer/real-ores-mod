package com.example.randomoredrop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class ModEconomy {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, Long>>() {}.getType();

    private static final Map<Item, Long> ITEM_VALUES = new LinkedHashMap<>();
    private static final Set<Item> BULK_SELLABLE = new HashSet<>();
    private static final Map<UUID, Long> BALANCES = new HashMap<>();
    private static Path saveFile;

    public static void initialize() {
        // 原版礦物與碎片（4 碎片 = 1 粗礦/寶石；燒製錠再增值 25%）
        registerBulk(ModItems.COAL_SHARD, 5);
        registerBulk(Items.COAL, 20);
        registerBulk(ModItems.COPPER_SHARD, 8);
        registerBulk(Items.RAW_COPPER, 32);
        registerBulk(Items.COPPER_INGOT, 40);

        registerBulk(ModItems.IRON_SHARD, 15);
        registerBulk(Items.RAW_IRON, 60);
        registerBulk(Items.IRON_INGOT, 75);

        registerBulk(ModItems.REDSTONE_SHARD, 12);
        registerBulk(Items.REDSTONE, 48);
        registerBulk(ModItems.LAPIS_SHARD, 15);
        registerBulk(Items.LAPIS_LAZULI, 60);
        registerBulk(ModItems.QUARTZ_SHARD, 18);
        registerBulk(Items.QUARTZ, 72);

        registerBulk(ModItems.GOLD_SHARD, 30);
        registerBulk(Items.RAW_GOLD, 120);
        registerBulk(Items.GOLD_INGOT, 150);

        registerBulk(ModItems.DIAMOND_SHARD, 100);
        registerBulk(Items.DIAMOND, 400);
        registerBulk(ModItems.EMERALD_SHARD, 80);
        registerBulk(Items.EMERALD, 320);

        registerBulk(Items.ANCIENT_DEBRIS, 600);
        registerBulk(Items.NETHERITE_SCRAP, 700);
        registerBulk(Items.NETHERITE_INGOT, 3200);

        // 錫（Tin — Common 早期金屬）
        registerBulk(ModBlocks.TIN_ORE.asItem(), 45);
        registerBulk(ModBlocks.DEEPSLATE_TIN_ORE.asItem(), 50);
        registerBulk(ModItems.TIN_SHARD, 10);
        registerBulk(ModItems.RAW_TIN, 40);
        registerBulk(ModItems.TIN_INGOT, 50);
        registerGearSet(50,
                ModItems.TIN_SWORD, ModItems.TIN_PICKAXE, ModItems.TIN_AXE, ModItems.TIN_SHOVEL, ModItems.TIN_HOE,
                ModItems.TIN_HELMET, ModItems.TIN_CHESTPLATE, ModItems.TIN_LEGGINGS, ModItems.TIN_BOOTS);

        // 銀（Silver — Uncommon 中期高附魔金屬）
        registerBulk(ModBlocks.SILVER_ORE.asItem(), 110);
        registerBulk(ModBlocks.DEEPSLATE_SILVER_ORE.asItem(), 120);
        registerBulk(ModItems.SILVER_SHARD, 25);
        registerBulk(ModItems.RAW_SILVER, 100);
        registerBulk(ModItems.SILVER_INGOT, 125);
        registerGearSet(125,
                ModItems.SILVER_SWORD, ModItems.SILVER_PICKAXE, ModItems.SILVER_AXE, ModItems.SILVER_SHOVEL, ModItems.SILVER_HOE,
                ModItems.SILVER_HELMET, ModItems.SILVER_CHESTPLATE, ModItems.SILVER_LEGGINGS, ModItems.SILVER_BOOTS);

        // 鈦（Titanium — Rare 後期高耐久金屬）
        registerBulk(ModBlocks.TITANIUM_ORE.asItem(), 650);
        registerBulk(ModBlocks.DEEPSLATE_TITANIUM_ORE.asItem(), 700);
        registerBulk(ModItems.TITANIUM_SHARD, 150);
        registerBulk(ModItems.RAW_TITANIUM, 600);
        registerBulk(ModItems.TITANIUM_INGOT, 750);
        registerGearSet(750,
                ModItems.TITANIUM_SWORD, ModItems.TITANIUM_PICKAXE, ModItems.TITANIUM_AXE, ModItems.TITANIUM_SHOVEL, ModItems.TITANIUM_HOE,
                ModItems.TITANIUM_HELMET, ModItems.TITANIUM_CHESTPLATE, ModItems.TITANIUM_LEGGINGS, ModItems.TITANIUM_BOOTS);

        // 鎢（Tungsten — Epic 終局防火重裝金屬）
        registerBulk(ModBlocks.TUNGSTEN_ORE.asItem(), 1300);
        registerBulk(ModBlocks.DEEPSLATE_TUNGSTEN_ORE.asItem(), 1400);
        registerBulk(ModItems.TUNGSTEN_SHARD, 300);
        registerBulk(ModItems.RAW_TUNGSTEN, 1200);
        registerBulk(ModItems.TUNGSTEN_INGOT, 1500);
        registerGearSet(1500,
                ModItems.TUNGSTEN_SWORD, ModItems.TUNGSTEN_PICKAXE, ModItems.TUNGSTEN_AXE, ModItems.TUNGSTEN_SHOVEL, ModItems.TUNGSTEN_HOE,
                ModItems.TUNGSTEN_HELMET, ModItems.TUNGSTEN_CHESTPLATE, ModItems.TUNGSTEN_LEGGINGS, ModItems.TUNGSTEN_BOOTS);
    }

    private static void registerBulk(Item item, long value) {
        ITEM_VALUES.put(item, value);
        BULK_SELLABLE.add(item);
    }

    private static void registerGearSet(long ingotVal, Item sword, Item pick, Item axe, Item shovel, Item hoe,
                                        Item helmet, Item chest, Item legs, Item boots) {
        // 裝備價值 = 消耗金屬錠總值 + 10% 鍛造加成
        ITEM_VALUES.put(sword, Math.round(ingotVal * 2 * 1.1));
        ITEM_VALUES.put(pick, Math.round(ingotVal * 3 * 1.1));
        ITEM_VALUES.put(axe, Math.round(ingotVal * 3 * 1.1));
        ITEM_VALUES.put(shovel, Math.round(ingotVal * 1 * 1.15));
        ITEM_VALUES.put(hoe, Math.round(ingotVal * 2 * 1.1));
        ITEM_VALUES.put(helmet, Math.round(ingotVal * 5 * 1.1));
        ITEM_VALUES.put(chest, Math.round(ingotVal * 8 * 1.1));
        ITEM_VALUES.put(legs, Math.round(ingotVal * 7 * 1.1));
        ITEM_VALUES.put(boots, Math.round(ingotVal * 4 * 1.1));
    }

    public static long getValue(Item item) {
        return ITEM_VALUES.getOrDefault(item, 0L);
    }

    public static Map<Item, Long> getAllValues() {
        return Collections.unmodifiableMap(ITEM_VALUES);
    }

    public static void setExternalValue(Item item, long value) {
        if (item != null && value > 0) {
            ITEM_VALUES.putIfAbsent(item, value);
        }
    }

    public static boolean isBulkSellable(Item item) {
        return BULK_SELLABLE.contains(item);
    }

    public static void load(MinecraftServer server) {
        BALANCES.clear();
        saveFile = server.getWorldPath(LevelResource.ROOT).resolve("data").resolve("randomoredrop_coins.json");
        if (Files.exists(saveFile)) {
            try {
                String json = Files.readString(saveFile);
                Map<String, Long> loaded = GSON.fromJson(json, MAP_TYPE);
                if (loaded != null) {
                    loaded.forEach((k, v) -> {
                        try {
                            BALANCES.put(UUID.fromString(k), Math.max(0L, v));
                        } catch (IllegalArgumentException ignored) {
                        }
                    });
                }
            } catch (IOException ignored) {
            }
        }
    }

    public static void save() {
        if (saveFile == null) {
            return;
        }
        try {
            Files.createDirectories(saveFile.getParent());
            Map<String, Long> out = new LinkedHashMap<>();
            BALANCES.forEach((k, v) -> out.put(k.toString(), v));
            Files.writeString(saveFile, GSON.toJson(out));
        } catch (IOException ignored) {
        }
    }

    public static long getBalance(UUID playerId) {
        return BALANCES.getOrDefault(playerId, 0L);
    }

    public static long addCoins(UUID playerId, long amount) {
        long next = Math.max(0L, getBalance(playerId) + amount);
        BALANCES.put(playerId, next);
        save();
        return next;
    }

    public static boolean spendCoins(UUID playerId, long amount) {
        long current = getBalance(playerId);
        if (current < amount) {
            return false;
        }
        BALANCES.put(playerId, current - amount);
        save();
        return true;
    }
}
