package com.example.randomoredrop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DecimalFormat;
import java.util.*;

public class ModEconomy {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, Long>>() {}.getType();
    private static final DecimalFormat FMT_DEC = new DecimalFormat("#,##0.##");

    // 全部以「分（cents）」儲存：100 cents = 1.00 金幣，10 cents = 0.1 金幣，25 cents = 0.25 金幣（完全無浮點誤差）
    private static final Map<Item, Long> EXPLICIT_CENTS = new LinkedHashMap<>();
    private static final Set<Item> BULK_SELLABLE = new HashSet<>();
    private static final Map<UUID, Long> BALANCES_CENTS = new HashMap<>();
    private static Path saveFile;

    public static void initialize() {
        // 實體金幣等值面額（不可透過 /sell all 賣，應使用右鍵或 /deposit 存入）
        EXPLICIT_CENTS.put(ModItems.COMPUTER, 5000L); // 50 金幣
        EXPLICIT_CENTS.put(ModItems.COIN_1, 100L);
        EXPLICIT_CENTS.put(ModItems.COIN_10, 1000L);
        EXPLICIT_CENTS.put(ModItems.COIN_100, 10000L);
        EXPLICIT_CENTS.put(ModItems.COIN_1000, 100000L);
        EXPLICIT_CENTS.put(ModItems.COIN_10000, 1000000L);

        // === 嚴格材料加總計價（4 碎片 = 1 礦，9 礦 = 1 礦磚，工具/盔甲 = 消耗金屬錠總值，絕無刷錢漏洞）===
        // 煤炭：碎片 0.25 | 煤炭 1 | 煤磚 9
        registerMineralFamily(ModItems.COAL_SHARD, Items.COAL, Items.COAL, Items.COAL_BLOCK, 100L);
        EXPLICIT_CENTS.put(Items.CHARCOAL, 100L);

        // 銅：碎片 0.5 | 粗銅/銅錠 2 | 銅磚 18
        registerMineralFamily(ModItems.COPPER_SHARD, Items.RAW_COPPER, Items.COPPER_INGOT, null, 200L);
        EXPLICIT_CENTS.put(Items.RAW_COPPER_BLOCK, 1800L);
        BuiltInRegistries.ITEM.getOptional(Identifier.withDefaultNamespace("copper_block")).ifPresent(i -> EXPLICIT_CENTS.put(i, 1800L));

        // 紅石：碎片 0.5 | 紅石 2 | 紅石磚 18
        registerMineralFamily(ModItems.REDSTONE_SHARD, Items.REDSTONE, Items.REDSTONE, Items.REDSTONE_BLOCK, 200L);

        // 青金石：碎片 0.75 | 青金石 3 | 青金石磚 27
        registerMineralFamily(ModItems.LAPIS_SHARD, Items.LAPIS_LAZULI, Items.LAPIS_LAZULI, Items.LAPIS_BLOCK, 300L);

        // 地獄石英：碎片 1 | 石英 4 | 石英塊(4石英) 16
        registerBulk(ModItems.QUARTZ_SHARD, 100L);
        registerBulk(Items.QUARTZ, 400L);
        EXPLICIT_CENTS.put(Items.QUARTZ_BLOCK, 1600L);

        // 鐵：碎片 2 | 粗鐵/鐵錠 8 | 鐵磚 72 | 鐵粒(1/9) 0.89
        registerMineralFamily(ModItems.IRON_SHARD, Items.RAW_IRON, Items.IRON_INGOT, Items.IRON_BLOCK, 800L);
        EXPLICIT_CENTS.put(Items.RAW_IRON_BLOCK, 7200L);
        EXPLICIT_CENTS.put(Items.IRON_NUGGET, 89L);
        registerExactGearSet(800L,
                Items.IRON_SWORD, Items.IRON_PICKAXE, Items.IRON_AXE, Items.IRON_SHOVEL, Items.IRON_HOE,
                Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS);

        // 金：碎片 4 | 粗金/金錠 16 | 金磚 144 | 金粒 1.78
        registerMineralFamily(ModItems.GOLD_SHARD, Items.RAW_GOLD, Items.GOLD_INGOT, Items.GOLD_BLOCK, 1600L);
        EXPLICIT_CENTS.put(Items.RAW_GOLD_BLOCK, 14400L);
        EXPLICIT_CENTS.put(Items.GOLD_NUGGET, 178L);
        registerExactGearSet(1600L,
                Items.GOLDEN_SWORD, Items.GOLDEN_PICKAXE, Items.GOLDEN_AXE, Items.GOLDEN_SHOVEL, Items.GOLDEN_HOE,
                Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS);

        // 綠寶石：碎片 15 | 綠寶石 60 | 綠寶石磚 540
        registerMineralFamily(ModItems.EMERALD_SHARD, Items.EMERALD, Items.EMERALD, Items.EMERALD_BLOCK, 6000L);

        // 鑽石：碎片 40 | 鑽石 160 | 鑽石磚 1,440
        registerMineralFamily(ModItems.DIAMOND_SHARD, Items.DIAMOND, Items.DIAMOND, Items.DIAMOND_BLOCK, 16000L);
        registerExactGearSet(16000L,
                Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE,
                Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);

        // 獄髓：遠古遺骸/碎片 800 | 獄髓錠(4碎片+4金錠) 3,264 | 獄髓磚(9錠) 29,376
        registerBulk(Items.ANCIENT_DEBRIS, 80000L);
        registerBulk(Items.NETHERITE_SCRAP, 80000L);
        registerBulk(Items.NETHERITE_INGOT, 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_BLOCK, 326400L * 9L);
        // 獄髓裝備 = 對應鑽石裝備 + 1 獄髓錠
        EXPLICIT_CENTS.put(Items.NETHERITE_SWORD, 32000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_PICKAXE, 48000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_AXE, 48000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_SHOVEL, 16000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_HOE, 32000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_HELMET, 80000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_CHESTPLATE, 128000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_LEGGINGS, 112000L + 326400L);
        EXPLICIT_CENTS.put(Items.NETHERITE_BOOTS, 64000L + 326400L);

        // === 4 款現實世界金屬（嚴格材料加總）===
        // 錫：碎片 0.75 | 粗錫/錫錠 3 | 裝備 = 消耗錠數 × 3
        registerBulk(ModBlocks.TIN_ORE.asItem(), 300L);
        registerBulk(ModBlocks.DEEPSLATE_TIN_ORE.asItem(), 300L);
        registerMineralFamily(ModItems.TIN_SHARD, ModItems.RAW_TIN, ModItems.TIN_INGOT, null, 300L);
        registerExactGearSet(300L,
                ModItems.TIN_SWORD, ModItems.TIN_PICKAXE, ModItems.TIN_AXE, ModItems.TIN_SHOVEL, ModItems.TIN_HOE,
                ModItems.TIN_HELMET, ModItems.TIN_CHESTPLATE, ModItems.TIN_LEGGINGS, ModItems.TIN_BOOTS);

        // 銀：碎片 5 | 粗銀/銀錠 20 | 裝備 = 消耗錠數 × 20
        registerBulk(ModBlocks.SILVER_ORE.asItem(), 2000L);
        registerBulk(ModBlocks.DEEPSLATE_SILVER_ORE.asItem(), 2000L);
        registerMineralFamily(ModItems.SILVER_SHARD, ModItems.RAW_SILVER, ModItems.SILVER_INGOT, null, 2000L);
        registerExactGearSet(2000L,
                ModItems.SILVER_SWORD, ModItems.SILVER_PICKAXE, ModItems.SILVER_AXE, ModItems.SILVER_SHOVEL, ModItems.SILVER_HOE,
                ModItems.SILVER_HELMET, ModItems.SILVER_CHESTPLATE, ModItems.SILVER_LEGGINGS, ModItems.SILVER_BOOTS);

        // 鈦：碎片 150 | 粗鈦/鈦錠 600 | 裝備 = 消耗錠數 × 600
        registerBulk(ModBlocks.TITANIUM_ORE.asItem(), 60000L);
        registerBulk(ModBlocks.DEEPSLATE_TITANIUM_ORE.asItem(), 60000L);
        registerMineralFamily(ModItems.TITANIUM_SHARD, ModItems.RAW_TITANIUM, ModItems.TITANIUM_INGOT, null, 60000L);
        registerExactGearSet(60000L,
                ModItems.TITANIUM_SWORD, ModItems.TITANIUM_PICKAXE, ModItems.TITANIUM_AXE, ModItems.TITANIUM_SHOVEL, ModItems.TITANIUM_HOE,
                ModItems.TITANIUM_HELMET, ModItems.TITANIUM_CHESTPLATE, ModItems.TITANIUM_LEGGINGS, ModItems.TITANIUM_BOOTS);

        // 鎢：碎片 400 | 粗鎢/鎢錠 1,600 | 裝備 = 消耗錠數 × 1,600
        registerBulk(ModBlocks.TUNGSTEN_ORE.asItem(), 160000L);
        registerBulk(ModBlocks.DEEPSLATE_TUNGSTEN_ORE.asItem(), 160000L);
        registerMineralFamily(ModItems.TUNGSTEN_SHARD, ModItems.RAW_TUNGSTEN, ModItems.TUNGSTEN_INGOT, null, 160000L);
        registerExactGearSet(160000L,
                ModItems.TUNGSTEN_SWORD, ModItems.TUNGSTEN_PICKAXE, ModItems.TUNGSTEN_AXE, ModItems.TUNGSTEN_SHOVEL, ModItems.TUNGSTEN_HOE,
                ModItems.TUNGSTEN_HELMET, ModItems.TUNGSTEN_CHESTPLATE, ModItems.TUNGSTEN_LEGGINGS, ModItems.TUNGSTEN_BOOTS);


        // === 原版稀有物品與常用方塊精準標價 ===
        EXPLICIT_CENTS.put(Items.ANVIL, 24800L);                 // 3 鐵磚 + 4 鐵錠 = 31 鐵錠 = 248
        EXPLICIT_CENTS.put(Items.OBSIDIAN, 800L);                // 8
        EXPLICIT_CENTS.put(Items.ENDER_PEARL, 1500L);            // 15
        EXPLICIT_CENTS.put(Items.BLAZE_ROD, 2400L);              // 24
        EXPLICIT_CENTS.put(Items.BLAZE_POWDER, 1200L);           // 12
        EXPLICIT_CENTS.put(Items.ENDER_EYE, 2700L);              // 15 + 12 = 27
        EXPLICIT_CENTS.put(Items.GHAST_TEAR, 6000L);             // 60
        EXPLICIT_CENTS.put(Items.SHULKER_SHELL, 18000L);         // 180
        EXPLICIT_CENTS.put(Items.TOTEM_OF_UNDYING, 65000L);      // 650
        EXPLICIT_CENTS.put(Items.ELYTRA, 280000L);               // 2,800
        EXPLICIT_CENTS.put(Items.ENCHANTED_GOLDEN_APPLE, 350000L); // 3,500
        EXPLICIT_CENTS.put(Items.GOLDEN_APPLE, 25000L);          // 250
        EXPLICIT_CENTS.put(Items.NETHER_STAR, 600000L);          // 6,000
        EXPLICIT_CENTS.put(Items.BEACON, 602400L);               // 6,000 + 3 黑曜石(24)
    }

    private static void registerMineralFamily(Item shard, Item raw, Item ingot, Item block, long unitCents) {
        registerBulk(shard, unitCents / 4L);
        registerBulk(raw, unitCents);
        registerBulk(ingot, unitCents);
        if (block != null) {
            EXPLICIT_CENTS.put(block, unitCents * 9L);
        }
    }

    private static void registerBulk(Item item, long cents) {
        EXPLICIT_CENTS.put(item, cents);
        BULK_SELLABLE.add(item);
    }

    private static void registerExactGearSet(long ingotCents, Item sword, Item pick, Item axe, Item shovel, Item hoe,
                                             Item helmet, Item chest, Item legs, Item boots) {
        EXPLICIT_CENTS.put(sword, ingotCents * 2L);
        EXPLICIT_CENTS.put(pick, ingotCents * 3L);
        EXPLICIT_CENTS.put(axe, ingotCents * 3L);
        EXPLICIT_CENTS.put(shovel, ingotCents);
        EXPLICIT_CENTS.put(hoe, ingotCents * 2L);
        EXPLICIT_CENTS.put(helmet, ingotCents * 5L);
        EXPLICIT_CENTS.put(chest, ingotCents * 8L);
        EXPLICIT_CENTS.put(legs, ingotCents * 7L);
        EXPLICIT_CENTS.put(boots, ingotCents * 4L);
    }

    /**
     * 遊戲內「所有物品」都有對應的精準金幣價值（以分 cents 計，100 = 1.00 金幣）
     */
    private static final Set<String> FORBIDDEN_PATHS = Set.of(
            "barrier", "bedrock", "end_portal_frame", "dragon_egg",
            "command_block", "chain_command_block", "repeating_command_block", "command_block_minecart",
            "structure_block", "structure_void", "jigsaw", "light", "debug_stick", "knowledge_book",
            "test_block", "test_instance_block", "spawner", "trial_spawner", "vault",
            "reinforced_deepslate", "budding_amethyst", "petrified_oak_slab",
            "farmland", "dirt_path", "frogspawn", "chorus_plant", "player_head", "upgrader"
    );

    /**
     * 生存模式無法正常取得、管理員專用或全世界極度唯一（如龍蛋、基岩、屏障、終界傳送門框）的物品
     */
    public static boolean isForbiddenOrUnobtainable(Item item) {
        if (item == null || item == Items.AIR) {
            return true;
        }
        String path = BuiltInRegistries.ITEM.getKey(item).getPath();
        return FORBIDDEN_PATHS.contains(path)
                || path.endsWith("_spawn_egg")
                || path.startsWith("infested_")
                || path.contains("command_block")
                || path.contains("structure_")
                || path.contains("end_portal");
    }

    /**
     * 判斷是否為任何奇物（含 Artifacts 模組全系列與本模組 6 款奇物）；奇物禁止透過開箱或 Upgrader 取得
     */
    public static boolean isArtifactItem(Item item) {
        if (item == null || item == Items.AIR) {
            return false;
        }
        return "artifacts".equals(BuiltInRegistries.ITEM.getKey(item).getNamespace());
    }

    /**
     * 依 Artifacts 模組每款奇物的正面實戰強度分級定價（以 cents 計，100 = 1 金幣）
     */
    private static long getExternalArtifactCents(String path) {
        return switch (path) {
            // Tier S：質變級生存／戰鬥／經濟神器（10,000 – 15,000 金幣）
            case "everlasting_beef", "eternal_steak" -> 1500000L;                // 15,000（無限食物）
            case "crystal_heart", "vampiric_glove", "chorus_totem" -> 1200000L;  // 12,000（加血／吸血／免死傳送）
            case "helium_flamingo" -> 1100000L;                                  // 11,000（空中游泳滑翔）
            case "cloud_in_a_bottle", "antidote_vessel", "villager_hat", "lucky_scarf" -> 1000000L; // 10,000

            // Tier A：強力戰鬥／機動／採礦奇物（7,500 – 9,000 金幣）
            case "power_glove" -> 900000L;                                       // 9,000
            case "feral_claws", "digging_claws", "night_vision_goggles" -> 850000L; // 8,500
            case "obsidian_skull", "running_shoes", "bunny_hoppers", "scarf_of_invisibility" -> 800000L; // 8,000
            case "universal_attractor", "cross_necklace", "fire_gauntlet",
                    "withered_bracelet", "pickaxe_heater", "warp_drive" -> 750000L; // 7,500

            // Tier B：中高階功能／水陸移動／反擊奇物（5,000 – 6,000 金幣）
            case "flame_pendant", "shock_pendant", "thorn_pendant",
                    "aqua_dashers", "strider_shoes", "kitty_slippers" -> 600000L; // 6,000
            case "charm_of_sinking", "snorkel", "flippers" -> 550000L;           // 5,500
            case "panic_necklace", "steadfast_spikes", "pocket_piston", "umbrella",
                    "onion_ring", "rooted_boots", "superstitious_hat", "witch_hat" -> 500000L; // 5,000

            // Tier C：輕度情境／輔助奇物（3,500 金幣）與純趣味道具（1,000 金幣）
            case "cowboy_hat", "golden_hook", "angler_hat", "snowshoes",
                    "charm_of_shrinking", "plastic_drinking_hat", "novelty_drinking_hat" -> 350000L; // 3,500
            case "whoopee_cushion" -> 100000L;                                   // 1,000
            default -> 450000L;                                                  // 其他奇物保底 4,500
        };
    }

    public static long getCents(Item item) {
        if (isForbiddenOrUnobtainable(item)) {
            return 0L;
        }
        Identifier key = BuiltInRegistries.ITEM.getKey(item);
        if ("artifacts".equals(key.getNamespace())) {
            return getExternalArtifactCents(key.getPath());
        }
        Long explicit = EXPLICIT_CENTS.get(item);
        if (explicit != null) {
            return explicit;
        }
        return computeFallbackCents(item);
    }

    private static long computeFallbackCents(Item item) {
        String path = BuiltInRegistries.ITEM.getKey(item).getPath();

        // 最常見地形方塊（泥土、石頭、鵝卵石、砂、礫石、深板岩、地獄石、樹葉、木棒等）：0.1 金幣
        if (path.contains("dirt") || path.contains("cobblestone") || path.equals("stone")
                || path.contains("deepslate") || path.contains("sand") || path.contains("gravel")
                || path.contains("netherrack") || path.contains("basalt") || path.contains("blackstone")
                || path.contains("granite") || path.contains("diorite") || path.contains("andesite")
                || path.contains("tuff") || path.contains("calcite") || path.contains("dripstone")
                || path.contains("leaves") || path.contains("sapling") || path.contains("grass")
                || path.contains("snow") || path.equals("stick") || path.contains("seed")
                || path.contains("flower") || path.contains("fern") || path.contains("kelp")
                || path.contains("moss") || path.contains("mud") || path.contains("clay_ball")) {
            return 10L; // 0.1 金幣
        }

        // 木材、木板、羊毛、玻璃、磚塊、陶土、食物、農作物：0.2 ~ 0.5 金幣
        if (path.contains("planks") || path.contains("slab") || path.contains("stairs")
                || path.contains("fence") || path.contains("button") || path.contains("pressure_plate")
                || path.contains("carpet") || path.contains("pane") || path.contains("torch")) {
            return 20L; // 0.2 金幣
        }
        if (path.contains("log") || path.contains("wood") || path.contains("stem")
                || path.contains("wool") || path.contains("glass") || path.contains("brick")
                || path.contains("terracotta") || path.contains("concrete") || path.contains("door")
                || path.contains("trapdoor") || path.contains("chest") || path.contains("barrel")) {
            return 50L; // 0.5 金幣
        }

        // 原版礦石本體（絲綢之觸挖下來的礦石方塊）：對應礦物等值
        if (path.endsWith("_ore")) {
            if (path.contains("diamond")) return 16000L;
            if (path.contains("emerald")) return 6000L;
            if (path.contains("gold")) return 1600L;
            if (path.contains("iron")) return 800L;
            if (path.contains("lapis")) return 300L;
            if (path.contains("redstone")) return 200L;
            if (path.contains("copper")) return 200L;
            if (path.contains("coal")) return 100L;
            if (path.contains("quartz")) return 400L;
        }

        // 依原版稀有度決定合理保底價值
        ItemStack defaultStack = item.getDefaultInstance();
        Rarity rarity = defaultStack.getOrDefault(DataComponents.RARITY, Rarity.COMMON);
        return switch (rarity) {
            case COMMON -> 30L;       // 0.3 金幣
            case UNCOMMON -> 1200L;   // 12 金幣
            case RARE -> 15000L;      // 150 金幣
            case EPIC -> 150000L;     // 1,500 金幣
        };
    }

    /**
     * CS:GO 磨損度價值倍率：嶄新出廠 1.45x / 輕微磨損 1.20x / 久經沙場 1.00x / 破損不堪 0.80x / 戰痕累累 0.65x
     * 讓低磨損的紫色（受限級）開箱裝備也能回本或小賺，高磨損則折價。
     */
    public static double getWearMultiplier(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isDamageableItem() || stack.getMaxDamage() <= 0) {
            return 1.0;
        }
        float wear = Math.min(1.0F, Math.max(0.0F, stack.getDamageValue() / (float) stack.getMaxDamage()));
        if (wear < 0.20F) return 1.45;
        if (wear < 0.40F) return 1.20;
        if (wear < 0.60F) return 1.00;
        if (wear < 0.80F) return 0.80;
        return 0.65;
    }

    public static long getUnitCents(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return 0L;
        }
        long base = getCents(stack.getItem());
        if (base <= 0L) {
            return 0L;
        }
        return Math.max(1L, Math.round(base * getWearMultiplier(stack)));
    }

    public static long getStackCents(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return 0L;
        }
        return getUnitCents(stack) * stack.getCount();
    }

    public static double getCoinsDouble(Item item) {
        return getCents(item) / 100.0;
    }

    public static boolean isBulkSellable(Item item) {
        return BULK_SELLABLE.contains(item);
    }

    public static Map<Item, Long> getExplicitCents() {
        return Collections.unmodifiableMap(EXPLICIT_CENTS);
    }

    public static void setExternalCents(Item item, long cents) {
        if (item != null && cents > 0) {
            EXPLICIT_CENTS.putIfAbsent(item, cents);
        }
    }

    public static String formatCents(long cents) {
        return FMT_DEC.format(cents / 100.0);
    }

    public static void load(MinecraftServer server) {
        BALANCES_CENTS.clear();
        saveFile = server.getWorldPath(LevelResource.ROOT).resolve("data").resolve("randomoredrop_coins_v3.json");
        if (Files.exists(saveFile)) {
            try {
                String json = Files.readString(saveFile);
                Map<String, Long> loaded = GSON.fromJson(json, MAP_TYPE);
                if (loaded != null) {
                    loaded.forEach((k, v) -> {
                        try {
                            BALANCES_CENTS.put(UUID.fromString(k), Math.max(0L, v));
                        } catch (IllegalArgumentException ignored) {
                        }
                    });
                }
            } catch (IOException ignored) {
            }
        }
    }

    public static void save() {
        if (saveFile == null) {
            return;
        }
        try {
            Files.createDirectories(saveFile.getParent());
            Map<String, Long> out = new LinkedHashMap<>();
            BALANCES_CENTS.forEach((k, v) -> out.put(k.toString(), v));
            Files.writeString(saveFile, GSON.toJson(out));
        } catch (IOException ignored) {
        }
    }

    public static long getBalanceCents(UUID playerId) {
        return BALANCES_CENTS.getOrDefault(playerId, 0L);
    }

    public static long addCents(UUID playerId, long cents) {
        long next = Math.max(0L, getBalanceCents(playerId) + cents);
        BALANCES_CENTS.put(playerId, next);
        save();
        return next;
    }

    public static boolean spendCents(UUID playerId, long cents) {
        long current = getBalanceCents(playerId);
        if (current < cents) {
            return false;
        }
        BALANCES_CENTS.put(playerId, current - cents);
        save();
        return true;
    }
}
