package com.example.randomoredrop;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.text.NumberFormat;
import java.util.Locale;

public class ModCommands {
    private static final long BASIC_CASE_PRICE = 150L;
    private static final long RARE_CASE_PRICE = 1200L;
    private static final long EPIC_CASE_PRICE = 6000L;

    public static void initialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> register(dispatcher));
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        // /coins
        dispatcher.register(Commands.literal("coins")
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    long bal = ModEconomy.getBalance(player.getUUID());
                    ctx.getSource().sendSuccess(() -> Component.literal("你目前擁有 ")
                            .withStyle(ChatFormatting.YELLOW)
                            .append(Component.literal(fmt(bal) + " 金幣").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)), false);
                    return 1;
                }));

        // /sell, /sell hand, /sell all
        dispatcher.register(Commands.literal("sell")
                .executes(ctx -> sellHand(ctx.getSource()))
                .then(Commands.literal("hand").executes(ctx -> sellHand(ctx.getSource())))
                .then(Commands.literal("all").executes(ctx -> sellAllMinerals(ctx.getSource()))));

        // /opencase [basic|rare|epic]
        dispatcher.register(Commands.literal("opencase")
                .executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal("=== 礦物寶箱目錄 ===").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
                    ctx.getSource().sendSuccess(() -> Component.literal("/opencase basic ").withStyle(ChatFormatting.WHITE)
                            .append(Component.literal("(" + fmt(BASIC_CASE_PRICE) + " 金幣) - 基礎礦物與錫/銀裝備").withStyle(ChatFormatting.GRAY)), false);
                    ctx.getSource().sendSuccess(() -> Component.literal("/opencase rare ").withStyle(ChatFormatting.AQUA)
                            .append(Component.literal("(" + fmt(RARE_CASE_PRICE) + " 金幣) - 銀/鑽石/鈦碎片與稀有裝備").withStyle(ChatFormatting.GRAY)), false);
                    ctx.getSource().sendSuccess(() -> Component.literal("/opencase epic ").withStyle(ChatFormatting.LIGHT_PURPLE)
                            .append(Component.literal("(" + fmt(EPIC_CASE_PRICE) + " 金幣) - 鈦與終局防火鎢裝備").withStyle(ChatFormatting.GRAY)), false);
                    return 1;
                })
                .then(Commands.literal("basic").executes(ctx -> openCase(ctx.getSource(), "basic", BASIC_CASE_PRICE)))
                .then(Commands.literal("rare").executes(ctx -> openCase(ctx.getSource(), "rare", RARE_CASE_PRICE)))
                .then(Commands.literal("epic").executes(ctx -> openCase(ctx.getSource(), "epic", EPIC_CASE_PRICE))));
    }

    private static int sellHand(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ItemStack stack = player.getMainHandItem();
        if (stack.isEmpty()) {
            source.sendFailure(Component.literal("請先把手持要販售的礦物、碎片或裝備拿在主手上！"));
            return 0;
        }
        long unitVal = ModEconomy.getValue(stack.getItem());
        if (unitVal <= 0) {
            source.sendFailure(Component.literal("這個物品目前無法販售成金幣。"));
            return 0;
        }
        int count = stack.getCount();
        long earned = unitVal * count;
        Component itemName = stack.getHoverName().copy();
        stack.setCount(0);
        long total = ModEconomy.addCoins(player.getUUID(), earned);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.2F);

        source.sendSuccess(() -> Component.literal("已售出 ")
                .withStyle(ChatFormatting.GREEN)
                .append(itemName)
                .append(Component.literal(" x" + count + "，獲得 ").withStyle(ChatFormatting.GREEN))
                .append(Component.literal(fmt(earned) + " 金幣").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD))
                .append(Component.literal("（餘額：" + fmt(total) + " 金幣）").withStyle(ChatFormatting.YELLOW)), false);
        return 1;
    }

    private static int sellAllMinerals(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        Inventory inv = player.getInventory();
        long earned = 0;
        int soldItems = 0;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) {
                continue;
            }
            if (ModEconomy.isBulkSellable(stack.getItem())) {
                long unitVal = ModEconomy.getValue(stack.getItem());
                if (unitVal > 0) {
                    earned += unitVal * stack.getCount();
                    soldItems += stack.getCount();
                    inv.setItem(i, ItemStack.EMPTY);
                }
            }
        }

        if (earned <= 0) {
            source.sendFailure(Component.literal("背包中沒有可批次販售的礦物或碎片（裝備請拿在主手用 /sell 單獨販售）。"));
            return 0;
        }

        long total = ModEconomy.addCoins(player.getUUID(), earned);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.3F);

        final int finalCount = soldItems;
        final long finalEarned = earned;
        source.sendSuccess(() -> Component.literal("已批次售出 " + finalCount + " 個礦物/碎片，獲得 ")
                .withStyle(ChatFormatting.GREEN)
                .append(Component.literal(fmt(finalEarned) + " 金幣").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD))
                .append(Component.literal("（餘額：" + fmt(total) + " 金幣）").withStyle(ChatFormatting.YELLOW)), false);
        return 1;
    }

    private static int openCase(CommandSourceStack source, String tier, long cost) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (!ModEconomy.spendCoins(player.getUUID(), cost)) {
            long bal = ModEconomy.getBalance(player.getUUID());
            source.sendFailure(Component.literal("金幣不足！需要 " + fmt(cost) + " 金幣，你目前只有 " + fmt(bal) + " 金幣。"));
            return 0;
        }

        RandomSource rng = player.getRandom();
        ItemStack reward = rollReward(tier, rng);
        String rarityTag;
        ChatFormatting rarityColor;
        long val = ModEconomy.getValue(reward.getItem()) * reward.getCount();
        if (val >= 3000) {
            rarityTag = "【史詩】";
            rarityColor = ChatFormatting.LIGHT_PURPLE;
        } else if (val >= 480) {
            rarityTag = "【稀有】";
            rarityColor = ChatFormatting.AQUA;
        } else if (val >= 50) {
            rarityTag = "【優良】";
            rarityColor = ChatFormatting.YELLOW;
        } else {
            rarityTag = "【普通】";
            rarityColor = ChatFormatting.WHITE;
        }

        Component rewardName = reward.getHoverName().copy();
        int rewardCount = reward.getCount();
        if (!player.getInventory().add(reward)) {
            player.level().addFreshEntity(new ItemEntity(player.level(), player.getX(), player.getY(), player.getZ(), reward));
        }

        player.level().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8F, 1.15F);
        long remaining = ModEconomy.getBalance(player.getUUID());

        source.sendSuccess(() -> Component.literal("開啟寶箱獲得 ")
                .withStyle(ChatFormatting.GOLD)
                .append(Component.literal(rarityTag).withStyle(rarityColor, ChatFormatting.BOLD))
                .append(rewardName)
                .append(Component.literal(" x" + rewardCount).withStyle(ChatFormatting.WHITE))
                .append(Component.literal("（價值 " + fmt(val) + " 金幣｜餘額 " + fmt(remaining) + " 金幣）").withStyle(ChatFormatting.GRAY)), false);
        return 1;
    }

    private static ItemStack rollReward(String tier, RandomSource rng) {
        int roll = rng.nextInt(100);
        if ("basic".equals(tier)) {
            if (roll < 50) {
                Item[] pool = {ModItems.TIN_SHARD, ModItems.COAL_SHARD, ModItems.COPPER_SHARD, ModItems.IRON_SHARD};
                return new ItemStack(pool[rng.nextInt(pool.length)], rng.nextIntBetweenInclusive(4, 10));
            } else if (roll < 82) {
                Item[] pool = {ModItems.TIN_INGOT, ModItems.TIN_PICKAXE, ModItems.TIN_SWORD, ModItems.SILVER_SHARD, Items.IRON_INGOT};
                Item chosen = pool[rng.nextInt(pool.length)];
                int count = (chosen == ModItems.TIN_PICKAXE || chosen == ModItems.TIN_SWORD) ? 1 : rng.nextIntBetweenInclusive(2, 5);
                return new ItemStack(chosen, count);
            } else if (roll < 97) {
                Item[] pool = {ModItems.SILVER_INGOT, ModItems.DIAMOND_SHARD, ModItems.TITANIUM_SHARD};
                return new ItemStack(pool[rng.nextInt(pool.length)], rng.nextIntBetweenInclusive(2, 4));
            } else {
                return new ItemStack(ModItems.TUNGSTEN_SHARD, 2);
            }
        } else if ("rare".equals(tier)) {
            if (roll < 42) {
                Item[] pool = {ModItems.SILVER_INGOT, ModItems.SILVER_SWORD, ModItems.SILVER_PICKAXE, ModItems.SILVER_CHESTPLATE, ModItems.DIAMOND_SHARD};
                Item chosen = pool[rng.nextInt(pool.length)];
                int count = (chosen == ModItems.SILVER_INGOT || chosen == ModItems.DIAMOND_SHARD) ? rng.nextIntBetweenInclusive(3, 6) : 1;
                return new ItemStack(chosen, count);
            } else if (roll < 85) {
                Item[] pool = {ModItems.TITANIUM_SHARD, ModItems.TITANIUM_INGOT, Items.DIAMOND};
                Item chosen = pool[rng.nextInt(pool.length)];
                int count = (chosen == ModItems.TITANIUM_SHARD) ? rng.nextIntBetweenInclusive(3, 6) : rng.nextIntBetweenInclusive(1, 2);
                return new ItemStack(chosen, count);
            } else {
                Item[] pool = {ModItems.TITANIUM_SWORD, ModItems.TITANIUM_PICKAXE, ModItems.TUNGSTEN_SHARD};
                Item chosen = pool[rng.nextInt(pool.length)];
                return new ItemStack(chosen, chosen == ModItems.TUNGSTEN_SHARD ? rng.nextIntBetweenInclusive(3, 5) : 1);
            }
        } else {
            // epic case
            if (roll < 52) {
                Item[] pool = {ModItems.TITANIUM_SWORD, ModItems.TITANIUM_PICKAXE, ModItems.TITANIUM_HELMET, ModItems.TITANIUM_CHESTPLATE, ModItems.TITANIUM_LEGGINGS, ModItems.TITANIUM_BOOTS, ModItems.TITANIUM_INGOT};
                Item chosen = pool[rng.nextInt(pool.length)];
                return new ItemStack(chosen, chosen == ModItems.TITANIUM_INGOT ? rng.nextIntBetweenInclusive(3, 5) : 1);
            } else {
                Item[] pool = {ModItems.TUNGSTEN_INGOT, ModItems.TUNGSTEN_SWORD, ModItems.TUNGSTEN_PICKAXE, ModItems.TUNGSTEN_HELMET, ModItems.TUNGSTEN_CHESTPLATE, ModItems.TUNGSTEN_LEGGINGS, ModItems.TUNGSTEN_BOOTS};
                Item chosen = pool[rng.nextInt(pool.length)];
                return new ItemStack(chosen, chosen == ModItems.TUNGSTEN_INGOT ? rng.nextIntBetweenInclusive(2, 4) : 1);
            }
        }
    }

    private static String fmt(long num) {
        return NumberFormat.getNumberInstance(Locale.US).format(num);
    }
}
