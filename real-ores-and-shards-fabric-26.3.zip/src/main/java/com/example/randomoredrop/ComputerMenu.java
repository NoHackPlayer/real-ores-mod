package com.example.randomoredrop;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.List;

public class ComputerMenu extends ChestMenu {
    private static final String[] CASE_SLOTS = {
            "starter", "miner", "gem", "artifact", "armory", "netherite", "legendary"
    };

    private final ServerPlayer owner;
    private final SimpleContainer grid;

    public ComputerMenu(int syncId, Inventory playerInv, ServerPlayer owner) {
        this(syncId, playerInv, owner, new SimpleContainer(36));
    }

    private ComputerMenu(int syncId, Inventory playerInv, ServerPlayer owner, SimpleContainer grid) {
        super(MenuType.GENERIC_9x4, syncId, playerInv, grid, 4);
        this.owner = owner;
        this.grid = grid;
        populateButtons();
    }

    private void populateButtons() {
        ItemStack filler = makeIcon(Items.GRAY_STAINED_GLASS_PANE, Component.literal(" "), List.of());
        ItemStack darkFiller = makeIcon(Items.BLACK_STAINED_GLASS_PANE, Component.literal(" "), List.of());
        for (int i = 0; i < 36; i++) {
            this.grid.setItem(i, (i >= 27 ? darkFiller : filler).copy());
        }

        // Row 0 (Slots 0-8): Core Tools & Live Balance
        this.grid.setItem(2, makeIcon(Items.ANVIL,
                Component.literal("⚡ 裝備升級台 (Upgrader)").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD),
                List.of(Component.literal("點擊開啟 Upgrader 轉盤升級介面").withStyle(ChatFormatting.GRAY))));

        long bal = ModEconomy.getBalanceCents(this.owner.getUUID());
        this.grid.setItem(4, makeIcon(Items.NETHER_STAR,
                Component.literal("帳戶餘額：" + ModEconomy.formatCents(bal) + " 金幣").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                List.of(Component.literal("所有交易、開箱與銀行皆整合於此").withStyle(ChatFormatting.GRAY))));

        this.grid.setItem(6, makeIcon(Items.EMERALD,
                Component.literal("🏷 販售副手物品").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
                List.of(Component.literal("把任意想賣的物品放進副手後點擊").withStyle(ChatFormatting.GRAY))));

        this.grid.setItem(7, makeIcon(Items.HOPPER,
                Component.literal("💰 一鍵販售礦物碎片").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                List.of(Component.literal("批次賣出背包全部礦物與碎片").withStyle(ChatFormatting.GRAY))));

        // Row 1 (Slots 10-16): 7 Balanced CS:GO Cases (10 -> 10,000 Coins)
        for (int i = 0; i < CASE_SLOTS.length; i++) {
            ComputerActions.CaseDef def = ComputerActions.getCaseDef(CASE_SLOTS[i]);
            this.grid.setItem(10 + i, makeIcon(def.icon(),
                    Component.literal(def.displayName() + " (" + ModEconomy.formatCents(def.costCents()) + " 金幣)")
                            .withStyle(def.titleColor(), ChatFormatting.BOLD),
                    List.of(
                            Component.literal(def.subtitle()).withStyle(ChatFormatting.GRAY),
                            Component.literal("左鍵：開啟 CS:GO 滾動開箱").withStyle(ChatFormatting.GREEN),
                            Component.literal("右鍵：預覽掉落物與機率").withStyle(ChatFormatting.YELLOW)
                    )));
        }

        // Row 2 (Slots 19-23, 25): Bank Withdraw & Deposit
        this.grid.setItem(19, makeIcon(ModItems.COIN_1,
                Component.literal("提款 1 金幣").withStyle(ChatFormatting.YELLOW),
                List.of(Component.literal("領出 1 元實體金幣").withStyle(ChatFormatting.GRAY))));
        this.grid.setItem(20, makeIcon(ModItems.COIN_10,
                Component.literal("提款 10 金幣").withStyle(ChatFormatting.YELLOW),
                List.of(Component.literal("領出 10 元實體金幣").withStyle(ChatFormatting.GRAY))));
        this.grid.setItem(21, makeIcon(ModItems.COIN_100,
                Component.literal("提款 100 金幣").withStyle(ChatFormatting.GOLD),
                List.of(Component.literal("領出 100 元實體金幣").withStyle(ChatFormatting.GRAY))));
        this.grid.setItem(22, makeIcon(ModItems.COIN_1000,
                Component.literal("提款 1,000 金幣").withStyle(ChatFormatting.AQUA),
                List.of(Component.literal("領出 1,000 元實體金幣").withStyle(ChatFormatting.GRAY))));
        this.grid.setItem(23, makeIcon(ModItems.COIN_10000,
                Component.literal("提款 10,000 金幣").withStyle(ChatFormatting.LIGHT_PURPLE),
                List.of(Component.literal("領出 10,000 元實體金幣").withStyle(ChatFormatting.GRAY))));

        this.grid.setItem(25, makeIcon(Items.GOLD_BLOCK,
                Component.literal("🏦 存入背包全部實體金幣").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
                List.of(Component.literal("一鍵存入所有面額實體金幣").withStyle(ChatFormatting.GRAY))));

        // Row 3 (Slot 31): CS:GO Rarity & Odds Legend
        this.grid.setItem(31, makeIcon(Items.BOOK,
                Component.literal("📖 CS:GO 寶箱機率說明").withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD),
                List.of(
                        Component.literal("藍 軍規級 52.0%｜紫 受限級 26.5%").withStyle(ChatFormatting.AQUA),
                        Component.literal("粉 保密級 14.5%｜紅 隱秘級 5.5%｜金 ★極品 1.5%").withStyle(ChatFormatting.GOLD),
                        Component.literal("所有寶箱依價值精準分級與平衡").withStyle(ChatFormatting.GRAY)
                )));
    }

    public static ItemStack makeIcon(Item item, Component name, List<Component> lore) {
        ItemStack st = new ItemStack(item);
        st.set(DataComponents.ITEM_NAME, name);
        if (!lore.isEmpty()) {
            st.set(DataComponents.LORE, new ItemLore(lore));
        }
        return st;
    }

    @Override
    public void clicked(int slotId, int button, ContainerInput containerInput, Player player) {
        if (slotId >= 0 && slotId < 36) {
            if (player instanceof ServerPlayer sp) {
                handleButton(sp, slotId, button);
            }
            return;
        }
        if (containerInput == ContainerInput.QUICK_MOVE) {
            return;
        }
        super.clicked(slotId, button, containerInput, player);
    }

    private void handleButton(ServerPlayer sp, int slot, int button) {
        if (slot >= 10 && slot <= 16) {
            String caseId = CASE_SLOTS[slot - 10];
            ComputerActions.CaseDef def = ComputerActions.getCaseDef(caseId);
            if (button == 1) {
                CaseOpenerMenu.openPreview(sp, caseId, def.costCents());
            } else {
                CaseOpenerMenu.openAndSpin(sp, caseId, def.costCents());
            }
            return;
        }

        switch (slot) {
            case 2 -> {
                sp.closeContainer();
                UpgraderCompat.openUpgraderGui(sp);
                return;
            }
            case 6 -> ComputerActions.sellOffhand(sp);
            case 7 -> ComputerActions.sellAllMinerals(sp);
            case 19 -> ComputerActions.withdrawSingle(sp, 1L, ModItems.COIN_1);
            case 20 -> ComputerActions.withdrawSingle(sp, 10L, ModItems.COIN_10);
            case 21 -> ComputerActions.withdrawSingle(sp, 100L, ModItems.COIN_100);
            case 22 -> ComputerActions.withdrawSingle(sp, 1000L, ModItems.COIN_1000);
            case 23 -> ComputerActions.withdrawSingle(sp, 10000L, ModItems.COIN_10000);
            case 25 -> ComputerActions.depositAll(sp);
            default -> {
                return;
            }
        }
        populateButtons();
        this.broadcastChanges();
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }
}
