package com.example.randomoredrop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

public class StockMarket {
    public record Candle(long openCents, long highCents, long lowCents, long closeCents) {}

    public record StockSnapshot(
            String symbol,
            String name,
            long priceCents,
            long prevCloseCents,
            boolean live,
            List<Candle> candles,
            long ownedShares,
            long avgCostCents
    ) {}

    public static class Holding {
        public long shares;
        public long avgCostCents;
        public Holding() {}
        public Holding(long shares, long avgCostCents) {
            this.shares = shares;
            this.avgCostCents = avgCostCents;
        }
    }

    private static class StockState {
        final String symbol;
        final String name;
        volatile long priceCents;
        volatile long prevCloseCents;
        volatile boolean live;
        volatile List<Candle> candles;

        StockState(String symbol, String name, long basePriceCents) {
            this.symbol = symbol;
            this.name = name;
            this.priceCents = basePriceCents;
            this.prevCloseCents = basePriceCents;
            this.live = false;
            this.candles = generateFallbackCandles(symbol.hashCode(), basePriceCents);
        }
    }

    public static final String[] SYMBOLS = {
            "NVDA", "TSLA", "AAPL", "PLTR", "AMD", "AMZN", "MSFT", "META", "GOOGL", "INTC"
    };

    private static final String[] NAMES = {
            "NVIDIA", "Tesla", "Apple", "Palantir", "AMD", "Amazon", "Microsoft", "Meta", "Alphabet", "Intel"
    };

    // Baseline fallback prices in cents (1 USD = 1.00 Coin = 100 cents)
    private static final long[] BASE_CENTS = {
            14200L, 33500L, 23200L, 6500L, 14500L, 21000L, 42500L, 58500L, 17800L, 2450L
    };

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type PORTFOLIO_TYPE = new TypeToken<Map<String, Map<String, Holding>>>() {}.getType();

    private static final Map<String, StockState> STOCKS = new LinkedHashMap<>();
    private static final Map<UUID, Map<String, Holding>> PORTFOLIOS = new ConcurrentHashMap<>();
    private static Path saveFile;
    private static ScheduledExecutorService scheduler;
    private static HttpClient httpClient;

    static {
        for (int i = 0; i < SYMBOLS.length; i++) {
            STOCKS.put(SYMBOLS[i], new StockState(SYMBOLS[i], NAMES[i], BASE_CENTS[i]));
        }
    }

    public static void start(MinecraftServer server) {
        load(server);
        if (httpClient == null) {
            httpClient = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(5))
                    .followRedirects(HttpClient.Redirect.NORMAL)
                    .build();
        }
        stopScheduler();
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "RealOres-StockFetcher");
            t.setDaemon(true);
            return t;
        });
        // Fetch live US stock prices & OHLC K-line candles immediately, then every 60 seconds
        scheduler.scheduleAtFixedRate(StockMarket::refreshAllSafe, 0, 60, TimeUnit.SECONDS);
    }

    public static void stop() {
        save();
        stopScheduler();
    }

    private static void stopScheduler() {
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
    }

    public static void triggerAsyncRefresh() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.execute(StockMarket::refreshAllSafe);
        }
    }

    private static void refreshAllSafe() {
        for (String sym : SYMBOLS) {
            try {
                if (!fetchYahooChart(sym, "1d", "5m")) {
                    if (!fetchYahooChart(sym, "5d", "30m")) {
                        nudgeFallback(STOCKS.get(sym));
                    }
                }
            } catch (Throwable ignored) {
                nudgeFallback(STOCKS.get(sym));
            }
        }
    }

    private static boolean fetchYahooChart(String symbol, String range, String interval) {
        try {
            String url = "https://query1.finance.yahoo.com/v8/finance/chart/" + symbol
                    + "?range=" + range + "&interval=" + interval;
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(5))
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200 || resp.body() == null || resp.body().isEmpty()) {
                return false;
            }
            JsonObject root = JsonParser.parseString(resp.body()).getAsJsonObject();
            JsonObject chart = root.getAsJsonObject("chart");
            if (chart == null || !chart.has("result") || chart.get("result").isJsonNull()) {
                return false;
            }
            JsonArray results = chart.getAsJsonArray("result");
            if (results.isEmpty()) return false;
            JsonObject res = results.get(0).getAsJsonObject();
            JsonObject meta = res.getAsJsonObject("meta");
            if (meta == null) return false;

            double regPrice = meta.has("regularMarketPrice") && !meta.get("regularMarketPrice").isJsonNull()
                    ? meta.get("regularMarketPrice").getAsDouble() : 0.0;
            double prevClose = meta.has("chartPreviousClose") && !meta.get("chartPreviousClose").isJsonNull()
                    ? meta.get("chartPreviousClose").getAsDouble()
                    : (meta.has("previousClose") && !meta.get("previousClose").isJsonNull()
                    ? meta.get("previousClose").getAsDouble() : regPrice);

            List<Candle> parsed = new ArrayList<>();
            if (res.has("indicators") && !res.get("indicators").isJsonNull()) {
                JsonObject ind = res.getAsJsonObject("indicators");
                if (ind.has("quote") && !ind.get("quote").isJsonNull()) {
                    JsonArray qArr = ind.getAsJsonArray("quote");
                    if (!qArr.isEmpty()) {
                        JsonObject q = qArr.get(0).getAsJsonObject();
                        JsonArray opens = q.getAsJsonArray("open");
                        JsonArray highs = q.getAsJsonArray("high");
                        JsonArray lows = q.getAsJsonArray("low");
                        JsonArray closes = q.getAsJsonArray("close");
                        if (opens != null && highs != null && lows != null && closes != null) {
                            int n = Math.min(Math.min(opens.size(), closes.size()), Math.min(highs.size(), lows.size()));
                            for (int i = 0; i < n; i++) {
                                Double o = optDouble(opens.get(i));
                                Double h = optDouble(highs.get(i));
                                Double l = optDouble(lows.get(i));
                                Double c = optDouble(closes.get(i));
                                if (o != null && h != null && l != null && c != null && o > 0 && c > 0) {
                                    parsed.add(new Candle(toCents(o), toCents(h), toCents(l), toCents(c)));
                                }
                            }
                        }
                    }
                }
            }

            if (parsed.size() < 6) {
                return false;
            }
            if (parsed.size() > 36) {
                parsed = new ArrayList<>(parsed.subList(parsed.size() - 36, parsed.size()));
            }
            long priceCents = regPrice > 0 ? toCents(regPrice) : parsed.get(parsed.size() - 1).closeCents();
            long prevCents = prevClose > 0 ? toCents(prevClose) : parsed.get(0).openCents();

            StockState st = STOCKS.get(symbol);
            if (st != null) {
                st.priceCents = Math.max(10L, priceCents);
                st.prevCloseCents = Math.max(10L, prevCents);
                st.candles = Collections.unmodifiableList(parsed);
                st.live = true;
            }
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static Double optDouble(JsonElement el) {
        if (el == null || el.isJsonNull()) return null;
        try {
            double v = el.getAsDouble();
            return Double.isFinite(v) ? v : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static long toCents(double usd) {
        return Math.max(10L, Math.round(usd * 100.0));
    }

    private static List<Candle> generateFallbackCandles(int seed, long baseCents) {
        Random r = new Random(seed * 31L + 77L);
        List<Candle> list = new ArrayList<>();
        long cur = Math.max(100L, Math.round(baseCents * 0.985));
        for (int i = 0; i < 32; i++) {
            long open = cur;
            double drift = (r.nextDouble() - 0.49) * 0.014;
            long close = Math.max(50L, Math.round(open * (1.0 + drift)));
            long hi = Math.max(open, close) + Math.max(5L, Math.round(open * r.nextDouble() * 0.006));
            long lo = Math.max(25L, Math.min(open, close) - Math.max(5L, Math.round(open * r.nextDouble() * 0.006)));
            list.add(new Candle(open, hi, lo, close));
            cur = close;
        }
        return list;
    }

    private static void nudgeFallback(StockState st) {
        if (st == null || st.live) return;
        Random r = new Random();
        List<Candle> copy = new ArrayList<>(st.candles);
        long open = st.priceCents;
        long close = Math.max(50L, Math.round(open * (1.0 + (r.nextDouble() - 0.5) * 0.012)));
        long hi = Math.max(open, close) + Math.max(5L, Math.round(open * r.nextDouble() * 0.004));
        long lo = Math.max(25L, Math.min(open, close) - Math.max(5L, Math.round(open * r.nextDouble() * 0.004)));
        copy.add(new Candle(open, hi, lo, close));
        if (copy.size() > 36) copy.remove(0);
        st.priceCents = close;
        st.candles = Collections.unmodifiableList(copy);
    }

    public static List<StockSnapshot> getSnapshotsFor(UUID playerId) {
        Map<String, Holding> book = PORTFOLIOS.getOrDefault(playerId, Collections.emptyMap());
        List<StockSnapshot> out = new ArrayList<>(SYMBOLS.length);
        for (String sym : SYMBOLS) {
            StockState st = STOCKS.get(sym);
            Holding h = book.get(sym);
            out.add(new StockSnapshot(
                    st.symbol, st.name, st.priceCents, st.prevCloseCents, st.live, st.candles,
                    h != null ? h.shares : 0L,
                    h != null ? h.avgCostCents : 0L
            ));
        }
        return out;
    }

    public static ComputerActions.ActionMsg buyStock(ServerPlayer player, String symbol, long qty) {
        StockState st = STOCKS.get(symbol);
        if (st == null || qty <= 0L) {
            return new ComputerActions.ActionMsg("msg.randomoredrop.stock_invalid", "", "", true);
        }
        long totalCost = st.priceCents * qty;
        if (!ModEconomy.spendCents(player.getUUID(), totalCost)) {
            return new ComputerActions.ActionMsg("msg.randomoredrop.not_enough_coins",
                    ModEconomy.formatCents(totalCost),
                    ModEconomy.formatCents(ModEconomy.getBalanceCents(player.getUUID())), true);
        }
        Map<String, Holding> book = PORTFOLIOS.computeIfAbsent(player.getUUID(), k -> new ConcurrentHashMap<>());
        Holding h = book.computeIfAbsent(symbol, k -> new Holding(0L, 0L));
        long newShares = h.shares + qty;
        long weightedCost = (h.shares * h.avgCostCents + totalCost) / newShares;
        h.shares = newShares;
        h.avgCostCents = weightedCost;
        save();
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.25F);
        return new ComputerActions.ActionMsg("msg.randomoredrop.stock_bought",
                qty + " " + symbol, ModEconomy.formatCents(totalCost), false);
    }

    public static ComputerActions.ActionMsg sellStock(ServerPlayer player, String symbol, long qty) {
        StockState st = STOCKS.get(symbol);
        if (st == null) {
            return new ComputerActions.ActionMsg("msg.randomoredrop.stock_invalid", "", "", true);
        }
        Map<String, Holding> book = PORTFOLIOS.get(player.getUUID());
        Holding h = book != null ? book.get(symbol) : null;
        if (h == null || h.shares <= 0L) {
            return new ComputerActions.ActionMsg("msg.randomoredrop.stock_no_shares", symbol, "", true);
        }
        long sellQty = (qty <= 0L) ? h.shares : Math.min(qty, h.shares);
        long payout = st.priceCents * sellQty;
        h.shares -= sellQty;
        if (h.shares <= 0L) {
            book.remove(symbol);
        }
        save();
        ModEconomy.addCents(player.getUUID(), payout);
        player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 1.35F);
        return new ComputerActions.ActionMsg("msg.randomoredrop.stock_sold",
                sellQty + " " + symbol, ModEconomy.formatCents(payout), false);
    }

    private static void load(MinecraftServer server) {
        PORTFOLIOS.clear();
        saveFile = server.getWorldPath(LevelResource.ROOT).resolve("data").resolve("randomoredrop_stocks_v1.json");
        if (Files.exists(saveFile)) {
            try {
                Map<String, Map<String, Holding>> loaded = GSON.fromJson(Files.readString(saveFile), PORTFOLIO_TYPE);
                if (loaded != null) {
                    loaded.forEach((k, v) -> {
                        try {
                            Map<String, Holding> m = new ConcurrentHashMap<>();
                            if (v != null) m.putAll(v);
                            PORTFOLIOS.put(UUID.fromString(k), m);
                        } catch (IllegalArgumentException ignored) {}
                    });
                }
            } catch (IOException ignored) {}
        }
    }

    public static void save() {
        if (saveFile == null) return;
        try {
            Files.createDirectories(saveFile.getParent());
            Map<String, Map<String, Holding>> out = new LinkedHashMap<>();
            PORTFOLIOS.forEach((k, v) -> out.put(k.toString(), new LinkedHashMap<>(v)));
            Files.writeString(saveFile, GSON.toJson(out));
        } catch (IOException ignored) {}
    }
}
