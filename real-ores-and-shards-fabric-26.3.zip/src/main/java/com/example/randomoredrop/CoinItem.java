package com.example.randomoredrop;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class CoinItem extends Item {
    private final long coinValue; // whole coins (1, 10, 100, 1000, 10000)

    public CoinItem(long coinValue, Properties properties) {
        super(properties);
        this.coinValue = coinValue;
    }

    public long getCoinValue() {
        return this.coinValue;
    }

    public long getCentsValue() {
        return this.coinValue * 100L;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            int count = player.isShiftKeyDown() ? stack.getCount() : 1;
            long centsAdded = this.getCentsValue() * count;
            stack.shrink(count);
            long totalCents = ModEconomy.addCents(serverPlayer.getUUID(), centsAdded);
            level.playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.7F, 1.35F);
            serverPlayer.sendSystemMessage(Component.literal("已存入 ")
                    .withStyle(ChatFormatting.GREEN)
                    .append(Component.literal(ModEconomy.formatCents(centsAdded) + " 金幣").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD))
                    .append(Component.literal("（餘額：" + ModEconomy.formatCents(totalCents) + " 金幣）").withStyle(ChatFormatting.YELLOW)));
        }
        return InteractionResult.SUCCESS;
    }
}
