package com.example.randomoredrop;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ComputerNetwork {
    private record PendingSpin(String caseId, ItemStack prize, int tierIndex, ChatFormatting color, long valCents, double exactChancePct, long expireTick) {}
    private static final Map<UUID, PendingSpin> PENDING_SPINS = new ConcurrentHashMap<>();
    private static long serverTicks = 0L;

    public record OpenComputerPayload(long balanceCents) implements CustomPacketPayload {
        public static final Type<OpenComputerPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "open_computer"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenComputerPayload> CODEC = StreamCodec.of(
                (buf, p) -> buf.writeLong(p.balanceCents()),
                buf -> new OpenComputerPayload(buf.readLong())
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record BalanceSyncPayload(long balanceCents, String msgKey, String arg1, String arg2, boolean isError) implements CustomPacketPayload {
        public static final Type<BalanceSyncPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "balance_sync"));
        public static final StreamCodec<RegistryFriendlyByteBuf, BalanceSyncPayload> CODEC = StreamCodec.of(
                (buf, p) -> {
                    buf.writeLong(p.balanceCents());
                    buf.writeUtf(p.msgKey());
                    buf.writeUtf(p.arg1());
                    buf.writeUtf(p.arg2());
                    buf.writeBoolean(p.isError());
                },
                buf -> new BalanceSyncPayload(buf.readLong(), buf.readUtf(), buf.readUtf(), buf.readUtf(), buf.readBoolean())
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record SpinResultPayload(
            String caseId,
            long costCents,
            long newBalanceCents,
            int winTier,
            String winItemId,
            int winCount,
            int winDamage,
            long winValueCents
    ) implements CustomPacketPayload {
        public static final Type<SpinResultPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "spin_result"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SpinResultPayload> CODEC = StreamCodec.of(
                (buf, p) -> {
                    buf.writeUtf(p.caseId());
                    buf.writeLong(p.costCents());
                    buf.writeLong(p.newBalanceCents());
                    buf.writeVarInt(p.winTier());
                    buf.writeUtf(p.winItemId());
                    buf.writeVarInt(p.winCount());
                    buf.writeVarInt(p.winDamage());
                    buf.writeLong(p.winValueCents());
                },
                buf -> new SpinResultPayload(
                        buf.readUtf(), buf.readLong(), buf.readLong(),
                        buf.readVarInt(), buf.readUtf(), buf.readVarInt(), buf.readVarInt(), buf.readLong()
                )
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record ComputerActionPayload(String action, String arg) implements CustomPacketPayload {
        public static final Type<ComputerActionPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "computer_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf, ComputerActionPayload> CODEC = StreamCodec.of(
                (buf, p) -> {
                    buf.writeUtf(p.action());
                    buf.writeUtf(p.arg());
                },
                buf -> new ComputerActionPayload(buf.readUtf(), buf.readUtf())
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record StockSyncPayload(long balanceCents, java.util.List<StockMarket.StockSnapshot> stocks) implements CustomPacketPayload {
        public static final Type<StockSyncPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "stock_sync"));
        public static final StreamCodec<RegistryFriendlyByteBuf, StockSyncPayload> CODEC = StreamCodec.of(
                (buf, p) -> {
                    buf.writeLong(p.balanceCents());
                    buf.writeVarInt(p.stocks().size());
                    for (StockMarket.StockSnapshot s : p.stocks()) {
                        buf.writeUtf(s.symbol());
                        buf.writeUtf(s.name());
                        buf.writeLong(s.priceCents());
                        buf.writeLong(s.prevCloseCents());
                        buf.writeBoolean(s.live());
                        buf.writeLong(s.ownedShares());
                        buf.writeLong(s.avgCostCents());
                        buf.writeLong(s.shortShares());
                        buf.writeLong(s.shortAvgEntryCents());
                        buf.writeVarInt(s.candles().size());
                        for (StockMarket.Candle c : s.candles()) {
                            buf.writeLong(c.openCents());
                            buf.writeLong(c.highCents());
                            buf.writeLong(c.lowCents());
                            buf.writeLong(c.closeCents());
                        }
                    }
                },
                buf -> {
                    long bal = buf.readLong();
                    int n = buf.readVarInt();
                    java.util.List<StockMarket.StockSnapshot> list = new java.util.ArrayList<>(n);
                    for (int i = 0; i < n; i++) {
                        String sym = buf.readUtf();
                        String nm = buf.readUtf();
                        long price = buf.readLong();
                        long prev = buf.readLong();
                        boolean live = buf.readBoolean();
                        long owned = buf.readLong();
                        long avg = buf.readLong();
                        long sOwned = buf.readLong();
                        long sAvg = buf.readLong();
                        int cn = buf.readVarInt();
                        java.util.List<StockMarket.Candle> candles = new java.util.ArrayList<>(cn);
                        for (int j = 0; j < cn; j++) {
                            candles.add(new StockMarket.Candle(buf.readLong(), buf.readLong(), buf.readLong(), buf.readLong()));
                        }
                        list.add(new StockMarket.StockSnapshot(sym, nm, price, prev, live, candles, owned, avg, sOwned, sAvg));
                    }
                    return new StockSyncPayload(bal, list);
                }
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public static void registerCommon() {
        PayloadTypeRegistry.clientboundPlay().register(OpenComputerPayload.TYPE, OpenComputerPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(BalanceSyncPayload.TYPE, BalanceSyncPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(SpinResultPayload.TYPE, SpinResultPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(StockSyncPayload.TYPE, StockSyncPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(ComputerActionPayload.TYPE, ComputerActionPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ComputerActionPayload.TYPE, (payload, ctx) -> {
            ServerPlayer sp = ctx.player();
            ctx.server().execute(() -> handleAction(sp, payload.action(), payload.arg()));
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayer sp = handler.getPlayer();
            claimPending(sp, true);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            serverTicks++;
            if (PENDING_SPINS.isEmpty() || serverTicks % 20 != 0) {
                return;
            }
            for (Map.Entry<UUID, PendingSpin> entry : PENDING_SPINS.entrySet()) {
                if (serverTicks >= entry.getValue().expireTick()) {
                    ServerPlayer sp = server.getPlayerList().getPlayer(entry.getKey());
                    if (sp != null) {
                        claimPending(sp, false);
                    }
                }
            }
        });
    }

    public static void sendOpenComputer(ServerPlayer player) {
        long bal = ModEconomy.getBalanceCents(player.getUUID());
        ServerPlayNetworking.send(player, new OpenComputerPayload(bal));
        sendStocks(player);
    }

    public static void sendStocks(ServerPlayer player) {
        long bal = ModEconomy.getBalanceCents(player.getUUID());
        ServerPlayNetworking.send(player, new StockSyncPayload(bal, StockMarket.getSnapshotsFor(player.getUUID())));
    }

    public static void sendBalance(ServerPlayer player, String msgKey, String arg1, String arg2, boolean isError) {
        long bal = ModEconomy.getBalanceCents(player.getUUID());
        ServerPlayNetworking.send(player, new BalanceSyncPayload(bal, msgKey, arg1, arg2, isError));
    }

    private static void handleAction(ServerPlayer sp, String action, String arg) {
        switch (action) {
            case "open_upgrader" -> {
                claimPending(sp, false);
                UpgraderCompat.openUpgraderGui(sp);
            }
            case "spin_case" -> {
                claimPending(sp, false);
                ComputerActions.CaseDef def = ComputerActions.getCaseDef(arg);
                if (!ModEconomy.spendCents(sp.getUUID(), def.costCents())) {
                    long bal = ModEconomy.getBalanceCents(sp.getUUID());
                    sendBalance(sp, "msg.randomoredrop.not_enough_coins",
                            ModEconomy.formatCents(def.costCents()), ModEconomy.formatCents(bal), true);
                    return;
                }
                ComputerActions.CaseEntry entry = ComputerActions.rollCaseEntry(def.id(), sp.getRandom());
                ItemStack prize = entry.stack().copy();
                long valCents = ModEconomy.getStackCents(prize);
                String itemId = BuiltInRegistries.ITEM.getKey(prize.getItem()).toString();
                double exactPct = ComputerActions.getExactDropChancePct(def.id(), entry.tierIndex());
                PENDING_SPINS.put(sp.getUUID(), new PendingSpin(
                        def.id(), prize, entry.tierIndex(), entry.color(), valCents, exactPct, serverTicks + 140L
                ));
                long newBal = ModEconomy.getBalanceCents(sp.getUUID());
                ServerPlayNetworking.send(sp, new SpinResultPayload(
                        def.id(), def.costCents(), newBal, entry.tierIndex(), itemId, prize.getCount(), prize.getDamageValue(), valCents
                ));
            }
            case "claim_spin" -> claimPending(sp, false);
            case "sell_slots" -> {
                ComputerActions.ActionMsg res = ComputerActions.sellSelectedSlotsAction(sp, arg);
                sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
            }
            case "sell_offhand" -> {
                ComputerActions.ActionMsg res = ComputerActions.sellOffhandAction(sp);
                sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
            }
            case "sell_minerals" -> {
                ComputerActions.ActionMsg res = ComputerActions.sellAllMineralsAction(sp);
                sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
            }
            case "withdraw" -> {
                long amt = switch (arg) {
                    case "1" -> 1L;
                    case "10" -> 10L;
                    case "100" -> 100L;
                    case "1000" -> 1000L;
                    case "10000" -> 10000L;
                    default -> 0L;
                };
                if (amt > 0L) {
                    Item coin = switch (arg) {
                        case "1" -> ModItems.COIN_1;
                        case "10" -> ModItems.COIN_10;
                        case "100" -> ModItems.COIN_100;
                        case "1000" -> ModItems.COIN_1000;
                        default -> ModItems.COIN_10000;
                    };
                    ComputerActions.ActionMsg res = ComputerActions.withdrawSingleAction(sp, amt, coin);
                    sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
                }
            }
            case "deposit_all" -> {
                ComputerActions.ActionMsg res = ComputerActions.depositAllAction(sp);
                sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
            }
            case "sync_stocks" -> sendStocks(sp);
            case "refresh_stocks" -> {
                StockMarket.triggerAsyncRefresh();
                sendStocks(sp);
            }
            case "buy_stock" -> {
                String[] parts = arg.split(":");
                if (parts.length == 2) {
                    try {
                        long qty = Long.parseLong(parts[1]);
                        ComputerActions.ActionMsg res = StockMarket.buyStock(sp, parts[0], qty);
                        sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
                        sendStocks(sp);
                    } catch (NumberFormatException ignored) {}
                }
            }
            case "sell_stock" -> {
                String[] parts = arg.split(":");
                if (parts.length == 2) {
                    try {
                        long qty = Long.parseLong(parts[1]);
                        ComputerActions.ActionMsg res = StockMarket.sellStock(sp, parts[0], qty);
                        sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
                        sendStocks(sp);
                    } catch (NumberFormatException ignored) {}
                }
            }
            case "short_stock" -> {
                String[] parts = arg.split(":");
                if (parts.length == 2) {
                    try {
                        long qty = Long.parseLong(parts[1]);
                        ComputerActions.ActionMsg res = StockMarket.shortStock(sp, parts[0], qty);
                        sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
                        sendStocks(sp);
                    } catch (NumberFormatException ignored) {}
                }
            }
            case "cover_stock" -> {
                String[] parts = arg.split(":");
                if (parts.length == 2) {
                    try {
                        long qty = Long.parseLong(parts[1]);
                        ComputerActions.ActionMsg res = StockMarket.coverStock(sp, parts[0], qty);
                        sendBalance(sp, res.key(), res.arg1(), res.arg2(), res.isError());
                        sendStocks(sp);
                    } catch (NumberFormatException ignored) {}
                }
            }
            default -> {}
        }
    }

    private static void claimPending(ServerPlayer sp, boolean silent) {
        PendingSpin pending = PENDING_SPINS.remove(sp.getUUID());
        if (pending == null) {
            return;
        }
        ItemStack prize = pending.prize().copy();
        Component rewardName = prize.getHoverName().copy();
        int count = prize.getCount();
        // MUST capture wear BEFORE giveOrDrop() mutates prize count to 0!
        Component wearComp = ComputerActions.formatWearComponent(prize);
        ComputerActions.giveOrDrop(sp, prize);

        if (!silent) {
            if (pending.tierIndex() >= 4) {
                net.minecraft.sounds.SoundEvent goldSound = BuiltInRegistries.SOUND_EVENT
                        .getOptional(Identifier.withDefaultNamespace("ui.toast.challenge_complete"))
                        .orElse(SoundEvents.PLAYER_LEVELUP);
                sp.level().playSound(null, sp.blockPosition(), goldSound, SoundSource.PLAYERS, 0.9F, 1.0F);
            } else if (pending.tierIndex() >= 2) {
                sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.85F, 1.15F);
            } else {
                sp.level().playSound(null, sp.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 0.95F);
            }

            long remaining = ModEconomy.getBalanceCents(sp.getUUID());
            Component rarityComp = Component.translatable(ComputerActions.rarityKey(pending.tierIndex()))
                    .withStyle(pending.color(), ChatFormatting.BOLD);
            Component itemAndWear = Component.empty()
                    .append(rewardName.copy().withStyle(pending.color(), ChatFormatting.BOLD))
                    .append(Component.literal(" x" + count).withStyle(ChatFormatting.WHITE))
                    .append(wearComp);

            sp.sendSystemMessage(Component.translatable(
                    "msg.randomoredrop.case_won",
                    rarityComp,
                    itemAndWear,
                    ModEconomy.formatCents(pending.valCents()),
                    ModEconomy.formatCents(remaining)
            ).withStyle(ChatFormatting.GOLD));

            if (pending.tierIndex() >= 3 && sp.level().getServer() != null) {
                String pctStr = String.format("%.2f%%", pending.exactChancePct());
                Component caseName = Component.translatable("case.randomoredrop." + pending.caseId());
                Component globalMsg = Component.translatable(
                        "msg.randomoredrop.broadcast_case",
                        Component.literal(sp.getName().getString()).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD),
                        caseName,
                        rarityComp,
                        itemAndWear,
                        pctStr,
                        ModEconomy.formatCents(pending.valCents())
                ).withStyle(ChatFormatting.GOLD);
                sp.level().getServer().getPlayerList().broadcastSystemMessage(globalMsg, false);
            }
        }
    }
}
