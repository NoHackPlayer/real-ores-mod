package com.example.randomoredrop;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ComputerNetwork {
    private record PendingSpin(ItemStack prize, int tierIndex, String rarityLabel, ChatFormatting color, long valCents, long expireTick) {}
    private static final Map<UUID, PendingSpin> PENDING_SPINS = new ConcurrentHashMap<>();
    private static long serverTicks = 0L;

    public record OpenComputerPayload(long balanceCents) implements CustomPacketPayload {
        public static final Type<OpenComputerPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "open_computer"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenComputerPayload> CODEC = StreamCodec.of(
                (buf, p) -> buf.writeLong(p.balanceCents()),
                buf -> new OpenComputerPayload(buf.readLong())
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record BalanceSyncPayload(long balanceCents, String message, boolean isError) implements CustomPacketPayload {
        public static final Type<BalanceSyncPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "balance_sync"));
        public static final StreamCodec<RegistryFriendlyByteBuf, BalanceSyncPayload> CODEC = StreamCodec.of(
                (buf, p) -> {
                    buf.writeLong(p.balanceCents());
                    buf.writeUtf(p.message());
                    buf.writeBoolean(p.isError());
                },
                buf -> new BalanceSyncPayload(buf.readLong(), buf.readUtf(), buf.readBoolean())
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record SpinResultPayload(
            String caseId,
            long costCents,
            long newBalanceCents,
            int winTier,
            String winItemId,
            int winCount,
            long winValueCents
    ) implements CustomPacketPayload {
        public static final Type<SpinResultPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "spin_result"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SpinResultPayload> CODEC = StreamCodec.of(
                (buf, p) -> {
                    buf.writeUtf(p.caseId());
                    buf.writeLong(p.costCents());
                    buf.writeLong(p.newBalanceCents());
                    buf.writeVarInt(p.winTier());
                    buf.writeUtf(p.winItemId());
                    buf.writeVarInt(p.winCount());
                    buf.writeLong(p.winValueCents());
                },
                buf -> new SpinResultPayload(
                        buf.readUtf(), buf.readLong(), buf.readLong(),
                        buf.readVarInt(), buf.readUtf(), buf.readVarInt(), buf.readLong()
                )
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record ComputerActionPayload(String action, String arg) implements CustomPacketPayload {
        public static final Type<ComputerActionPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, "computer_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf, ComputerActionPayload> CODEC = StreamCodec.of(
                (buf, p) -> {
                    buf.writeUtf(p.action());
                    buf.writeUtf(p.arg());
                },
                buf -> new ComputerActionPayload(buf.readUtf(), buf.readUtf())
        );
        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public static void registerCommon() {
        PayloadTypeRegistry.clientboundPlay().register(OpenComputerPayload.TYPE, OpenComputerPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(BalanceSyncPayload.TYPE, BalanceSyncPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(SpinResultPayload.TYPE, SpinResultPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(ComputerActionPayload.TYPE, ComputerActionPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ComputerActionPayload.TYPE, (payload, ctx) -> {
            ServerPlayer sp = ctx.player();
            ctx.server().execute(() -> handleAction(sp, payload.action(), payload.arg()));
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayer sp = handler.getPlayer();
            claimPending(sp, true);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            serverTicks++;
            if (PENDING_SPINS.isEmpty() || serverTicks % 20 != 0) {
                return;
            }
            for (Map.Entry<UUID, PendingSpin> entry : PENDING_SPINS.entrySet()) {
                if (serverTicks >= entry.getValue().expireTick()) {
                    ServerPlayer sp = server.getPlayerList().getPlayer(entry.getKey());
                    if (sp != null) {
                        claimPending(sp, false);
                    }
                }
            }
        });
    }

    public static void sendOpenComputer(ServerPlayer player) {
        long bal = ModEconomy.getBalanceCents(player.getUUID());
        ServerPlayNetworking.send(player, new OpenComputerPayload(bal));
    }

    public static void sendBalance(ServerPlayer player, String msg, boolean isError) {
        long bal = ModEconomy.getBalanceCents(player.getUUID());
        ServerPlayNetworking.send(player, new BalanceSyncPayload(bal, msg, isError));
    }

    private static void handleAction(ServerPlayer sp, String action, String arg) {
        switch (action) {
            case "open_upgrader" -> {
                claimPending(sp, false);
                UpgraderCompat.openUpgraderGui(sp);
            }
            case "upgrade_do" -> {
                claimPending(sp, false);
                String res = ComputerActions.tryUpgradeResult(sp, arg);
                sendBalance(sp, res, res.startsWith("ERR:"));
            }
            case "spin_case" -> {
                claimPending(sp, false);
                ComputerActions.CaseDef def = ComputerActions.getCaseDef(arg);
                if (!ModEconomy.spendCents(sp.getUUID(), def.costCents())) {
                    long bal = ModEconomy.getBalanceCents(sp.getUUID());
                    sendBalance(sp, "金幣不足！需要 " + ModEconomy.formatCents(def.costCents()) + " 金幣（餘額 " + ModEconomy.formatCents(bal) + "）", true);
                    return;
                }
                ComputerActions.CaseEntry entry = ComputerActions.rollCaseEntry(def.id(), sp.getRandom());
                ItemStack prize = entry.stack().copy();
                long valCents = ModEconomy.getStackCents(prize);
                String itemId = BuiltInRegistries.ITEM.getKey(prize.getItem()).toString();
                PENDING_SPINS.put(sp.getUUID(), new PendingSpin(
                        prize, entry.tierIndex(), entry.rarityLabel(), entry.color(), valCents, serverTicks + 140L
                ));
                long newBal = ModEconomy.getBalanceCents(sp.getUUID());
                ServerPlayNetworking.send(sp, new SpinResultPayload(
                        def.id(), def.costCents(), newBal, entry.tierIndex(), itemId, prize.getCount(), valCents
                ));
            }
            case "claim_spin" -> claimPending(sp, false);
            case "sell_offhand" -> {
                String res = ComputerActions.sellOffhandResult(sp);
                sendBalance(sp, res, res.startsWith("ERR:"));
            }
            case "sell_minerals" -> {
                String res = ComputerActions.sellAllMineralsResult(sp);
                sendBalance(sp, res, res.startsWith("ERR:"));
            }
            case "withdraw" -> {
                long amt = switch (arg) {
                    case "1" -> 1L;
                    case "10" -> 10L;
                    case "100" -> 100L;
                    case "1000" -> 1000L;
                    case "10000" -> 10000L;
                    default -> 0L;
                };
                if (amt > 0L) {
                    net.minecraft.world.item.Item coin = switch (arg) {
                        case "1" -> ModItems.COIN_1;
                        case "10" -> ModItems.COIN_10;
                        case "100" -> ModItems.COIN_100;
                        case "1000" -> ModItems.COIN_1000;
                        default -> ModItems.COIN_10000;
                    };
                    String res = ComputerActions.withdrawSingleResult(sp, amt, coin);
                    sendBalance(sp, res, res.startsWith("ERR:"));
                }
            }
            case "deposit_all" -> {
                String res = ComputerActions.depositAllResult(sp);
                sendBalance(sp, res, res.startsWith("ERR:"));
            }
            default -> {}
        }
    }

    private static void claimPending(ServerPlayer sp, boolean silent) {
        PendingSpin pending = PENDING_SPINS.remove(sp.getUUID());
        if (pending == null) {
            return;
        }
        ItemStack prize = pending.prize().copy();
        Component rewardName = prize.getHoverName().copy();
        int count = prize.getCount();
        ComputerActions.giveOrDrop(sp, prize);

        if (!silent) {
            if (pending.tierIndex() >= 4) {
                net.minecraft.sounds.SoundEvent goldSound = BuiltInRegistries.SOUND_EVENT
                        .getOptional(Identifier.withDefaultNamespace("ui.toast.challenge_complete"))
                        .orElse(SoundEvents.PLAYER_LEVELUP);
                sp.level().playSound(null, sp.blockPosition(), goldSound, SoundSource.PLAYERS, 0.9F, 1.0F);
            } else if (pending.tierIndex() >= 2) {
                sp.level().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.85F, 1.15F);
            } else {
                sp.level().playSound(null, sp.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8F, 0.95F);
            }

            long remaining = ModEconomy.getBalanceCents(sp.getUUID());
            sp.sendSystemMessage(Component.literal("🎰 開箱獲得 ")
                    .withStyle(ChatFormatting.GOLD)
                    .append(Component.literal("[" + pending.rarityLabel() + "] ").withStyle(pending.color(), ChatFormatting.BOLD))
                    .append(rewardName)
                    .append(Component.literal(" x" + count).withStyle(ChatFormatting.WHITE))
                    .append(Component.literal("（價值 " + ModEconomy.formatCents(pending.valCents())
                            + " 金幣｜餘額 " + ModEconomy.formatCents(remaining) + " 金幣）").withStyle(ChatFormatting.GRAY)));
        }
    }
}
