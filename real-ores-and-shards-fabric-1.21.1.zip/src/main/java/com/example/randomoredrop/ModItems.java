package com.example.randomoredrop;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModItems {
    public static final Item IRON_SHARD = registerSimple("iron_shard");
    public static final Item GOLD_SHARD = registerSimple("gold_shard");
    public static final Item COPPER_SHARD = registerSimple("copper_shard");
    public static final Item DIAMOND_SHARD = registerSimple("diamond_shard");
    public static final Item COAL_SHARD = registerSimple("coal_shard");
    public static final Item EMERALD_SHARD = registerSimple("emerald_shard");
    public static final Item LAPIS_SHARD = registerSimple("lapis_shard");
    public static final Item REDSTONE_SHARD = registerSimple("redstone_shard");
    public static final Item QUARTZ_SHARD = registerSimple("quartz_shard");

    public static final Item TIN_SHARD = registerSimple("tin_shard");
    public static final Item RAW_TIN = registerSimple("raw_tin");
    public static final Item TIN_INGOT = registerSimple("tin_ingot");

    public static final Item SILVER_SHARD = registerSimple("silver_shard");
    public static final Item RAW_SILVER = registerSimple("raw_silver");
    public static final Item SILVER_INGOT = registerSimple("silver_ingot");

    public static final Item TITANIUM_SHARD = registerSimple("titanium_shard");
    public static final Item RAW_TITANIUM = registerSimple("raw_titanium");
    public static final Item TITANIUM_INGOT = registerSimple("titanium_ingot");

    public static final Item TUNGSTEN_SHARD = registerFireproof("tungsten_shard");
    public static final Item RAW_TUNGSTEN = registerFireproof("raw_tungsten");
    public static final Item TUNGSTEN_INGOT = registerFireproof("tungsten_ingot");

    public static final Item TIN_SWORD = registerSword("tin_sword", ModToolTiers.TIN, 3, -2.4F, false);
    public static final Item TIN_PICKAXE = registerPickaxe("tin_pickaxe", ModToolTiers.TIN, 1.0F, -2.8F, false);
    public static final Item TIN_AXE = registerAxe("tin_axe", ModToolTiers.TIN, 6.0F, -3.1F, false);
    public static final Item TIN_SHOVEL = registerShovel("tin_shovel", ModToolTiers.TIN, 1.5F, -3.0F, false);
    public static final Item TIN_HOE = registerHoe("tin_hoe", ModToolTiers.TIN, -1.5F, -1.5F, false);
    public static final Item TIN_HELMET = registerArmor("tin_helmet", ModArmorMaterials.TIN, ArmorItem.Type.HELMET, 12, false);
    public static final Item TIN_CHESTPLATE = registerArmor("tin_chestplate", ModArmorMaterials.TIN, ArmorItem.Type.CHESTPLATE, 12, false);
    public static final Item TIN_LEGGINGS = registerArmor("tin_leggings", ModArmorMaterials.TIN, ArmorItem.Type.LEGGINGS, 12, false);
    public static final Item TIN_BOOTS = registerArmor("tin_boots", ModArmorMaterials.TIN, ArmorItem.Type.BOOTS, 12, false);

    public static final Item SILVER_SWORD = registerSword("silver_sword", ModToolTiers.SILVER, 3, -2.3F, false);
    public static final Item SILVER_PICKAXE = registerPickaxe("silver_pickaxe", ModToolTiers.SILVER, 1.0F, -2.8F, false);
    public static final Item SILVER_AXE = registerAxe("silver_axe", ModToolTiers.SILVER, 5.5F, -3.0F, false);
    public static final Item SILVER_SHOVEL = registerShovel("silver_shovel", ModToolTiers.SILVER, 1.5F, -3.0F, false);
    public static final Item SILVER_HOE = registerHoe("silver_hoe", ModToolTiers.SILVER, -2.0F, -1.0F, false);
    public static final Item SILVER_HELMET = registerArmor("silver_helmet", ModArmorMaterials.SILVER, ArmorItem.Type.HELMET, 18, false);
    public static final Item SILVER_CHESTPLATE = registerArmor("silver_chestplate", ModArmorMaterials.SILVER, ArmorItem.Type.CHESTPLATE, 18, false);
    public static final Item SILVER_LEGGINGS = registerArmor("silver_leggings", ModArmorMaterials.SILVER, ArmorItem.Type.LEGGINGS, 18, false);
    public static final Item SILVER_BOOTS = registerArmor("silver_boots", ModArmorMaterials.SILVER, ArmorItem.Type.BOOTS, 18, false);

    public static final Item TITANIUM_SWORD = registerSword("titanium_sword", ModToolTiers.TITANIUM, 3, -2.3F, false);
    public static final Item TITANIUM_PICKAXE = registerPickaxe("titanium_pickaxe", ModToolTiers.TITANIUM, 1.0F, -2.8F, false);
    public static final Item TITANIUM_AXE = registerAxe("titanium_axe", ModToolTiers.TITANIUM, 5.0F, -2.9F, false);
    public static final Item TITANIUM_SHOVEL = registerShovel("titanium_shovel", ModToolTiers.TITANIUM, 1.5F, -3.0F, false);
    public static final Item TITANIUM_HOE = registerHoe("titanium_hoe", ModToolTiers.TITANIUM, -3.0F, 0.0F, false);
    public static final Item TITANIUM_HELMET = registerArmor("titanium_helmet", ModArmorMaterials.TITANIUM, ArmorItem.Type.HELMET, 35, false);
    public static final Item TITANIUM_CHESTPLATE = registerArmor("titanium_chestplate", ModArmorMaterials.TITANIUM, ArmorItem.Type.CHESTPLATE, 35, false);
    public static final Item TITANIUM_LEGGINGS = registerArmor("titanium_leggings", ModArmorMaterials.TITANIUM, ArmorItem.Type.LEGGINGS, 35, false);
    public static final Item TITANIUM_BOOTS = registerArmor("titanium_boots", ModArmorMaterials.TITANIUM, ArmorItem.Type.BOOTS, 35, false);

    public static final Item TUNGSTEN_SWORD = registerSword("tungsten_sword", ModToolTiers.TUNGSTEN, 3, -2.5F, true);
    public static final Item TUNGSTEN_PICKAXE = registerPickaxe("tungsten_pickaxe", ModToolTiers.TUNGSTEN, 1.0F, -2.8F, true);
    public static final Item TUNGSTEN_AXE = registerAxe("tungsten_axe", ModToolTiers.TUNGSTEN, 5.0F, -3.1F, true);
    public static final Item TUNGSTEN_SHOVEL = registerShovel("tungsten_shovel", ModToolTiers.TUNGSTEN, 1.5F, -3.0F, true);
    public static final Item TUNGSTEN_HOE = registerHoe("tungsten_hoe", ModToolTiers.TUNGSTEN, -4.0F, 0.0F, true);
    public static final Item TUNGSTEN_HELMET = registerArmor("tungsten_helmet", ModArmorMaterials.TUNGSTEN, ArmorItem.Type.HELMET, 42, true);
    public static final Item TUNGSTEN_CHESTPLATE = registerArmor("tungsten_chestplate", ModArmorMaterials.TUNGSTEN, ArmorItem.Type.CHESTPLATE, 42, true);
    public static final Item TUNGSTEN_LEGGINGS = registerArmor("tungsten_leggings", ModArmorMaterials.TUNGSTEN, ArmorItem.Type.LEGGINGS, 42, true);
    public static final Item TUNGSTEN_BOOTS = registerArmor("tungsten_boots", ModArmorMaterials.TUNGSTEN, ArmorItem.Type.BOOTS, 42, true);

    public static final Map<Item, Item> ORE_TO_SHARD = new LinkedHashMap<>();

    static {
        ORE_TO_SHARD.put(Items.RAW_IRON, IRON_SHARD);
        ORE_TO_SHARD.put(Items.RAW_GOLD, GOLD_SHARD);
        ORE_TO_SHARD.put(Items.RAW_COPPER, COPPER_SHARD);
        ORE_TO_SHARD.put(Items.DIAMOND, DIAMOND_SHARD);
        ORE_TO_SHARD.put(Items.COAL, COAL_SHARD);
        ORE_TO_SHARD.put(Items.EMERALD, EMERALD_SHARD);
        ORE_TO_SHARD.put(Items.LAPIS_LAZULI, LAPIS_SHARD);
        ORE_TO_SHARD.put(Items.REDSTONE, REDSTONE_SHARD);
        ORE_TO_SHARD.put(Items.QUARTZ, QUARTZ_SHARD);
        ORE_TO_SHARD.put(RAW_TIN, TIN_SHARD);
        ORE_TO_SHARD.put(RAW_SILVER, SILVER_SHARD);
        ORE_TO_SHARD.put(RAW_TITANIUM, TITANIUM_SHARD);
        ORE_TO_SHARD.put(RAW_TUNGSTEN, TUNGSTEN_SHARD);
    }

    private static Item register(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name), item);
    }

    private static Item registerSimple(String name) {
        return register(name, new Item(new Item.Properties()));
    }

    private static Item registerFireproof(String name) {
        return register(name, new Item(new Item.Properties().fireResistant()));
    }

    private static Item.Properties baseProps(boolean fireproof) {
        Item.Properties props = new Item.Properties();
        return fireproof ? props.fireResistant() : props;
    }

    private static Item registerSword(String name, Tier tier, int damage, float speed, boolean fireproof) {
        return register(name, new SwordItem(tier, baseProps(fireproof).attributes(SwordItem.createAttributes(tier, damage, speed))));
    }

    private static Item registerPickaxe(String name, Tier tier, float damage, float speed, boolean fireproof) {
        return register(name, new PickaxeItem(tier, baseProps(fireproof).attributes(PickaxeItem.createAttributes(tier, damage, speed))));
    }

    private static Item registerAxe(String name, Tier tier, float damage, float speed, boolean fireproof) {
        return register(name, new AxeItem(tier, baseProps(fireproof).attributes(AxeItem.createAttributes(tier, damage, speed))));
    }

    private static Item registerShovel(String name, Tier tier, float damage, float speed, boolean fireproof) {
        return register(name, new ShovelItem(tier, baseProps(fireproof).attributes(ShovelItem.createAttributes(tier, damage, speed))));
    }

    private static Item registerHoe(String name, Tier tier, float damage, float speed, boolean fireproof) {
        return register(name, new HoeItem(tier, baseProps(fireproof).attributes(HoeItem.createAttributes(tier, damage, speed))));
    }

    private static Item registerArmor(String name, Holder<ArmorMaterial> material, ArmorItem.Type type, int durabilityMult, boolean fireproof) {
        return register(name, new ArmorItem(material, type, baseProps(fireproof).durability(type.getDurability(durabilityMult))));
    }

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            ORE_TO_SHARD.values().forEach(entries::accept);
            entries.accept(RAW_TIN); entries.accept(TIN_INGOT);
            entries.accept(RAW_SILVER); entries.accept(SILVER_INGOT);
            entries.accept(RAW_TITANIUM); entries.accept(TITANIUM_INGOT);
            entries.accept(RAW_TUNGSTEN); entries.accept(TUNGSTEN_INGOT);
        });

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(TIN_PICKAXE); entries.accept(TIN_AXE); entries.accept(TIN_SHOVEL); entries.accept(TIN_HOE);
            entries.accept(SILVER_PICKAXE); entries.accept(SILVER_AXE); entries.accept(SILVER_SHOVEL); entries.accept(SILVER_HOE);
            entries.accept(TITANIUM_PICKAXE); entries.accept(TITANIUM_AXE); entries.accept(TITANIUM_SHOVEL); entries.accept(TITANIUM_HOE);
            entries.accept(TUNGSTEN_PICKAXE); entries.accept(TUNGSTEN_AXE); entries.accept(TUNGSTEN_SHOVEL); entries.accept(TUNGSTEN_HOE);
        });

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
            entries.accept(TIN_SWORD); entries.accept(TIN_HELMET); entries.accept(TIN_CHESTPLATE); entries.accept(TIN_LEGGINGS); entries.accept(TIN_BOOTS);
            entries.accept(SILVER_SWORD); entries.accept(SILVER_HELMET); entries.accept(SILVER_CHESTPLATE); entries.accept(SILVER_LEGGINGS); entries.accept(SILVER_BOOTS);
            entries.accept(TITANIUM_SWORD); entries.accept(TITANIUM_HELMET); entries.accept(TITANIUM_CHESTPLATE); entries.accept(TITANIUM_LEGGINGS); entries.accept(TITANIUM_BOOTS);
            entries.accept(TUNGSTEN_SWORD); entries.accept(TUNGSTEN_HELMET); entries.accept(TUNGSTEN_CHESTPLATE); entries.accept(TUNGSTEN_LEGGINGS); entries.accept(TUNGSTEN_BOOTS);
        });
    }
}
