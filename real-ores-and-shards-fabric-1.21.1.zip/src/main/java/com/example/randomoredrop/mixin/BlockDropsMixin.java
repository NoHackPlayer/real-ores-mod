package com.example.randomoredrop.mixin;

import com.example.randomoredrop.ModItems;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;

@Mixin(Block.class)
public class BlockDropsMixin {
    private static final int MIN_SHARDS = 1;
    private static final int MAX_SHARDS = 4;

    @Inject(
            method = "getDrops(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)Ljava/util/List;",
            at = @At("RETURN"),
            cancellable = true
    )
    private static void replaceOreDropsWithShards(
            BlockState state,
            ServerLevel level,
            BlockPos pos,
            @Nullable BlockEntity blockEntity,
            @Nullable Entity entity,
            ItemStack tool,
            CallbackInfoReturnable<List<ItemStack>> cir
    ) {
        if (!state.is(ConventionalBlockTags.ORES)) {
            return;
        }

        List<ItemStack> originalDrops = cir.getReturnValue();
        if (originalDrops == null || originalDrops.isEmpty()) {
            return;
        }

        RandomSource random = level.getRandom();
        int fortuneLevel = 0;
        if (tool != null && !tool.isEmpty()) {
            Holder<Enchantment> fortune = level.registryAccess()
                    .lookupOrThrow(Registries.ENCHANTMENT)
                    .getOrThrow(Enchantments.FORTUNE);
            fortuneLevel = EnchantmentHelper.getItemEnchantmentLevel(fortune, tool);
        }

        List<ItemStack> modified = new ArrayList<>(originalDrops.size());
        for (ItemStack stack : originalDrops) {
            Item shard = ModItems.ORE_TO_SHARD.get(stack.getItem());
            if (shard != null) {
                int baseCount = random.nextIntBetweenInclusive(MIN_SHARDS, MAX_SHARDS);
                int fortuneBonus = fortuneLevel > 0 ? random.nextInt(fortuneLevel + 1) : 0;
                modified.add(new ItemStack(shard, baseCount + fortuneBonus));
            } else {
                modified.add(stack);
            }
        }

        cir.setReturnValue(modified);
    }
}
