package com.example.randomoredrop.mixin;

import com.example.randomoredrop.RandomOreDropMod;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.OreFeature;
import net.minecraft.world.level.levelgen.feature.ScatteredOreFeature;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({OreFeature.class, ScatteredOreFeature.class})
public class OreFeatureMixin {
    private static final float VANILLA_ORE_KEEP_CHANCE = 0.35f;

    @Inject(method = "place", at = @At("HEAD"), cancellable = true)
    private void reduceVanillaOreGeneration(FeaturePlaceContext<OreConfiguration> context, CallbackInfoReturnable<Boolean> cir) {
        OreConfiguration config = context.config();

        boolean isExternalOre = config.targetStates.stream().anyMatch(target -> {
            BlockState state = target.state;
            String namespace = BuiltInRegistries.BLOCK.getKey(state.getBlock()).getNamespace();
            if (RandomOreDropMod.MOD_ID.equals(namespace)) {
                return false;
            }
            return state.is(ConventionalBlockTags.ORES) || state.is(Blocks.ANCIENT_DEBRIS);
        });

        if (isExternalOre && context.random().nextFloat() > VANILLA_ORE_KEEP_CHANCE) {
            cir.setReturnValue(false);
        }
    }
}
