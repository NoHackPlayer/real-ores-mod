package com.example.randomoredrop;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public class ModBlocks {
    public static final Block TIN_ORE = registerOre("tin_ore", 3.0f, 3.0f, SoundType.STONE, MapColor.STONE, 0, 2);
    public static final Block DEEPSLATE_TIN_ORE = registerOre("deepslate_tin_ore", 4.5f, 3.0f, SoundType.DEEPSLATE, MapColor.DEEPSLATE, 0, 2);

    public static final Block SILVER_ORE = registerOre("silver_ore", 3.2f, 3.0f, SoundType.STONE, MapColor.STONE, 1, 3);
    public static final Block DEEPSLATE_SILVER_ORE = registerOre("deepslate_silver_ore", 4.7f, 3.0f, SoundType.DEEPSLATE, MapColor.DEEPSLATE, 1, 3);

    public static final Block TITANIUM_ORE = registerOre("titanium_ore", 4.0f, 5.0f, SoundType.STONE, MapColor.STONE, 2, 5);
    public static final Block DEEPSLATE_TITANIUM_ORE = registerOre("deepslate_titanium_ore", 5.5f, 5.0f, SoundType.DEEPSLATE, MapColor.DEEPSLATE, 2, 5);

    public static final Block TUNGSTEN_ORE = registerOre("tungsten_ore", 4.5f, 6.0f, SoundType.STONE, MapColor.STONE, 3, 6);
    public static final Block DEEPSLATE_TUNGSTEN_ORE = registerOre("deepslate_tungsten_ore", 6.0f, 6.0f, SoundType.DEEPSLATE, MapColor.DEEPSLATE, 3, 6);

    private static Block registerOre(String name, float strength, float resistance, SoundType sound, MapColor color, int minXp, int maxXp) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name);
        Block block = new DropExperienceBlock(
                UniformInt.of(minXp, maxXp),
                BlockBehaviour.Properties.of()
                        .mapColor(color)
                        .requiresCorrectToolForDrops()
                        .strength(strength, resistance)
                        .sound(sound)
        );
        Registry.register(BuiltInRegistries.BLOCK, id, block);
        Registry.register(BuiltInRegistries.ITEM, id, new BlockItem(block, new Item.Properties()));
        return block;
    }

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.NATURAL_BLOCKS).register(entries -> {
            entries.accept(TIN_ORE);
            entries.accept(DEEPSLATE_TIN_ORE);
            entries.accept(SILVER_ORE);
            entries.accept(DEEPSLATE_SILVER_ORE);
            entries.accept(TITANIUM_ORE);
            entries.accept(DEEPSLATE_TITANIUM_ORE);
            entries.accept(TUNGSTEN_ORE);
            entries.accept(DEEPSLATE_TUNGSTEN_ORE);
        });
    }
}
