package com.example.randomoredrop;

import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;

public class ModArmorMaterials {
    public static final Holder<ArmorMaterial> TIN = register(
            "tin",
            Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                map.put(ArmorItem.Type.BOOTS, 1);
                map.put(ArmorItem.Type.LEGGINGS, 4);
                map.put(ArmorItem.Type.CHESTPLATE, 5);
                map.put(ArmorItem.Type.HELMET, 2);
                map.put(ArmorItem.Type.BODY, 4);
            }),
            16, SoundEvents.ARMOR_EQUIP_IRON, 0.0F, 0.0F,
            () -> Ingredient.of(ModItems.TIN_INGOT)
    );

    public static final Holder<ArmorMaterial> SILVER = register(
            "silver",
            Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                map.put(ArmorItem.Type.BOOTS, 2);
                map.put(ArmorItem.Type.LEGGINGS, 5);
                map.put(ArmorItem.Type.CHESTPLATE, 6);
                map.put(ArmorItem.Type.HELMET, 2);
                map.put(ArmorItem.Type.BODY, 5);
            }),
            22, SoundEvents.ARMOR_EQUIP_GOLD, 0.5F, 0.0F,
            () -> Ingredient.of(ModItems.SILVER_INGOT)
    );

    public static final Holder<ArmorMaterial> TITANIUM = register(
            "titanium",
            Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                map.put(ArmorItem.Type.BOOTS, 3);
                map.put(ArmorItem.Type.LEGGINGS, 6);
                map.put(ArmorItem.Type.CHESTPLATE, 8);
                map.put(ArmorItem.Type.HELMET, 3);
                map.put(ArmorItem.Type.BODY, 11);
            }),
            12, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.5F, 0.05F,
            () -> Ingredient.of(ModItems.TITANIUM_INGOT)
    );

    public static final Holder<ArmorMaterial> TUNGSTEN = register(
            "tungsten",
            Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                map.put(ArmorItem.Type.BOOTS, 3);
                map.put(ArmorItem.Type.LEGGINGS, 6);
                map.put(ArmorItem.Type.CHESTPLATE, 8);
                map.put(ArmorItem.Type.HELMET, 3);
                map.put(ArmorItem.Type.BODY, 12);
            }),
            8, SoundEvents.ARMOR_EQUIP_NETHERITE, 3.5F, 0.15F,
            () -> Ingredient.of(ModItems.TUNGSTEN_INGOT)
    );

    private static Holder<ArmorMaterial> register(
            String name,
            EnumMap<ArmorItem.Type, Integer> defense,
            int enchantmentValue,
            Holder<SoundEvent> equipSound,
            float toughness,
            float knockbackResistance,
            Supplier<Ingredient> repairIngredient
    ) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name);
        List<ArmorMaterial.Layer> layers = List.of(new ArmorMaterial.Layer(id));
        ArmorMaterial material = new ArmorMaterial(
                defense, enchantmentValue, equipSound, repairIngredient, layers, toughness, knockbackResistance
        );
        return Registry.registerForHolder(BuiltInRegistries.ARMOR_MATERIAL, id, material);
    }

    public static void initialize() {
        // Trigger static initialization
    }
}
