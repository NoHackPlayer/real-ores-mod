package com.example.randomoredrop;

import net.fabricmc.api.ModInitializer;

public class RandomOreDropMod implements ModInitializer {
    public static final String MOD_ID = "randomoredrop";

    @Override
    public void onInitialize() {
        ModArmorMaterials.initialize();
        ModBlocks.initialize();
        ModItems.initialize();
        ModWorldGen.initialize();
    }
}
