package com.example.randomoredrop;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public class ModWorldGen {
    public static final ResourceKey<PlacedFeature> ORE_TIN_KEY = placedKey("ore_tin");
    public static final ResourceKey<PlacedFeature> ORE_SILVER_KEY = placedKey("ore_silver");
    public static final ResourceKey<PlacedFeature> ORE_TITANIUM_KEY = placedKey("ore_titanium");
    public static final ResourceKey<PlacedFeature> ORE_TUNGSTEN_KEY = placedKey("ore_tungsten");

    private static ResourceKey<PlacedFeature> placedKey(String name) {
        return ResourceKey.create(Registries.PLACED_FEATURE, ResourceLocation.fromNamespaceAndPath(RandomOreDropMod.MOD_ID, name));
    }

    public static void initialize() {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Decoration.UNDERGROUND_ORES, ORE_TIN_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Decoration.UNDERGROUND_ORES, ORE_SILVER_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Decoration.UNDERGROUND_ORES, ORE_TITANIUM_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Decoration.UNDERGROUND_ORES, ORE_TUNGSTEN_KEY);
    }
}
