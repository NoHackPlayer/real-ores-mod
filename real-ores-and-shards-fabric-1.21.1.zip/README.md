# Real Ores & Shards (Fabric 1.21.1)

## 免裝軟體：用 GitHub 自動編譯成 `.jar`
1. 登入 GitHub，點右上角 `+` → **New repository** 建立一個新的倉庫（名稱隨意，例如 `real-ores-mod`）。
2. 解壓本 ZIP 檔案，把資料夾裡面的**所有檔案與資料夾**（包含 `.github`、`src`、`build.gradle`、`gradle.properties`、`settings.gradle`、`LICENSE`）直接拖曳上傳到 GitHub 倉庫根目錄，點 **Commit changes**。
   - 提示：Windows / macOS 若沒看到 `.github` 隱藏資料夾，請先開啟「顯示隱藏檔案」。
3. 點擊倉庫上方的 **Actions** 分頁，等待 `Build Fabric Mod JAR` 跑完並顯示綠色勾勾（約 1～2 分鐘）。
4. 點進去該次執行結果，在最下方 **Artifacts** 區塊下載 `real-ores-and-shards-mod-jar`，解壓裡面的 `real-ores-and-shards-1.0.0.jar`，連同 **Fabric API (1.21.1)** 一起放入 Minecraft 的 `mods` 資料夾即可遊玩！
